---
uuid: 20230110142114
title: How To set Goals - Dave Ramsey
created: 2023-01-10T14:21:14
updated: 2023-01-10T14:21:21
private: true
alias:
---
Up:: [[Goals MOC]]

# [[How To set Goals - Dave Ramsey]]

- Author:: [[@Dave Ramsey]]
- Category:: video
- URL:: https://www.youtube.com/watch?v=3U4AUvrlp_0
- Rating:: 

## Learn by elaboration


---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source
- 🏷️ Tags:: [[Goals MOC]] 
- 📡 Status:: #status/🌲 

