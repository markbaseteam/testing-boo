---
uuid: 20230110134422
title: 7 Goal-Setting Categories - Dave Ramsey
created: 2023-01-10T13:44:22
updated: 2023-01-10T13:44:27
private: false
alias:
---

# [[7 Goal-Setting Categories - Dave Ramsey]]

- Author:: [[@Dave Ramsey]]
- Category:: video
- URL:: https://www.youtube.com/watch?v=8BtrZcNjBqk
- Rating:: 5

## Learn by elaboration
- Physical
- Intellectual
- Family
- Career
- Financial 
- Spiritual
- Family

[[Goal setting categories]]

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source
- 🏷️ Tags:: [[Goals MOC]]
- 📡 Status:: #status/🌿 

