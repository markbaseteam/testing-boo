---
uuid: 20220501221610
title: Learning a language
created: 2022-05-01T22:16:10.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
Up:: [[Personal Development]]

# [[Learning a language]]


Started learning French but lost the plot as there was no one to practice with, Cest la vie
## Apps
- [[Duolingo]] (free)

---
## 📇Additional Metadata

- 🏷️ Tags::
- 📡 Status:: #status/🌲 