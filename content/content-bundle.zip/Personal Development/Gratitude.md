---
uuid: 20221223081839
title: Gratitude
created: 2022-12-23T08:18:39
updated: 2022-12-23T08:18:39
private: true
alias:
---

Up:: [[Goals MOC]]

# [[Gratitude]]

To be practiced everyday as there are many things and people to be grateful for. Can be hard sometimes to see it though.


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Personal Health MOC]]
- 📡 Status:: #status/🌲 
