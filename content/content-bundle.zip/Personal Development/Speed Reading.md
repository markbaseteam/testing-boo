---
uuid: 20230526123338
title: Speed Reading
created: 2023-05-26T12:33:38
updated: 2023-05-26T12:33:38
private: false
alias:
---

# [[Speed Reading]]

## Tips
- Minimize sub-vocalization
- Use your finger to guide your reading
- Do not reread anything you already read
- Try and stop and start 1 to 2 words from the beginning of a line

## Reasons for slow reading
- Sub-vocalization
	- Reduce this by using small distractions
	- Press the tip of your tongue to the roof of your mouth
	- Environment is key, not too loud or too quiet
- Re-reading (Regression)
	- Go back to the beginning of a sentence when it does not make sense
	- Using a pen/chopstick to read faster
	- Using a card or paper to cover up what you read.
- Fixations
	- Untrained reader has 15 fixations per line
	- Reduce to about 3-4 using bouncing and using your peripheral vision

## 3 Techniques
- Train your eyes
	- Peripheral vision to fixate less 
- Train your mind
	- Visualize
	- Start with 60-80% comprehension
- Train your focus
	- 


## Current WPM
- 
- [[2023-05-26]] 200

## Books, articles and videos
- [[The Speed Reading Book - Tony Buzan]]
- For:
	- [How to Read a Book a Day | Jordan Harry | TEDxBathUniversity - YouTube](https://www.youtube.com/watch?v=e2-ahs905MQ)
	- [You’re Not Slow: Become a Speed Reader in 15 Minutes - YouTube](https://www.youtube.com/watch?v=HB__TF9rp0E)
- Against:
	- [The Science Behind Reading Speed - College Info Geek - YouTube](https://www.youtube.com/watch?v=jv2BdHXRD3Q)
	- [Do Speed Reading Apps & Techniques Really Work? - College Info Geek - YouTube](https://www.youtube.com/watch?v=JL4WMHyUhdc)
	- [5 Ways to Read Faster That ACTUALLY Work - College Info Geek - YouTube](https://www.youtube.com/watch?v=kmDMrxUSXKY&t=0s)



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Education]]
- 📡 Status:: #status/🌲  
