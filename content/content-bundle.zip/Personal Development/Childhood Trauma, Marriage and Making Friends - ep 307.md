---
uuid: 20230419143512
title: Childhood Trauma, Marriag and Making Friends - ep 307
created: 2023-04-19T14:35:12
updated: 2023-04-19T14:35:13
private: true
alias:
---

# [[Childhood Trauma, Marriage and Making Friends - ep 307]]

- Author:: [[@Jordan Peterson]]
- Category:: video
- URL:: [Childhood Trauma, Marriage, and Making Friends | Dr. John Delony | EP 307 - YouTube](https://www.youtube.com/watch?v=B_373YVlnDA&t=2471s)
- Rating:: 5

## Learn by elaboration
- Many good points were made in this podcast
- Need to communicate at LEAST 90min per week on domestic matters
- Need to date at LEAST 90min to not get a communication backlog
- Need to work on a vision - ask the hard questions cause you do not know
- Really need to listen to what your wife/significant other says 
	- Ask if she wants to connect or she is looking for a solution

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source
- 🏷️ Tags:: [[Marriage]], [[Relationship]]
- 📡 Status:: #status/🌲 

