---
uuid: 20230106070827
title: The Optimal Morning Routine - Andrew Huberman
created: 2023-01-06T07:08:27
updated: 2023-01-06T07:08:27
private: true
alias:
---

# [[The Optimal Morning Routine - Andrew Huberman]]

- Author:: [[Andrew Huberman]]
- Category:: video
- URL:: https://www.youtube.com/watch?v=gR_f-iwUGY4
- Rating:: 5

## Learn by elaboration
- Get 5-10 min light in your eyes AS SOON AS the sun is up/out
	- Times the Cortisol Pulse 
	- Circadian Rhythm
	- 
- Bad night sleep? Adenosine may still be in your body
	- Wait 90 min before first cup of coffee
	- Exercise
- Dopamine is the molecule for DRIVE
	- Used in creation of Epinephrine
- Temperature
	- Keep room cool when trying to fall asleep
	- Ice bath to boost dopamine production
	- Pain is short lived but pleasure is long
	- Pleasure is short lived but pain is long

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/video 
- 🏷️ Tags:: [[Motivation]] [[Dopamine]] [[Personal Development]]
- 📡 Status:: #status/🌲 

