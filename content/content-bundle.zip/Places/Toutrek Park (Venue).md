---
uuid: 20220725064856
title: Toutrek Park (Venue)
created: 2022-07-25T06:48:56
updated: 2022-07-25T06:48:56
private: true
alias:
---

# [[Toutrek Park (Venue)]]

Nice venue with decent pricing

## Events held
- Rugby End Year
- Cricket End Year
- [[Jan-Willem 40th Birthday]]
- NJ Birthday
- Rochelle Birthday



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
