---
uuid: 20220429100631
title: Queenswood Medical Centre
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---
# Queenswood Medical Centre

Medical center in Pretoria

Address: 
207 Shilling St, Queenswood, Pretoria, 0186

Hours: Opens 7AM

Health and safety: Appointment required · Mask required · Temperature check required · Staff wear masks · Staff get temperature checks · Staff required to disinfect surfaces between visits · More details

**Phone**: 012 111 8855
**Web:** http://www.queenswoodmed.co.za/

## Dr. Gerrie Dekker
Credentials:
General Medical Practitioner and Director at QMC Medical

## Dr. Karlien Coetzee
Credentials:
General Medical Practitioner and Director at QMC Medical

### Review:
"Friendly family practise with doctors,dentists and nursing services under one roof."