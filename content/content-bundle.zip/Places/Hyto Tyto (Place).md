---
uuid: 20220522153458
title: Hyto Tyto (Place)
created: 2022-05-22T15:34:58.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

# [[Hyto Tyto (Place)]]

a nice place to hold birthday parties for children
bit upperclass
located near Midstream area

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- [[Places]]
- 
