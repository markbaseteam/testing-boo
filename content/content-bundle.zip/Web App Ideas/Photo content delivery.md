---
uuid: 20220429100644
title: Photo content delivery
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---
Basicly a cloud app where users pay to pull the image directly from our service.

Have an ability for sellers to sell their product photos via this services, ask small percentage for using service(eg 15% with min of R9 pm per photo.)

Buyers will get an api key to access images and it will be delivered via sytem (see facebook like blocks).

Maybe look into creating an image gallery that can be imported as block.