---
uuid: 20220429120850
title: Transportation for loads of goods, produce etc
created: 2022-04-29T12:08:50.000Z
updated: 2022-06-09T16:15:28.345Z
private: false
alias: null
---

# [[Transportation for loads of goods, produce etc]]

- A place where users of the site are either goods or transport, and can request quotes or submit quotes.

---
## 📇Additional Metadata

- Type:: #type/note 
- Status:: #status/📤 
- Tags:: [[Web Application]]