---
uuid: 20220429100644
title: Invoice and quoting system
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---
A simple system that can be used to generate and send emails with custom invoices and quotes to a client. Quotes will have 3 segments a spec, a hour sheet and a single page quote.

Invoices:
Totally customizable look and feel via html template.
Save invoice as pdf.
Send invoice as pdf attachment.
Invoice statuses - created, sent, paid, cancelled.

Clients:

Company name, contact person, billing address, delivery address, emai address, tel, fax, cell.

Client statuses- potential, new, existing

Lead:

Hear about job, enter potential customer details, notes about lead, date received, folow up date.

Quotes:

3 parts, brief (spec), hour sheet based on spec, official quote with spec signed off.

Spec will be a 3 partdocument. First section will be a brief. Second section will be requirements, which is basically the brief just more pointalized. Section 3 will bethe functional spec, most probably written up by the developer quoting on the system.

User will only get a  single screen with buttons on the side what will be used to mark each task which needs to be quoted (something similar to a wiki markup language).

Spec must be downloadable, mailable and printable.