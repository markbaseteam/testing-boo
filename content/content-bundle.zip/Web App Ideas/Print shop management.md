---
uuid: 20220429100644
title: Print shop management
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.344Z
private: false
alias: null
---
Know where your job is at all times. Workflow based along with some crm to let clients know where in the workflow their jobs are. Customizble amount of workflow steps.