---
uuid: 20220502102040
title: Content management system
created: "2022-05-02T10:"
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---
A base cms that will be extendible to the degree of doing all projects. Basic user, menu, pages, multi-site, media management. Simple rss feed, with api.

Site:
Different template per subdomain
Different pages per subdomain
Different menus per subdomain with ability to duplicate menu os needed to.

Menu:
Menu items will be role based.
Menus will have unlimited depth.

Pages:
Content area with ckeditor.

Media management:
Ability to upload jpg,png,gif,swf,mpg,mov
Must be able to manage folders for where to upload media.

Users:
Single table for users.
Password will have salt and sha1 hashed.
User can belong to multiple groups.
Resources can be assigned to groups or single user.

Template management:
Ability to set layouts, images, css and template specific js.
Look into creating blocks for certain areas to display different modules.

Installer:
A nice installer to install the cms.
Ability to update from a remote location

Poll an update folder and install if an update was downlaoded from the main site.

Ability to make updates optional or mandatory.
Set a time for the updater to run.

Above systems will have to be modular and extendible.