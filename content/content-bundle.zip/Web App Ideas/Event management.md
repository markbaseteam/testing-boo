---
uuid: 20220429100644
title: Event management
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---
An online app where users can go from organizing a event, get payments online, advertise the event with emails, sms. Ability to create a single advert page.