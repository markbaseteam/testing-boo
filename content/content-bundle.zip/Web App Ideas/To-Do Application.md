---
uuid: 20220429100644
title: To-Do Application
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.344Z
private: false
alias: null
---
**To-Do Application**

- Add, edit, delete items CData handling example : IwUIText

- Due date for item sqlite

- Reminders - can choose between email and alarm, alarm sound can be chosen from the device, snooze function on alarm s3eAudio

- Integration with Google Calendar
- Set item duration on capture sqlite
- Ability to search Google Calendar for open slot on specific day to slot item into
- Settings - work days and working hours in a day, Google account settings, Alarm settings s3eSecureStorage

Please note that you guys need to supply Johan with a deadline for the development by end of business today.