---
uuid: 20220517033816
title: Online examination tool
created: 2022-05-17T03:38:16.000Z
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---

# [[Online examination tool]]


Description:

A Platform for teachers and students to go and take dummy exams for practice. Teachers will be able to sell exams and students be able to buy exams.

teachers will be able to offer the exams for free for a premium subscription.

Pre-primary: 1 teacher, 1 exam, 30 questions, 3 retakes.

Primary: 3 teachers, 10 exams, 50 questions each, 3 retakes $3

High School: 20 teachers, Unlimited exams, Unlimited Questions, Unlimited Retakes $9

College: Higher Education, Sell exams, Issue Certificates $29

targets:

primary * 500 = $1500;
High School * 500 = $4500;
College * 100 = $2900;

Total = $8900/month;

Possible names: Quiznos, exammate, exampal, exambud, exam


---
## 📇Additional Metadata

- Type:: #type/note 
- Status:: #status/📤 
- Tags:: [[Web Application]]