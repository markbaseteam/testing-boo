---
uuid: 20220429100644
title: Task feeder
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.344Z
private: false
alias: null
---
Tasks get assigned to projects, users can share projects, must be able to assign who can create tasks, edit tasks and delete tasks. Tasks get created in a feed and users can subscribe to a feed.