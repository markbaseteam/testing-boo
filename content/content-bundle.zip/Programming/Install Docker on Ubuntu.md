---
uuid: 20230526123751
title: Install Docker on Ubuntu
created: 2023-05-26T12:37:51
updated: 2023-05-26T12:37:52
private: false
alias:
---
Up:: [[Ubuntu]]

# [[Install Docker on Ubuntu]]

- Language:: [[Bash]]
- Type:: [[DevOps]]
- Context:: Installling Docker on a fresh install to start using it for deployment or development


- Snippet

```bash
$ curl -fsSL https://get.docker.com -o get-docker.sh

$ sudo sh get-docker.sh

$ sudo usermod -aG docker $USER

$ sudo apt install docker-compose-plugin
```

- Dependencies:: [[Docker]] and [[Ubuntu]]
- Source:: [Installing Docker on Ubuntu (4 Easy Ways) - Kinsta®](https://kinsta.com/blog/install-docker-ubuntu/)

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Docker]] [[Ubuntu]] [[DevOps]]
- 📡Status:: #status/🌲 