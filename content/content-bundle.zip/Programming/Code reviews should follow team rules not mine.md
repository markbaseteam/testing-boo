---
uuid: 20220607203349
title: Code reviews should follow team rules not mine
created: 2022-06-07T20:33:49.000Z
updated: 2022-06-09T16:15:28.337Z
private: true
alias: null
---

# [[Code reviews should follow team rules not mine]]

> [!quote] Not everyone codes like you
  Remember that not everyone codes the same and certainly doesn't always code the way you do. This doesn't mean they are wrong, and nor does it mean you're way is best.
  See Also:: [[Key elements to check for when doing code reviews]]
- Coding styles can be very personal and reviews should not follow your own styles and preferences. Check the teams rules and styles set forth when making suggestions.
---
## Additional Metadata

- Type:: #type/note
- Origin:: [[My Opinion on What Makes a Good Code Review.]]
- Tags:: [[Code Review]]
- Status:: #status/🌲 