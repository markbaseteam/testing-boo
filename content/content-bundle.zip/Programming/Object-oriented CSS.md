---
uuid: 20220516033952
title: Object-oriented CSS
created: 2022-05-16T03:39:52.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# [[Object-Oriented CSS]]

## Hosted

Play with these in Firebug to learn the basics.

- [Template](http://oocss.org/template.html)
- [Grids](http://oocss.org/grids_docs.html)
- [Module](http://oocss.org/module.html)
- [Content](http://oocss.org/library.html) (very alpha)

## Downloads on Github

- [Velocity download](http://cloud.github.com/downloads/stubbornella/oocss/velocity-download.zip)
- [Alternate download](http://oocss.org/velocity/velocity-download.zip)

## Stuck?

If you don't keep up with any of the exercises you can view (and download) the finished examples here.

- [Starting Template](http://oocss.org/velocity/exercise_template.html)
- [Exercise 1: Template](http://oocss.org/velocity/exercise1.html)
- [Exercise 2: Grids](http://oocss.org/velocity/exercise2.html)
- [Exercise 3: Module Manipulation](http://oocss.org/velocity/exercise3.html)
- [Exercise 4 Module Creation](http://oocss.org/velocity/exercise4.html)

## Welcome, Velocity Conference participants!

All the resources you need to get started are linked from the left navigation. Start by downloading the base files. Exercises one and two can be completed in Firebug if you are comfortable with it. Then you can download the finished file at the beginning of Exercise 3.

[Stubbornella](http://stubbornella.org/content/), [Github](http://wiki.github.com/stubbornella/oocss), [FAQ](http://wiki.github.com/stubbornella/oocss/faq)