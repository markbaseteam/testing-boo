---
uuid: 20220526080631
title: Save url to PDF
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[Save url to PDF]]

The web is constantly evolving, and for that reason you may want to be able to save some of your favorite pages in PDF format. Several websites allows you to do it, and now here’s a simple PHP function to integrate this functionnality into your own site or app.

`1.function url2pdf($url,$pdffilename) {`

`2.return $this->copyFile("http://pdfmyurl.com?url=".urlencode( str_replace("http://","",$url) ), $pdffilename);`

`3.}`
**» [Credits: Snipplr](http://snipplr.com/view.php?codeview&id=43877)**
 *Written by* Jean-Baptiste Jung • *Published on * April 3rd, 2011

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]