---
uuid: 20220429120811
title: DateTimeOffset Conversions
created: 2022-04-29T12:08:11.000Z
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---

# [[DateTimeOffset Conversions]]
- Language:: [[CSharp]]
- Type:: [[Back-end]]
- Context – DateTime conversions
- Convert a nullable DateTimeOffset? to a DateTime type
	* [StackOverflow](https://stackoverflow.com/questions/34223919/how-do-i-convert-a-datetimeoffset-to-datetime-in-c)
	* [MSDN Conversions from DateTimeOffset to DateTime](https://docs.microsoft.com/en-us/dotnet/standard/datetime/converting-between-datetime-and-offset#conversions-from-datetimeoffset-to-datetime)
* Snippet 

```csharp
var now = DateTime.Now;
DateTimeOffset? offset = now;
DateTime dateTime = offset.HasValue ? offset.Value.DateTime : DateTime.MaxValue;
```

- Dependencies:: – link to any other code or packages that are relevant or that you need to use this snippet

----
## 📇Additional Metadata

- Type:: #type/snippet
