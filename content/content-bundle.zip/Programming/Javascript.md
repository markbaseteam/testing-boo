---
uuid: 20230315144655
title: Javascript
created: 2023-03-15T14:46:55
updated: 2023-03-15T14:46:55
private: true
alias:
---

# [[Javascript]]



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Programming]] [[Language]]
- 📡 Status:: #status/🌲 
