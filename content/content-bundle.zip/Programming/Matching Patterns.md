---
uuid: 20220525072205
title: Matching Patterns
created: 2022-05-25T07:22:05.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# [[Matching Patterns]]

## Matching Patterns

The *preg_match()* function performs Perl-style pattern matching on a string. *preg_match()* takes two basic and three optional parameters. These parameters are, in order, a regular expression string, a source string, an array variable which stores matches, a flag argument and an offset parameter that can be used to specify the alternate place from which to start the search:

preg_match ( pattern, subject [, matches [, flags [, offset]]])

The *preg_match()* function returns 1 if a match is found and 0 otherwise. Let's search the string "Hello World!" for the letters "ll":

```php
<?php
if (preg_match("/ell/", "Hello World!", $matches)) {
  echo "Match was found <br />";
  echo $matches[0];
}
?>
```

The letters "ll" exist in "Hello", so *preg_match()* returns 1 and the first element of the $matches variable is filled with the string that matched the pattern. The regular expression in the next example is looking for the letters "ell", but looking for them with following characters:

```php
<?php
if (preg_match("/ll.*/", "The History of Halloween", $matches)) {
  echo "Match was found <br />";
  echo $matches[0];
}
?>
```

Now let's consider more complicated example. The most popular use of regular expressions is validation. The example below checks if the password is "strong", i.e. the password must be at least 8 characters and must contain at least one lower case letter, one upper case letter and one digit:

```php
<?php
$password = "Fyfjk34sdfjfsjq7";

if (preg_match("/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).*$/", $password)) {
    echo "Your passwords is strong.";
} else {
    echo "Your password is weak.";
}
?>
```

The ^ and $ are looking for something at the start and the end of the string. The ".*" combination is used at both the start and the end. As mentioned above, the .(dot) metacharacter means any alphanumeric character, and * metacharacter means "zero or more". Between are groupings in parentheses. The "?=" combination means "the next text must be like this". This construct doesn't capture the text. In this example, instead of specifying the order that things should appear, it's saying that it must appear but we're not worried about the order.

The first grouping  is (?=.*{8,}). This checks if there are at least 8 characters in the string. The next grouping (?=.*[0-9]) means "any alphanumeric character can happen zero or more times, then any digit can happen". So this checks if there is at least one number in the string. But since the string isn't captured, that one digit can appear anywhere in the string. The next groupings (?=.*[a-z]) and (?=.*[A-Z]) are looking for the lower case and upper case letter accordingly anywhere in the string.

Finally, we will consider regular expression that validates an email address:
```php
<?php
$email = firstname.lastname@aaa.bbb.com;

$regexp = "/^[^0-9][A-z0-9_]+([.][A-z0-9_]+)*[@][A-z0-9_]+([.][A-z0-9_]+)*[.][A-z]{2,4}$/";

if (preg_match($regexp, $email)) {
    echo "Email address is valid.";
} else {
    echo "Email address is <u>not</u> valid.";
}
?>
```

This regular expression checks for the number at the beginning and also checks for multiple periods in the user name and domain name in the email address. Let's try to investigate this regular expression yourself.

For the speed reasons, the *preg_match()* function matches only the first pattern it finds in a string. This means it is very quick to check whether a pattern exists in a string. An alternative function, *preg_match_all()*, matches a pattern against a string as many times as the pattern allows, and returns the number of times it matched.

![uparrow.gif](../../_resources/uparrow.gif)[Back to top](http://www.webcheatsheet.com/php/regular_expressions.php#top)

---
## Additional Metadata

Type:: #type/note
Origin:: [[Regular Expressions Starter for PHP]]
- Language:: [[PHP]]
- Tags:: [[Regular Expressions]] 