---
uuid: 20220515085158
title: Calculate age using date of birth
created: 2022-05-15T08:51:58.000Z
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---
## Calculate age using date of birth
Language:: [[PHP]] 
Type:: [[Back-end]] 

Pass a birth date to this function, and it will return the age of the person; very useful when building communities or social media sites.

`01.``function`  `age(``$date``){`
`02.``$year_diff`  `= ``''``;`
`03.``$time`  `= ``strtotime``(``$date``);`
`04.``if``(FALSE === ``$time``){`
`05.``return`  `''``;`
`06.``}`
`07.`
`08.``$date`  `= ``date``(``'Y-m-d'``, ``$time``);`
`09.``list(``$year``,``$month``,``$day``) = ``explode``(``"-"``,``$date``);`
`10.``$year_diff`  `= ``date``(``"Y"``) – ``$year``;`
`11.``$month_diff`  `= ``date``(``"m"``) – ``$month``;`
`12.``$day_diff`  `= ``date``(``"d"``) – ``$day``;`
`13.``if`  `(``$day_diff`  `< 0 || ``$month_diff`  `< 0) ``$year_diff``–;`
`14.`
`15.``return`  `$year_diff``;`
`16.``}`

Type:: #type/snippet 
**Source: [John Karry on http://www.phpsnippets.info/calculate-age-of-a-person-using-date-of-birth](http://www.phpsnippets.info/calculate-age-of-a-person-using-date-of-birth#comment-25)**