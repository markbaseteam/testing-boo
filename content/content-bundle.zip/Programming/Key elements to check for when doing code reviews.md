---
uuid: 20220608034748
title: Key elements to check for when doing code reviews
created: 2022-06-08T03:47:48.000Z
updated: 2022-06-09T16:15:28.340Z
private: true
alias: null
---

# [[Key elements to check for when doing code reviews]]

Always take a step back and think about the key elements of code review.
  - Does the code follow your team's coding guidelines
  - Does the code meet its objective / acceptance criteria.
  - Is the code legible and easy to understand what it's doing without the need for heavy comments / documentation. (**This one for me is one of the most important, as I'm a huge fan of descriptive method and variable names.**
  - Does the code need any refactoring, considering security, performance or simply ease of reading.
  - Does the code follow simple design patterns / principles e.g single responsibility, abstraction, encapsulation etc. If not make suggestions on how this can be achieved or perhaps teach those not familiar with it what it means and the benefits. ([View Highlight](https://instapaper.com/read/1507273537/19667850))

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[Code reviews should follow team rules not mine]]
- Tags:: [[Code Review]]
- Status:: #status/🌲 