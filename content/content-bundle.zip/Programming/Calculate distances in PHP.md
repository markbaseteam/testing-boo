---
uuid: 20220526080631
title: Calculate distances in PHP
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---

# [[Force file download]]

## Calculate distances in PHP

Here is a very handy function, which calculate the distance from a point A to a point B, using latitudes and longitudes. The function can return the distance in miles, kilometers, or nautical miles.
```php

function  distance($lat1, $lon1`, $lat2, $lon2, $unit) { 
	$theta = $lon1 - $lon2;
	$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));

	$dist= acos($dist);
	$dist = rad2deg($dist);
	$miles = $dist * 60 * 1.1515;
	$unit = strtoupper($unit);
	
	if ($unit == "K") {
		return ($miles * 1.609344);
			} else if ($unit == "N") {
				return ($miles * 0.8684);
			} else {`
				return  $miles`;
		}
	}
```


Usage:

`1.echo  distance(32.9697, -96.80322, 29.46786, -98.53506, "k")." kilometers";`

**» [Credits: PHP Snippets.info](http://www.phpsnippets.info/calculate-distances-in-php)**

---
## Additional Metadata

Type:: #type/note
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]
