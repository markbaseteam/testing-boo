---
uuid: 20221121120228
title: Microsoft Certifications for Flowcentric
created: 2022-11-21T12:02:28
updated: 2022-11-21T12:02:28
private: false
alias:
- Microsoft Azure Certifications 2023
---
Up:: [[Microsoft Azure|Azure]]

# [[Microsoft Certifications for Flowcentric]]

[16/11 10:08 am] Braam Nel

**Intermediate**

- [Microsoft Certified: Azure Administrator Associate - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/azure-administrator/ "https://learn.microsoft.com/en-us/certifications/azure-administrator/")
- [Microsoft Certified: Azure Developer Associate - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/azure-developer/ "https://learn.microsoft.com/en-us/certifications/azure-developer/")
- [Microsoft Certified: Power Platform Developer Associate - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/power-platform-developer-associate/ "https://learn.microsoft.com/en-us/certifications/power-platform-developer-associate/")

**Advanced**

- [Microsoft Certified: Azure Solutions Architect Expert - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/azure-solutions-architect/ "https://learn.microsoft.com/en-us/certifications/azure-solutions-architect/")
- [Microsoft Certified: Azure IoT Developer Specialty - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/azure-iot-developer-specialty/ "https://learn.microsoft.com/en-us/certifications/azure-iot-developer-specialty/")
- [Microsoft Certified: DevOps Engineer Expert - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/devops-engineer/ "https://learn.microsoft.com/en-us/certifications/devops-engineer/")
- [Microsoft Certified: Power Platform Solution Architect Expert - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/power-platform-solution-architect-expert/ "https://learn.microsoft.com/en-us/certifications/power-platform-solution-architect-expert/")


### Current chosen path:
- [Microsoft Certified: Azure Solutions Architect Expert - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/azure-solutions-architect/)
	- [Microsoft Certified: Azure Administrator Associate - Certifications | Microsoft Learn](https://learn.microsoft.com/en-us/certifications/azure-administrator/)
	- [AZ-104: Prerequisites for Azure administrators - Training | Microsoft Learn](https://learn.microsoft.com/en-us/training/paths/az-104-administrator-prerequisites/)
		- [Microsoft Azure Fundamentals: Describe cloud concepts - Training | Microsoft Learn](https://learn.microsoft.com/en-us/training/paths/microsoft-azure-fundamentals-describe-cloud-concepts/)
			- [[MS Azure Fundamentals - Describe cloud concepts]]
			- [[MS Azure Fundamentals - Describe Azure architecture and services]]
		- [Azure Fundamentals: Describe Azure management and governance - Training | Microsoft Learn](https://learn.microsoft.com/en-us/training/paths/describe-azure-management-governance/)



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Education]] [[Personal Development]]
- 📡 Status:: #status/🌲 
