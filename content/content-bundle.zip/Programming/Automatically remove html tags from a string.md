---
uuid: 20220515074840
title: Automatically remove html tags from a string
created: 2022-05-15T07:48:40.000Z
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---

## Automatically remove html tags from a string

Language:: [[PHP]] 
Type:: [[Back-end]] #type/snippet 

On user-submitted forms, you may want to remove all unnecessary html tags. Doing so is easy using the strip_tags() function:

`1.``$text`  `= ``strip_tags``(``$input``, ``""``);`
**Source: http://phpbuilder.com/columns/Jason_Gilmore060210.php3?page=2**