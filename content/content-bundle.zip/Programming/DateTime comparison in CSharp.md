---
uuid: 20221109092222
title: DateTime comparison in CSharp
created: 2022-11-09T09:22:22
updated: 2022-11-09T09:22:31
private: false
alias:
---

# [[DateTime comparison in CSharp]]

- Language:: [[CSharp]]
- Type:: [[Back-end]]
- Context:: Compare to dates and return a value based on which one is larger than the other
- Description :
	- [DateTime.Compare() Method in C# - GeeksforGeeks](https://www.geeksforgeeks.org/datetime-compare-method-in-c-sharp/)

- Snippet 

```csharp
// C# program to demonstrate the
// DateTime.Compare(DateTime,
// DateTime) Method
using System;

class GFG {

	// Main Method
	public static void Main()
	{
		// creating object of DateTime
		DateTime date1 = new DateTime(2010, 1,
								1, 4, 0, 15);

		// creating object of DateTime
		DateTime date2 = new DateTime(2010, 1,
								1, 4, 0, 14);

		// comparing date1 and date2
		// using Compare() method;
		int value = DateTime.Compare(date1, date2);

		// checking
		if (value > 0)
			Console.Write("date1 is later than date2. ");
		else if (value < 0)
			Console.Write("date1 is earlier than date2. ");
		else
			Console.Write("date1 is the same as date2. ");
	}
}

```

- Dependencies:: 

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[CSharp]]
- 📡Status:: #status/🌲 