---
uuid: 20220515065158
title: Get your average Feedburner subscribers
created: "2022-05-15T06:"
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---
## Get your average Feedburner subscribers

Recently, Feedburner counts had lots of problems and it’s hard to say that the provided info is still relevant. This code will grab your subscriber count from the last 7 days and will return the average.

```php
`01.``function`  `get_average_readers(``$feed_id``,``$interval`  `= 7){`
`02.``$today`  `= ``date``(``'Y-m-d'``, ``strtotime``(``"now"``));`

`03.``$ago`  `= ``date``(``'Y-m-d'``, ``strtotime``(``"-"``.``$interval``.``" days"``));`

`04.``$feed_url``=``"https://feedburner.google.com/api/awareness/1.0/GetFeedData?uri="``.``$feed_id``.``"&dates="``.``$ago``.``","``.``$today``;`

`05.``$ch`  `= curl_init();`
`06.``curl_setopt(``$ch``, CURLOPT_RETURNTRANSFER, 1);`
`07.``curl_setopt(``$ch``, CURLOPT_URL, ``$feed_url``);`
`08.``$data`  `= curl_exec(``$ch``);`
`09.``curl_close(``$ch``);`
`10.``$xml`  `= ``new`  `SimpleXMLElement(``$data``);`
`11.``$fb`  `= ``$xml``->feed->entry[``'circulation'``];`
`12.`
`13.``$nb`  `= 0;`
`14.``foreach``(``$xml``->feed->children() ``as`  `$circ``){`
`15.``$nb`  `+= ``$circ``[``'circulation'``];`
`16.``}`
`17.`
`18.``return`  `round``(``$nb``/``$interval``);`
`19.``}`
```

**Source: http://www.catswhoblog.com/how-to-get-a-more-relevant-feedburner-count**