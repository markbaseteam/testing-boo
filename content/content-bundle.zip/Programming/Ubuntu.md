---
uuid: 20230531094651
title: Ubuntu
created: 2023-05-31T09:46:51
updated: 2023-05-31T09:46:51
private: true
alias:
---

# [[Ubuntu]]

- Linux Operating System
- Best starter OS for Linux for people starting on Linux or moving from Windows or MacOS

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: 
- 📡 Status:: #status/🌲 
