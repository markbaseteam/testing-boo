---
uuid: 20220513045213
title: Wrap code in a region in VS Studio
created: 2022-05-13T04:52:13.000Z
updated: 2022-06-09T16:15:28.342Z
private: false
alias: null
---

#### **Question**
# [[Wrap code in a region in VS Studio]]

#### **Answer**
```
Keyboard Shortcut after selecting code to be wrapped: CTRL+K, CTRL+S

Snippet to create new region: #r, tab, tab
```

#### **Links/related reading** 
- links to other useful information (keep your notes as lean as possible)

----

Type:: #type/question-answer 
Tags:: [[Visual Studio 2022]] [[Programming]]

---
