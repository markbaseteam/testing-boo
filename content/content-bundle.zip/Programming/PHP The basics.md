---
uuid: 20220429120642
title: PHP The basics
created: 2022-04-29T12:06:42.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---
# [[PHP The basics]]

Type:: #type/content 
Status:: #status/🌲 

I have recently decided that i should get my certificqtion in my language of choice, php. I am going try and take all 10 sections in a bpog post each, working from the study guide and the manual to get as complete a set of notes as possible. Something to also do is creating small scripts that will help me grasp some of the concepts and the inner wokings of a funtion, class or extension.

So, to part 1 in our studies, the basics.

Php tags. To get php to be interpreted, you need to open a tag and, depending where you used it, close a tag. There are 4 valid tags:
```php
<?php and ?>
<? And ?>
<script language="php"> and <script>
<% and %>
```

The first and third one is always accessible and the second and third one is only active is set so in the php.ini file.

The is a bunch of operators in php: logical, mathematical associative and comparison. They all have a certain precedence and to know this is key:

A new feature in php 5.3 is namespaces. They were introduced to help with the organizing of classes and to help with the almost 30 character long class names that were prevailing in 5.2. There some rules to using namespaces in your code:

You should use them directly after the opening php tags
Only one namespace per class (according to best practices)

Insert sample code.

Variables are the lifeblood of any languages, and php is no different. There are some rules to using them:

It can only begin with a letter or an underscore.