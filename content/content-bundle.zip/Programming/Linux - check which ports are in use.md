---
uuid: 20230426160317
title: Linux - check which ports are in use
created: 2023-04-26T16:03:17
updated: 2023-04-26T16:03:17
private: false
alias:
---

# [[Linux - check which ports are in use]]

- Language:: [[Bash]]
- Type:: Server
- Context:: CLI
- Description – gives a list of ports in use by the system it is being running 

- Snippet 

```
$ sudo lsof -i -P -n | grep LISTEN
```

- 

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Linux]] [[Bash]] 
- 📡Status:: #status/🌲 