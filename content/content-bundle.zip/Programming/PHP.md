---
uuid: 20220513110739
title: PHP
created: 2022-05-13T11:07:39.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# [[PHP]]

## Links
- [PHP: The Right Way (phptherightway.com)](https://phptherightway.com/#site-header)

## Snippets
```dataview
LIST
FROM [[PHP]] and #type/snippet 
```

---
## 📇Additional Metadata

- 📁 Type:: #type/note
- Language:: [[PHP]]
- 🏷️ Tags:: [[Programming]] - [[Back-end]] - [[Server-side]]
