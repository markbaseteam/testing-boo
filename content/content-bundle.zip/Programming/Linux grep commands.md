---
uuid: 20221115131105
title: Linux grep commands
created: 2022-11-15T13:11:05
updated: 2022-11-15T13:11:05
private: true
alias:
---

# [[Linux grep commands]]


- [16 grep Command Examples to Help You in Real-World (geekflare.com)](https://geekflare.com/grep-command-examples/)

```bash
$ grep -i -C1 "bidderlastupdatedRecord" storage/logs/laravel.log
```
	
- ` -i ` Case insensitive
- ` -C[num] ` lines above and below

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Linux]]
- 📡 Status:: #status/🌲 
