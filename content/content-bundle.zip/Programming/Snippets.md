---
uuid: 20220515052430
title: Snippets
created: "2022-05-15T05:"
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

```dataview
TABLE type, language
FROM #type/snippet 
```

