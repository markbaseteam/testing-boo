---
uuid: 20230501101957
title: Github Flow
created: 2023-05-01T10:19:57
updated: 2023-05-01T10:19:57
private: false
alias:
---

# [[Github Flow]]

- Author:: [[Github]]
- Category:: article
- URL:: [GitHub flow - GitHub Docs](https://docs.github.com/en/get-started/quickstart/github-flow)
- Rating:: 4

## Learn by elaboration
- A simpler flow than [[Gitflow]] to work on the [[Github]] platform that is used EVERYWHERE.
- Should take this into account when working on [[Github]] and you are trying to contribute to a repo/library/code base.

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/article 
- 🏷️ Tags:: [[Git]]
- 📡 Status:: #status/🌲 

