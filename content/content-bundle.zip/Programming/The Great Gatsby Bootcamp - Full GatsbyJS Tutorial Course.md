---
uuid: 20220531211337
title: The Great Gatsby Bootcamp - Full GatsbyJS Tutorial Course
created: 2022-05-31T21:13:37.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[The Great Gatsby Bootcamp - Full GatsbyJS Tutorial Course]]

- Video: https://www.youtube.com/watch?v=kzWIUX3CpuI

This needs expansion... 🤦‍♂️





---
## 📇 Additional Metadata

- 🗂 Type:: #type/source 
- Source:: #source/course
- 🏷️ Tags:: [[GatsbyJS]] [[Netlify]] 
- 📡 Status:: #status/🌲 
- Done:: Yes
