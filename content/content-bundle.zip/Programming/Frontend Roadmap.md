---
uuid: 20220728232825
title: Frontend Roadmap
created: 2022-07-28T23:28:25
updated: 2022-07-28T23:28:25
private: true
alias:
---

# [[Frontend Roadmap]]

```mermaid
flowchart LR
	FRONTEND
	FRONTEND-->Internet
```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Web development]]
- 📡 Status:: #status/🌿 
