---
uuid: 20220530085902
title: Parse custom date time format
created: 2022-05-30T08:59:02.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# [[Parse custom date time format]]

- Language:: [[CSharp]]
- Type:: [[Back-end]]
- Context:: When you have a custom or inconsistent date and or time format, this may a good way to parse the text/string

- Snippet 

```csharp

DateTime insertedDateTime = DateTime.ParseExact(tokens[0] + " " + tokens[1], "yyyy-MM-dd mm:HH:ss", CultureInfo.InvariantCulture);

```

- Dependencies:: [DateTime parse with custom format](https://stackoverflow.com/questions/18630985/datetime-parse-with-custom-format)

----
## 📇Additional Metadata

- Type:: #type/snippet

