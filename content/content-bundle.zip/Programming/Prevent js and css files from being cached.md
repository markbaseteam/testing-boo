---
uuid: 20220515085158
title: Prevent js and css files from being cached
created: 2022-05-15T08:51:58.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---
## Prevent js and css files from being cached
Language:: [[PHP]] 
Type:: [[Back-end]] 

By default, external files such as javascript and css are cached by the browser. If you want to prevent this from caching, simply use this easy tip:

`1.``<link href=``"/stylesheet.css?<?php echo time(); ?>"`  `rel=``"stylesheet"`  `type=``"text/css"`  `/&glt;`

The result will look like this:

`1.``<link href=``"/stylesheet.css?1234567890"`  `rel=``"stylesheet"`  `type=``"text/css"`  `/&glt;`

Type:: #type/snippet 
**Source: http://davidwalsh.name/prevent-cache**