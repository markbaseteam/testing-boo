---
uuid: 20220515075606
title: Search for a string in another string
created: 2022-05-15T07:56:06.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---
## Search for a string in another string
Language:: [[PHP]] 
Type:: #type/snippet [[Back-end]] 

Description:: If a string is contained in another string and you need to search for it, this is a very clever way to do it:

```php
`1.``function`  `contains(``$str``, ``$content``, ``$ignorecase``=true){`
`2.``if`  `(``$ignorecase``){`
`3.``$str`  `= ``strtolower``(``$str``);`
`4.``$content`  `= ``strtolower``(``$content``);`
`5.``}`
`6.``return`  `strpos``(``$content``,``$str``) ? true : false;`
`7.``}`
```
**Source: http://www.jonasjohn.de/snippets/php/contains.htm**