---
uuid: 20220905160938
title: Connect to docker container for command line access
created: 2022-09-05T16:09:38
updated: 2022-09-05T16:09:52
private: true
alias:
---

# [[Connect to docker container for command line access]]

- Language:: Command Line
- Type:: front-end, back-end, deployment/DevOps
- Context:: create your own multi-select categories to further describe the purpose of the snippet e.g. is this to do with styling, making API calls, creating utility functions etc.
- Description – a text-based description of the snippet

- Snippet 

```cli
$ docker exec -it <container name> /bin/bash
```

- Dependencies:: – link to any other code or packages that are relevant or that you need to use this snippet

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags::
- 📡Status:: #status/🌲 