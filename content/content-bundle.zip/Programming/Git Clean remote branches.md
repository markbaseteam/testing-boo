---
uuid: 20221010045008
title: Git Clean local branches
created: 2022-10-10T04:50:08
updated: 2022-10-10T04:50:08
private: true
alias:
---

# [[Git Clean remote branches]]

- Language:: [[Bash]]
- Type:: [[Source Code Management]]
- Context:: cleans up branches that have already been merged into the branch you are currently on.
- Description 

- Snippet 

```bash

$ git branch -r --merged | egrep -v "(^\*|main|phase-2)" | xargs -n 1 git push --delete origin

# remove the origin prefix of the branch
$ git branch -r --merged | egrep -v "(^\*|main|phase-2)" | sed 's/origin\///' | xargs -n 1 git push --delete origin

```

- Dependencies:: https://devconnected.com/how-to-clean-up-git-branches/

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Git]]
- 📡Status:: #status/🌲 