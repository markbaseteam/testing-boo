---
uuid: 20220524094551
title: Plain Old CSharp Objects (POCOs)
created: 2022-05-24T09:45:51.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias:
  - POCO
---

# [[Plain Old CSharp Objects (POCOs)]]

>A Plain Old CLR/C# Object is a POCO. Java has Plain Old Java Objects, or POJOs. Really you could refer to these collectively as "Plain Old Objects" but I'm guessing someone didn't like the acronym that produced. So, what does it mean for an object to be "plain old"? **Basically, that it doesn't rely on a specific framework or library in order to function.** A plain old object can be instantiated anywhere in your application or in your tests and doesn't need to have a particular database or third party framework involved to function.

```csharp
public class Product
{
  public Product(int id)
  {
    Id = id;
  }

  private Product()
  {
    // required for EF
  }

  public int Id { get; private set; }
  // other properties and methods
}
```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note 
- 🏷️ Tags:: [[CSharp]] 
- 🌐 Url:: [Plain old CLR object - Wikipedia](https://en.wikipedia.org/wiki/Plain_old_CLR_object)

