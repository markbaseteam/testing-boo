---
uuid: 20230331093753
title: SQL Data entry template
created: 2023-03-31T09:37:53
updated: 2023-03-31T09:37:53
private: true
alias:
---
Up:: [[T-SQL]]

# [[SQL Data entry template]]

```sql
BEGIN TRY
	BEGIN TRANSACTION TRN_Datachange

		INSERT INTO TableName (Col1, Col2)
		VALUES
			('123', '567'),
			('654', '287')

		UPDATE TableName
		SET Col1 = '7654'
		WHERE ID = 1

	COMMIT TRANSACTION TRN_Datachange
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION TRN_Datachange

    DECLARE @ErrorNumber INT = ERROR_NUMBER();
    DECLARE @ErrorLine INT = ERROR_LINE();

    PRINT 'Actual error number: ' + CAST(@ErrorNumber AS VARCHAR(10));
    PRINT 'Actual line number: ' + CAST(@ErrorLine AS VARCHAR(10));

    THROW;
END CATCH
```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Programming]]
- 📡 Status:: #status/🌲 
