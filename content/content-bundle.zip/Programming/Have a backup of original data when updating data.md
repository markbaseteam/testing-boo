---
uuid: 20220429120846
title: Have a backup of original data when updating data
created: 2022-04-29T12:08:46.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

# [[Have a backup of original data when updating data]]

- Language:: [[T-SQL]]
- Type:: [[Back-end]]
- Context:: When updating data for testing, keep original
- Description – Have a backup of original data when updating data. You can have this by having the field you want to update in the where clause with the original value
- Snippet

``` sql
UPDATE Users SET UserID = 1, TestValue = 'mickey'
Where UserID = 2 and TestValue = 'Donald' and Id = 5
```
- Dependencies:: – link to any other code or packages that are relevant or that you need to use this snippet

----
## 📇Additional Metadata

- Type:: #type/snippet
- 📡 Status:: #status/🌲 

