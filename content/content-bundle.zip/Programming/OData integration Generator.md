---
uuid: 20220502045839
title: OData integration Generator
created: 2022-05-02T04:58:39.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# [[OData integration Generator]]

- A simple OData integration code generator using the [OData Client](https://learn.microsoft.com/en-us/odata/client/getting-started) in C#

https://marketplace.visualstudio.com/items?itemName=bingl.ODatav4ClientCodeGenerator



Type:: #type/link 
Language:: [[CSharp]] 
