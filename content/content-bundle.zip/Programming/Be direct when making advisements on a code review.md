---
uuid: 20220607203234
title: Be direct when making advisements on a code review
created: 2022-06-07T20:32:34.000Z
updated: 2022-06-09T16:15:28.336Z
private: true
alias: null
---

# [[Be direct when making advisements on a code review]]

> [!quote] Be clear and concise.
  Be straight to the point and clear about what you want changed or are advising. Don't waffle on, beating around the bush simply state the What and Why.
  Most git systems these days allow you to click on the line you wish to be changed , and add a comment so it's much simpler to specify the exact line of code you want changed.
  Hosting providers such as GitHub have a "suggestion" feature which allows you to add a code suggestion directly into the comment, which can instantly be accepted and committed from within the PR. ([View Highlight](https://instapaper.com/read/1507273537/19667841))
- Don't beat around the bush. Saying what and why you are advising changes will be more of value than trying a long winded explanation.
---
## Additional Metadata

- Type:: #type/note
- Origin:: [[My Opinion on What Makes a Good Code Review.]]
- Tags:: [[Code Review]]