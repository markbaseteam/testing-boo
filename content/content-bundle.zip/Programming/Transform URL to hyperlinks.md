---
uuid: 20220516033954
title: Transform URL to hyperlinks
created: 2022-05-16T03:39:54.000Z
updated: 2022-06-09T16:15:28.342Z
private: false
alias: null
---

# [[Transform URL to hyperlinks]]
- Language:: [[PHP]]
- Type:: [[Back-end]]
- Context:: create your own multi-select categories to further describe the purpose of the snippet e.g. is this to do with styling, making API calls, creating utility functions etc.
- Description:: If you leave a URL in the comment form of a WordPress blog, it will be automatically transformed into a hyperlink. If you want to implement the same functionality in your own website or web app, you can use the following code:

- Snippet 
  
```php

`1.``$url`  `= ``"Jean-Baptiste Jung (http://www.webdevcat.com)"``;`

`2.``$url`  `= preg_replace(``"#http://([A-z0-9./-]+)#"``, ``'<a href="$1">$0</a>'``, ``$url``);`
Snippet here
```

- Dependencies:: 

----
## 📇Additional Metadata

- Type:: #type/snippet 
- **Source: http://phpbuilder.com/columns/Jason_Gilmore060210.php3?page=2**

