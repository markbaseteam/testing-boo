---
uuid: 20220726103159
title: GoLang
created: 2022-07-26T10:31:59
updated: 2022-07-26T10:31:59
private: false
alias:
---

# [[GoLang]]



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Programming]]
- 📡 Status:: #status/🌲 
