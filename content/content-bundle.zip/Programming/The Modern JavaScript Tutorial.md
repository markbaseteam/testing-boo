---
uuid: 20220727072038
title: The Modern Javascript Tutorial
created: 2022-07-27T07:20:38
updated: 2022-07-27T07:20:51
private: false
alias:
---

# [[The Modern JavaScript Tutorial]]

- Author:: 
- Category:: website
- URL:: https://javascript.info/
- Rating:: 4

## Learn by elaboration


---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/website 
- 🏷️ Tags:: [[Javascript]]
- 📡 Status:: #status/🌲 

