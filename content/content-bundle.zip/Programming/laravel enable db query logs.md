---
uuid: 20220920135838
title: laravel enable db query logs
created: 2022-09-20T13:58:38
updated: 2022-09-20T13:58:50
private: true
alias:
---

# [[laravel enable db query logs]]

- Language:: [[PHP]] [[Laravel]]
- Type:: [[Back-end]]
- Context:: Enable the logging of the sql queries for an endpoint
- Description – a text-based description of the snippet

- Snippet 


First you have to enable query log it can be done using

```php
DB::enableQueryLog();
$user = User::get();
$query = DB::getQueryLog();
dd($query);
```

- Dependencies:: – link to any other code or packages that are relevant or that you need to use this snippet

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags::
- 📡Status:: #status/🌲 