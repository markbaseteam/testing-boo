---
uuid: 20230530044025
title: Microsoft Azure
created: 2023-05-30T04:40:25
updated: 2023-05-30T04:40:25
private: false
alias:
- Azure
---
Up:: [[Cloud Computing]]

# [[Microsoft Azure]]

## Certifications
- [[Microsoft Certifications for Flowcentric]]

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
