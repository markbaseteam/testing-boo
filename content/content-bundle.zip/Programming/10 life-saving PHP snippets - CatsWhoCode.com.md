---
uuid: 20220429100639
title: 10 life-saving PHP snippets - CatsWhoCode.com
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---
# 10 life-saving PHP snippets

In order to be efficient, a web developer should have a toolbox with code snippets he can use and reuse when needed. In this article, I’m going to show you 10 extremely useful PHP code snippets to add to your web developer toolbox.

[[Highlight specific words in a phrase]]

[[Get your average Feedburner subscribers]]

[[Automatic password creation]]

[[Compress multiple CSS files]]

[[Get short urls for Twitter]]

[[Calculate age using date of birth]]

[[Calculate execution time]]

[[Maintenance mode with PHP]]

[[Prevent js and css files from being cached]]

[[Add (th, st, nd, rd, th) to the end of a number]]