---
uuid: 20220429100643
title: Using the Windows COM in PHP « Justin Martin
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.342Z
private: false
alias: null
---
[Using the Windows COM in PHP « Justin Martin](http://thefrozenfire.com/2011/02/using-the-windows-com-in-php/)