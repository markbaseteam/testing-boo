---
uuid: 20220606131001
titel: Block Protocol
created: 2022-06-06T13:10:01
last-modified: 2022-06-06T13:10:01
alias:
---

# [[Block Protocol]]

- URL:: https://blockprotocol.org/
- Status:: 
- Description:  A proposal for a structured data to be able to transfer data between applications, example persons

> [!info] 
> The Block Protocol is a global standard for building **interactive blocks** connected to **structured data**.
>
 The following pages provide a practical introduction for developers who want to:
> -  [develop blocks](https://blockprotocol.org/docs/developing-blocks) and publish them to the block registry
> -   [embed blocks](https://blockprotocol.org/docs/embedding-blocks) within an application or allow an app's users to dynamically do the same
>For the full technical details, read [the Block Protocol specification](https://blockprotocol.org/spec).
>
>If you have any questions, [please open or contribute to a discussion](https://github.com/blockprotocol/blockprotocol/discussions). You can also [chat to us on Discord](https://blockprotocol.org/discord).


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Structured Data]]
- 📡 Status:: #status/🌲 
