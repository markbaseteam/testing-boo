---
uuid: 20220526060651
title: 10 super useful PHP snippets - CatsWhoCode.com
created: "2022-05-26T06:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---
# 10 super useful PHP snippets

Having the right code snippet at the right time can definitely be a life saver for web developers. Today, I’ve compiled 10 really awesome PHP code snippets that will, I hope, be very helpful in your forthcomming developments.

See Also:: [[Super simple page caching]]

See Also:: [[Calculate distances in PHP]]

See Also:: [[Convert seconds to time (years, months, days, hours…)]]

See Also:: [[Force file download]]

See Also:: [[Get current weather using Google API]]

See Also:: [[Basic PHP whois]]

See Also:: [[Get latitude and longitude from an adress]]

See Also:: [[Get domain favicon using PHP and Google]]

See Also:: [[Calculate Paypal fees]]

See Also:: [[Save url to PDF]]