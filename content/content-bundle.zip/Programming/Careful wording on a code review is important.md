---
uuid: 20220607203116
title: Careful wording on a code review is important
created: 2022-06-07T20:31:16.000Z
updated: 2022-06-09T16:15:28.336Z
private: true
alias: null
---

# [[Careful wording on a code review is important]]

> [!quote] Word comments carefully
  Remember that the person's code you're reviewing has probably put a lot of effort into this work, and they haven't deliberately made mistakes, especially those easy to miss spelling mistakes etc.
  Try not to be too soul crushing when leaving comments.
  Don't be so forceful with comments or suggestions. For example rather than saying
  Change this variable name
  Say something like:
  Perhaps this could be worded to a more descriptive variable name.
  This way the suggestion for improvement is made, but in a way that makes the coder feel they still have a say / matter is open for discussion. ([View Highlight](https://instapaper.com/read/1507273537/19667839))
	
- When leaving a comment on a Code Review, wording is important. Try being suggestive rather than commanding, (Catch more with honey).

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[My Opinion on What Makes a Good Code Review.]]
- Tags:: [[Code Review]]