---
uuid: 20220509080749
title: How to add existing project to new solution
created: 2022-05-09T08:07:49.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

# [[How to add existing project to new solution]]

## Creating a new solution

If the new solution doesn't yet exist, create it as follows:

1.  In Visual Studio, File>New>Project
2.  In the New Project form,  
    a. In the upper-left pane, choose Installed>Other Project Types>Visual Studio Solutions  or search for 'solution', lets you select 'Empty Solution'
    b. In Name: enter the new solution's name _sln_  
    c. In Location: enter the parent directory of the new solution's directory  
    d. Then OK the form.

## Moving an existing project, which is already in one solution, to another solution

I think of a project as being part of a solution (rather than projects being separate from solutions). Therefore, in my solutions, a project's directory is a subdirectory of that for the solution which contains the project.

1.  Cut the project's directory _proj_ and paste it into the new solution's directory _sln_
2.  In Visual Studio, load _sln_ (if not already loaded)
3.  In the Solution Explorer,  
    a. Click mouse button 2 on the line Solution '_sln_'  
    b. In the pop-up menu, select Add>Existing Project  
    c. Navigate to _sln_\ _proj_ and select _proj_.vcxproj  
    d. Click Open

---

How come I didn't see this before? Two things. One was that I expected the function to be on a pop-up made by clicking mouse button 2 on the Solution Explorer entry for the _project_. The other was I had never before created a solution as such --- only ever created a project, choosing an existing solution or "Create new solution" as the case may be. Not good UI, IMO, to hid the "create solution" functionality under "New Project". Once the new solution exists, Hans's method makes the rest of the task easy.

- Tags:: [[Visual Studio 2022]] [[CSharp]] 
- Status:: #status/🌲 