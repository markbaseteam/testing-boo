---
uuid: 20220429100642
title: SVN Tips and tricks
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[SVN Tips and tricks]]

Create a patch between 2 different tags

Check-for-modifications dialog, sort by status. Shift-Click or Ctrl-Click to select all those with "modified" and "added" status. Then simply right-drag the files from the Check-for-modifications dialog to another folder in explorer.

Another way (if you already committed your changes): Show log dialog, select all revisions with the interesting changes. In the lower pane, shift-select all entries, right-click, choose "save as".

Yet another way: Use the repository browser, find the first url (assuming you want to export everything that's changed between two tags, e.g., version 1 and version 2), right-click, "Mark for comparison". Find the second url, right-click, "compare urls". In the following "changed files" dialog, select all files, right-click, choose "export selection to...".

SVN Commit failed (details follow): Illegal repository URL ''

open the check-for-modifications dialog on your working copy root. Then
show the URL column (right-click on the column header to get a menu for
additiional columns).
It could be that your working copy got corrupted and lost the target url.

use relocate to fix the directory