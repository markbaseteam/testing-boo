---
uuid: 20220722092723
title: Coding Resources - List of Resources
created: 2022-07-22T09:27:23
updated: 2022-07-22T09:27:23
private: true
alias:
---

# [[Coding Resources - List of Resources]]

Coding Resources: https://brindle-celsius-ac6.notion.site/d0f94b8ef82042959520d47078286f16?v=8597b7f469be4b62bf8633b06f51b9d1

| Name                               | Tag          | Description | Link                              |
| ---------------------------------- | ------------ | ----------- | --------------------------------- |
| Programming Fonts                  |              |             | https://www.programmingfonts.org/ |
| SpaceVIM                           | Tool, Editor |             | https://spacevim.org/             |
| [[The Modern JavaScript Tutorial]] | Tutorial     |             | https://javascript.info/          |
|                                    |              |             |                                   |

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[2022-07-22]]
- Status:: #status/🌲 
- Tags:: [[Programming]], 