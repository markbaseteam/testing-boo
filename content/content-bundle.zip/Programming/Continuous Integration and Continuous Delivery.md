---
uuid: 20230501093554
title: Continuous Integration
created: 2023-05-01T09:35:54
updated: 2023-05-01T09:35:54
private: false
alias:
- "CI/CD"
---
Up:: [[DevOps]]

# [[Continuous Integration and Continuous Delivery]]

- Way way to many things need to go in here still


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Git]], [[Programming]]
- 📡 Status:: #status/🌲 
