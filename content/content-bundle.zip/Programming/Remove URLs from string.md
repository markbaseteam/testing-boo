---
uuid: 20220515075112
title: Remove URLs from string
created: 2022-05-15T07:51:12.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

## Remove URLs from string
Language:: [[PHP]] 
Type:: #type/snippet [[Back-end]] 

Description:: When I see the amount of URLs people try to leave in my blog comments to get traffic and/or backlinks, I think I should definitely give a go to this snippet!

```php
 $string = preg_replace('/\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|$!:,.;]*[A-Z0-9+&@#\/%=~_|$]/i', '', $string);
```

**Source: http://snipplr.com/view.php?codeview&id=15236**