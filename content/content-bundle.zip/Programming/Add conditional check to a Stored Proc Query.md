---
uuid: 20221114083600
title: Add conditional check to a Stored Proc Query
created: 2022-11-14T08:36:00
updated: 2022-11-14T08:36:04
private: true
alias:
---

# [[Add conditional check to a Stored Proc Query]]

- Language:: [[T-SQL]]
- Type:: [[Back-end]] [[Database]]
- Context:: This is so that can filter according to the parameter if it has been passed to the proc
- Description

- Snippet 

```sql
-- Add the AND with the check or to add the conditional check to the proc query
WHERE FirstParameter = @FirstParameter
	AND (
		@Parameter = 0 OR (
			@Parameter != 0 AND (Parameter = @Parameter)
		)
	)
```

- Dependencies:: 

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Database]], [[MS Sql]]
- 📡Status:: #status/🌲 