---
uuid: 20220526080631
title: Force file download
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---

# [[Force file download]]

Some files, such as mp3, are generally played throught the client browser. If you prefer forcing download of such files, this is not a problem: The following code snippet will do that job properly.

`01.function downloadFile($file){`
`02.$file_name = $file;`
`03.$mime = 'application/force-download';`
`04.header('Pragma: public');   // required`
`05.header('Expires: 0');       // no cache`
`06.header('Cache-Control: must-revalidate, post-check=0, pre-check=0');`
`07.header('Cache-Control: private',false);`
`08.header('Content-Type: '.$mime);`

`09.header('Content-Disposition: attachment; filename="'.basename($file_name).'"');`

`10.header('Content-Transfer-Encoding: binary');`
`11.header('Connection: close');`
`12.readfile($file_name);       // push it out`
`13.exit();`
`14.}`
**» [Credit: Alessio Delmonti](http://www.tecnocrazia.com/)**

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]