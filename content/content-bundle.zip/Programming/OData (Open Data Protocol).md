---
uuid: 20230413051924
title: OData (Open Data Protocol)
created: 2023-04-13T05:19:24
updated: 2023-04-13T05:19:25
private: false
alias:
---

# [[OData (Open Data Protocol)]]

- Author:: Microsoft
- Category:: website
- URL:: [OData overview - OData | Microsoft Learn](https://learn.microsoft.com/en-us/odata/overview)
- Rating:: 5

## Learn by elaboration
- [[OData integration Generator]]
- [[Basic Authentication with OData]]

### Gets a Query Response Object to access the Count property
- [Get Response Content for Data Modification Requests - OData | Microsoft Learn](https://learn.microsoft.com/en-us/odata/client/get-response-content#query-responses)

```csharp
var context = new DefaultContainer(new Uri("https://services.odata.org/v4/TripPinServiceRW/"));
DataServiceQuery<Person> query = context.People;
// Execute the query for all customers and get the response object.
QueryOperationResponse<Person> response =
    query.Execute() as QueryOperationResponse<Person>;
```




---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/website 
- 🏷️ Tags:: [[Rest API]], [[CSharp]]
- 📡 Status:: #status/🌲 

