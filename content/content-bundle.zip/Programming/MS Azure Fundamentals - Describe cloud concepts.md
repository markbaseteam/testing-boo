---
uuid: 20221121122153
title: MS Azure Fundamentals - Describe cloud concepts
created: 2022-11-21T12:21:53
updated: 2022-11-21T12:21:53
private: true
alias:
---
Up:: [[Microsoft Certifications for Flowcentric|Microsoft Azure Certifications 2023]]

# [[MS Azure Fundamentals - Describe cloud concepts]]


- [Microsoft Azure Fundamentals: Describe cloud concepts - Training | Microsoft Learn](https://learn.microsoft.com/en-us/training/paths/microsoft-azure-fundamentals-describe-cloud-concepts/)


## What is cloud computing
- Lets you choose only the services you need 
- Compute Power - Can increase or decrease on demand
- Storage - Can increase or decrease on demand
- Providers manage upkeep

## Describe the shared responsibility model
- The responsibility is shared between the cloud provider and the consumer
- Physical security, power, cooling and connectivity is the responsibility of the provider
- Consumer is responsible for the data and information stored in the cloud. Responsible for access security
- Some items where responsibility depends on the situation
	- SQL Database 
		- Provider responsible for the patching and maintenance
		- Consumer responsible for the data being ingested
	- Virtual Machine
		- Consumer responsible for maintenance and data
![[Pasted image 20221121123438.png]]
- IaaS (Infrastructure as a Service) - Most of responsibility lies with the consumer
- SaaS - Most of responsibility lies with Provider
- PaaS - Somewhere in between

You’ll always be responsible for:

-   The information and data stored in the cloud
-   Devices that are allowed to connect to your cloud (cell phones, computers, and so on)
-   The accounts and identities of the people, services, and devices within your organization

The cloud provider is always responsible for:

-   The physical datacenter
-   The physical network
-   The physical hosts

Your service model will determine responsibility for things like:

-   Operating systems
-   Network controls
-   Applications
-   Identity and infrastructure

## Define Cloud Models
### Private Cloud
- Cloud used to deliver IT services over the internet to a single entity
### Public Cloud
- Built and maintained by a 3rd party cloud-provider
- General Public accessibility is the main difference between public and private clouds
### Hybrid Cloud
- Computing environment containing both Public and Private clouds.
- The following table highlights a few key comparative aspects between the cloud models.

| **Public cloud**                                                      | **Private cloud**                                                  | **Hybrid cloud**                                                  |
| --------------------------------------------------------------------- | ------------------------------------------------------------------ | ----------------------------------------------------------------- |
| No capital expenditures to scale up                                   | Organizations have complete control over resources and security    | Provides the most flexibility                                     |
| Applications can be quickly provisioned and deprovisioned             | Data is not collocated with other organizations’ data              | Organizations determine where to run their applications           |
| Organizations pay only for what they use                              | Hardware must be purchased for startup and maintenance             | Organizations control security, compliance, or legal requirements |
| Organizations don’t have complete control over resources and security | Organizations are responsible for hardware maintenance and updates |                                                                   |
|                                                                       |                                                                    |                                                                   |

### Multi Cloud
- Use multiple (two or more) public cloud providers
- Different features from each one
- Manage the resources and security in all environments/cloud

### Azure Arc
- Set of technologies that helps you manage your cloud environment
- Private/Public/Hybrid/Multiple environments, does not matter, it can help

### Azure VM Solution
- Lets you run VMWare workloads in Azure with seamless integration and scalability

## Describe the consumption-based model

- Two expenses
	- Capital Expenditure (CapEx)
		- One time expenditure to secure resources
		- Buying a company vehicle, building a datacenter, repaving the parking lot
	- Operational Expenditure (OpEx)
		- Spent over time for products or services.
		- Renting a convention center, leasing a vehicle
		- Cloud computing
- Cloud computing is OpEx because it operates on a consumption based model
	- Meaning if you do not use anything you do not pay anything
- Consumption Model Benefits
	- No upfront costs
	- No need to purchase and manage costly infrastructure
	- Ability to pay for more resources as needed
	- Ability to stop paying for resources that are no longer needed
- Traditional datacenters you have to estimate future requirements and stand the change to overspend more than you need or underestimate and run up costs to add resources to the datacenter
- Cloud-based model you only pay for the machines you are using not the extra capacity that cloud provider has on hand
- Cloud computing is a way to rend compute power and storage from someone else's datacenter.


# Module 2
## Describe the benefits of high availability and scalability in the cloud

### High availability
- focuses on the maximum availability of a deployed resource or service, regardless of disruptions or events that may occur.
- Need to account for service availability when architecting a solution.
- Different for each Azure services, Uptime is part of the SLA (Service Level Agreements)
### Scalability
- Benefits include
	- Ability to add / remove resources as demand on your systems go up or down
	- Not overpaying for services by reducing resources not in use
- Two varieties
	- Vertical Scaling
		- Focuses on the capabilities of the resources (cpu/ram)
		- If you under-specced the requirements you can easily add more cpu or ram
		- Conversily, you can reduce cpu or ram if you over-specced the VM.
	- Horizontal Scaling 
		- Focuses on the amount of resources
		- Can be added and removed either automatically or manually

## Describe the benefits of reliability and predictability in the cloud

### Reliability
- Ability of a system to recover and continue to function
- Cloud is naturally reliable and resilient, because of decentralized design
- Enables you to have resources in different regions around the word
- If one region has a catastrophic event, you can move to another region
- Azure can sometimes do this automatically

### Predictability
- Cost
	- Focused on the predicting or forecasting of cloud spend
	- Tools like Total Cost of Ownership or Pricing Calculator to get an estimate of potential cloud spend
- Performance
	- Predicting the resources needed for a positive customer experience
	- Autoscaling, load balancing and high availability some of the concepts that support performance predictability
	- Autoscaling adds/removes resources to meet demand
	- Load balancing helps redirect traffic to less stressed areas
- Heavily influenced by the [[MS Azure Well-Architected Framework]]
- 

## Describe the benefits of security and governance in the cloud

- Governance
	- Templates help ensure all deployed resources meet corporate standards
	- Cloud-based auditing helps flag resources that is out of compliance
	- Depending on operating model, patches and updates may also be automatically applied
- Security
	- Maximum control - IaaS
	- PaaS or SaaS to have patches and updates installed automatically
	- Cloud provider typically well suited to handle things like DDoS, making for a more robust and secure network

## Describe the benefits of manageability in the cloud

- Two types of manageability for cloud computing
- Management **of** the cloud
	- Automatically scale resources
	- Deploy resources based on templates
	- Monitor health of resources and automatically replace failing resources
	- Receive automatic alerts based on configured metrics
- Management in the cloud
	- Web Portal
	- CLI
	- APIs
	- PowerShell

# Module 3
## Describe Infrastructure as a Service
### IaaS
- Iaas most flexible category of cloud services
- Maximum control over cloud resources
- Provider only maintains hardware, security and network connectivity
- Consumer responsible for installation and configuration, patches and updates and security
- Possible scenarios:
	- Lift and Shift migration: move things running on-prem to running on the IaaS infrastructure
	- Testing and Development: You can rapidly stand up or shut down different configured testing environments that you need to replicate.
### PaaS
- Middle ground between IaaS and SaaS
- Provider maintains physical hardware, connection and physical security. The also maintain the OS, middleware, dev tool and business intelligence tools.
- Consumer does not need to worry about licensing or patching of OS and databases.
- Provides a complete development environment without the headache of maintaining all the infrastructure.
- Possible scenarios:
	- Development Framework:
		-  PaaS provides a framework developers can work upon to build or customize cloud-based applications
		- Scalability, high-availability and multi-tenant capability included, reducing the amount of coding needed
		- Create applications using built-in software components
	- Analytics or business intelligence:
		- Tools provided on PaaS lets orgs analyze and mine their data to make better business decisions

### SaaS
- Least flexible
- Easiest to get up and running with the least amount of technical expertise and knowledge
- Email, financial software, messaging applications are common SaaS implementations
- 

---
## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Microsoft Azure|Azure]] [[Cloud Computing]]
- 📡 Status:: #status/🌲 
