---
uuid: 20230530064733
title: Netlify
created: 2023-05-30T06:47:33
updated: 2023-05-30T06:47:33
private: false
alias:
---
Up:: [[Cloud Computing]]

# [[Netlify]]

A cool service for hosting your starter projects, I am using it a lot with my blog and [[GatsbyJS]].

URL:: [Develop and deploy websites and apps in record time | Netlify](https://www.netlify.com/)

---

## 📇 Additional Metadata

- 🗂 Type:: #type/resource 
- 🏷️ Tags:: [[Cloud Computing]]
- 📡 Status:: #status/🌲 
