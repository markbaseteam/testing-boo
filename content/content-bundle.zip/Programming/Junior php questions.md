---
uuid: 20220513090339
title: Junior php questions
created: "2022-05-13T09:"
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# [[Junior php questions]]


- How would you do a variable variable?

- Name as many types in php as you can:
	- Object
	- Array
	- String
	- Int
	- Resource
	- Float aka double
	- Boolean
	- Null

- What is the cause of the following warning: warning cannot modify header information headers already sent.

- Alternative syntax `for if` and `foreach`

- What is the difference between require and include

- How many time can you include a file in another php file

- Name some magic constants:
	- File
	- Dir
	- Line
	- Function
	- Class
	- Method
	- Namespace

- What do you understand when I say the inheritance:

- How would you ensure that only a certain type of parameter is passed to a function/method.

- How would you determine the key of the array value in an array.

- What is a recursive function?

- What is the difference between post and get superglobals?

- Is it necessary to close a php file with a `?>` ?

- What function will you use to replace a part of a string from the second to fifth character.

- What function would use to output a variable safely on a clients browser

- What is safest connector for mysql

- What globals would you use to authenticate a user on a website.

- What is the most used function in php?

- Do know what SPL is?

- What is the advantage of a stored procdure on mysql

- Do you know how to write a stored procedure in mysql

- What would you use to manipulate an element on the dom without jquery?

- Why is mysql the db used most with php?

- What alternatives are there to MySQL?

- Have you worked with an api before? 

- Which ones?

- What would you use to make an array a valid JSON packet?

- You work on windows, production is on Linux, what is the first thing you check if you cant file a file?

- Why php?

- What is the difference between == and ===?

- What is late static binding?


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[PHP]] [[Interviews]]
- 📡 Status:: #status/🌲 