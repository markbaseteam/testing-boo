---
uuid: 20220513104009
title: How can I do a sql compare
created: 2022-05-13T10:40:09.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

#### **Question**
[[How can I do a sql compare]]

#### **Answer**
You can use Visual Studio which has the capability to do it.

#### **Links/related reading** 
- [complete how-to](https://www.sqlshack.com/how-to-compare-two-sql-databases-from-visual-studio/)

---
Type:: #type/question-answer 
Tags:: [[T-SQL]] [[Visual Studio 2022]] 
***
