---
uuid: 20220429120639
title: Human Memory limit
created: 2022-04-29T12:06:39.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

# [[Human Memory limit]]

> [!quote]
> The average human brain has only a few shared resources for discrete quanta in [working memory](http://www.nature.com/neuro/journal/v17/n3/fig_tab/nn.3655_F2.html), and each variable potentially consumes one of those quanta. As you add more variables, our ability to accurately recall the meaning of each variable is diminished. Working memory models typically involve **4–7 discrete quanta**. Above those numbers, error rates dramatically increase.

Type:: #type/quote 
Source:: #source/article 
Tags:: Composing Software Introduction Eric Elliot Medium.com

---