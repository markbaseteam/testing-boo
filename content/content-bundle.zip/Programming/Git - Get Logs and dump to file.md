---
uuid: 20221130111606
title: Git - Get Logs and dump to file
created: 2022-11-30T11:16:06
updated: 2022-11-30T11:16:55
private: true
alias:
---

# [[Git - Get Logs and dump to file]]

- Language:: [[Git]] [[Command Line]]
- Type:: [[Git]]
- Context:: Gets a log of the current repo and dumps it into a log file
- Description 

- Snippet 
- Get Logs:
```shell
$ git log --color --graph --pretty --name-status > logtest.txt
```
- format logs (Use pattern to delete unwanted char in file):
```regex
\[[\d]+m|\[m|\[1;[\d]+m
```
- Dependencies:: –

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[DevOps]]
- 📡Status:: #status/🌲 
