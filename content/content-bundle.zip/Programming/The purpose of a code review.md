---
uuid: 20220607203410
title: The purpose of a code review
created: 2022-06-07T20:34:10.000Z
updated: 2022-06-09T16:15:28.342Z
private: true
alias: null
---

# [[The purpose of a code review]]

>[!quote] Why do we do Code Reviews?
  Code review is simply what it says on the tin. It is the opportunity for other developers to look at your code commit and review it.
  Code reviews are one of the key elements to the development lifecycle. Without them poor or buggy code could make it's way into UAT and slow down the testing / release process. ([View Highlight](https://instapaper.com/read/1507273537/19667858))
- Can be two-fold, assigning a junior to a code review, can help them see what to do in some situations, a senior can always learn something new from a junior
- It also ensures that poor (inefficient) or potentially buggy code does not make it into the code base.

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[My Opinion on What Makes a Good Code Review.]]
- Tags:: [[Code Review]]
- Status:: #status/🌲 