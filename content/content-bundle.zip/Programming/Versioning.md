---
uuid: 20220726102735
title: Versioning
created: 2022-07-26T10:27:35
updated: 2022-07-26T10:27:35
private: true
alias:
---

# [[Versioning]]

The way software is normally and incrementally kept track of improvements and added functionality.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Programming]]
- 📡 Status:: #status/🌲 
