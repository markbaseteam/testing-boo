---
uuid: 20220516033952
title: Maintenance mode with PHP
created: 2022-05-16T03:39:52.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# [[Maintenance mode with PHP]]
- Language:: [[PHP]]
- Type:: [[Back-end]]
- Context:: When you have to maintenance on your site

When updating your site, it is generally a good thing to temporarily redirect your users to a “Maintenance” page so they will not see any critical info such as error messages.

This is generally done using an .htaccess file, but it can be done easily with PHP:
```php
`01.``function`  `maintenance(``$mode`  `= FALSE){`
`02.``if``(``$mode``){`

`03.``if``(``basename``(``$_SERVER``[``'SCRIPT_FILENAME'``]) != ``'maintenance.php'``){`

`04.``header(``"Location: http://example.com/maintenance.php"``);`
`05.``exit``;`
`06.``}`
`07.``}``else``{`

`08.``if``(``basename``(``$_SERVER``[``'SCRIPT_FILENAME'``]) == ``'maintenance.php'``){`

`09.``header(``"Location: http://example.com/"``);`
`10.``exit``;`
`11.``}`
`12.``}`
`13.``}`
```

- Dependencies:: – link to any other code or packages that are relevant or that you need to use this snippet

----
## 📇Additional Metadata

- Type:: #type/snippet
- **Source: http://www.phpsnippets.info/easy-maintenance-mode-with-php**