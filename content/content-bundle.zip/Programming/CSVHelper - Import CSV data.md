---
uuid: 20220429120639
title: CSVHelper - Import CSV data
created: 2022-04-29T12:06:39.000Z
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---

# [[CSVHelper - Import CSV data]]
Language:: [[CSharp]] 
Type:: [[Back-end]]
Context:: Utility function for CSV

Description:: A generic method to get the typed data from a csv file

Snippet:

```csharp
public class CsvHelper
    {
        public IEnumerable<T> GetRecords<T>(TextReader reader)
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                PrepareHeaderForMatch = args =>
                {
                    var emptyChar = "";
                    return args.Header.Replace(" ", emptyChar).Replace(".", emptyChar);
                },
                HeaderValidated = null,
                MissingFieldFound = null
            };

            using (var csv = new CsvReader(reader, config))
            {
                var records = csv.GetRecords<T>();
                return records.ToList<T>();
            }

        }
    }
```

* Dependencies:
	* https://www.nuget.org/packages/CsvHelper/
	* https://joshclose.github.io/CsvHelper/getting-started/

***
Type:: #type/snippet
