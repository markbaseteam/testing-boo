---
uuid: 20220524094427
title: Data Transfer Object (DTO)
created: 2022-05-24T09:44:27.000Z
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---

# [[Data Transfer Object (DTO)]]

> A DTO is a "Data Transfer Object". It's an object whose purpose is to transfer data. By definition, a DTO should only contain data, not logic or behavior. **If a DTO contains logic, it is not a DTO.** But wait, what is "logic" or "behavior"? Generally, logic and behavior refer to methods on the type. In C#, a **DTO should only have properties**, and those properties should only get and set data, not validate it or perform other operations on it.

```csharp
public class ProductViewModel
{
  public int ProductId { get; set; }
  public string Name { get; set; }
  public string Description { get; set; }
  public string ImageUrl { get; set; }
  public decimal UnitPrice { get; set; }
}
```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- Language:: [[CSharp]] [[CSharp]]
- 
