---
uuid: 20220913045213
title: Basic Authentication with OData
created: 2022-09-13T04:52:13
updated: 2022-09-13T04:52:13
private: true
alias:
---

Up:: [[OData (Open Data Protocol)]]

# [[Basic Authentication with OData]]

- Author:: Microsoft
- Category:: website
- URL:: [OData and Authentication – Part 6 – Custom Basic Authentication - OData (microsoft.com)](https://devblogs.microsoft.com/odata/odata-and-authentication-part-6-custom-basic-authentication/)
- Rating:: how effective this resource is at solving your problem or teaching you something

## Learn by elaboration

#### [Using the request headers directly](https://devblogs.microsoft.com/odata/odata-and-authentication-part-6-custom-basic-authentication/#using-the-request-headers-directly)

Another option is to just create and send the authentication header yourself.

1) Hook up to the DataServiceContext’s SendingRequest Event:
```csharp
ctx.SendingRequest +=new EventHandler<SendingRequestEventArgs>(OnSendingRequest);
```

2) Add the Basic Authentication Header to the request:
```csharp
static void OnSendingRequest(object sender, SendingRequestEventArgs e)  
{  
  var creds = “user” + “:” + “password”;  
  var bcreds = Encoding.ASCII.GetBytes(creds);  
  var base64Creds = Convert.ToBase64String(bcreds);   
  e.RequestHeader.Add(“Authorization”, “Basic ” + base64Creds);     
}
```

As you can see this is pretty simple. And has the advantage that it will work even if the server doesn’t respond with a challenge (i.e. WWW-Authenticate header).

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source
- 🏷️ Tags:: [[OData]], [[CSharp]], 
- 📡 Status:: #status/🌲 

