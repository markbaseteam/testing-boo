---
uuid: 20221122111933
title: MS Azure Fundamentals - Describe Azure architecture and services
created: 2022-11-22T11:19:33
updated: 2022-11-22T11:19:33
private: true
alias:
---

# [[MS Azure Fundamentals - Describe Azure architecture and services]]


- [Azure Fundamentals: Describe Azure architecture and services - Training | Microsoft Learn](https://learn.microsoft.com/en-us/training/paths/azure-fundamentals-describe-azure-architecture-services/)



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌱 
