---
uuid: 20230224075413
title: Open Source Society University
created: 2023-02-24T07:54:13
updated: 2023-02-24T07:54:13
private: false
alias:
---

# [[Open Source Society University]]

- Author:: the original author of the resource
- Category:: course
- URL:: https://github.com/ossu/computer-science
- Rating:: 3

## Learn by elaboration
- An open source [[Computer Science]] Course to let you get the degree without the immense financial impact.
- Not recognized as yet
- 

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/website 
- 🏷️ Tags::
- 📡 Status:: #status/🌲 

