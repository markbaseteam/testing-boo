---
uuid: 20220609101007
title: How to enable modules in Apache2 _ VIRTUALISTIC
created: "2022-06-09T10:"
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---


add it the [debian](http://www.debian.org) way with a2enmod:
sudo a2enmod
Which module would you like to enable?
Your choices are: actions asis auth_anon auth_dbm auth_digest auth_ldap
cache cern_meta cgid cgi dav_fs dav deflate disk_cache expires
ext_filter file_cache headers imap include info ldap mem_cache
mime_magic php5 proxy_connect proxy_ftp proxy_http proxy rewrite speling
ssl suexec unique_id userdir usertrack vhost_alias
Module name? mime_magic
Module mime_magic installed; run /etc/init.d/apache2 force-reload to
enable.