---
uuid: 20220510053707
title: Difference between Features and Epics
created: 2022-05-10T05:37:07.000Z
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---

#### Question
- What is the difference between epics and features

#### Answer

The epics and features that you create should reflect your business focus. As user stories or product backlog items roll up into features, and features roll up into epics—you'll want to name your features and epics with that in mind.

Typically, a feature is a shippable software component. An epic is a business initiative you want to accomplish. Here are a few examples of each.

**Features**

-   Add view options to the new work hub
-   Add mobile shopping cart
-   Support text alerts
-   Refresh the web portal with new look and feel

**Epics**

-   Increase customer engagement
-   Improve and simplify the user experience
-   Implement new architecture to improve performance
-   Engineer the application to support future growth
-   Support integration with external services
-   Support mobile apps


#### **Links/related reading** 
* https://docs.microsoft.com/en-us/azure/devops/boards/backlogs/define-features-epics


---

Type:: #type/question-answer
Tags:: [[Agile]], [[Azure DevOps]]

