---
uuid: 20220726102638
title: Visual Studio 2022
created: 2022-07-26T10:26:38
updated: 2022-07-26T10:26:38
private: false
alias:
---

# [[Visual Studio 2022]]

IDE for developing [[CSharp]] and [[DotNet]] Applications

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[CSharp]]
- 📡 Status:: #status/🌲 
