---
uuid: 20220624070151
title: HTTP Header-based versioning in ASP.NET Core
created: 2022-06-24T07:01:51
updated: 2022-06-24T07:01:51
private: false
alias:
---

# [[HTTP Header-based versioning in ASP.NET Core]]

## HTTP Header-Based Versioning
  In this type, we have to send the version in the Http header when we call the controller. So open the `Startup.cs` and add the below line of code into `services.AddApiVersioning` method. Also, delete the version mentioned in routes.
  
```csharp
  public void ConfigureServices(IServiceCollection services)
  {
	  services.AddControllers();
	  services.AddApiVersioning(x =>
	  {
		  x.DefaultApiVersion = new ApiVersion(1, 0);
		  x.AssumeDefaultVersionWhenUnspecified = true;
		  x.ReportApiVersions = true;
		  x.ApiVersionReader = new HeaderApiVersionReader("x-api-version");
	  });
  }
```
  Now enable the Http herder versioning type. When a client consumes the API, they have so send `x-api-version` into the header with specific version value to call the correct controller. ([View Highlight](https://instapaper.com/read/1508520253/19878901))

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[API Versioning in ASP.NET Core]]
- Status::
- Tags::