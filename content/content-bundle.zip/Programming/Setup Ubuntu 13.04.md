---
uuid: 20220429120633
title: Setup Ubuntu 13.04
created: 2022-04-29T12:06:33.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[Setup Ubuntu 13.04]]


https://www.digitalocean.com/community/articles/how-to-install-linux-apache-mysql-php-lamp-stack-on-ubuntu

http://www.technoreply.com/how-to-install-sublime-text-2-on-ubuntu-12-04-unity/
http://askubuntu.com/questions/172698/how-do-i-install-sublime-text-2

http://askubuntu.com/questions/172698/how-do-i-install-sublime-text-2
Filesync
Emmet
Sidebarenhancements

http://askubuntu.com/questions/261394/apache-could-not-reliably-determine-server

http://askubuntu.com/questions/48362/how-to-enable-mod-rewrite-in-apache

XDebug:
http://ubuntuforums.org/showthread.php?t=525257

Type:: #type/link 
