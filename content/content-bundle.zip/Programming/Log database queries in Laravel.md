---
uuid: 20220622165717
title: Log queries in Laravel
created: 2022-06-22T16:57:17
updated: 2022-06-22T16:57:17
private: true
alias:
---

# [[Log database queries in Laravel]]

- Language:: [[PHP]]
- Type:: [[Back-end]]
- Context:: Log db queries in [[Laravel]]
- Description – a text-based description of the snippet

- Snippet – 

```php
use Illuminate\Support\Facades\DB;


public function UserController()
{

    DB::enableQueryLog();
    $arr_user = DB::table('users')->select('name', 'email as user_email')->get();
    dd(DB::getQueryLog());
}
```

- Dependencies:: [How to Log Query in Laravel - Artisans Web](https://artisansweb.net/how-to-log-query-in-laravel/)

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Laravel]], [[PHP]]
- 📡Status:: #status/🌲 