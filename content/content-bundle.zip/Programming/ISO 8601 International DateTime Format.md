---
uuid: 20220429120640
title: ISO 8601 International DateTime Format
created: 2022-04-29T12:06:40.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

# [[ISO 8601 International DateTime Format]]

Source:: #source/article 
URL:: [Wikipedia](https://en.wikipedia.org/wiki/ISO_8601)
Status:: #status/🌲
Tags:: DateTime, International Standard
Rating:: 5

Type:: #type/resource
*** 