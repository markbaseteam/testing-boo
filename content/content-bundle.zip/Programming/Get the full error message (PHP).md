---
uuid: 20220429120643
title: Get the full error message (PHP)
created: 2022-04-29T12:06:43.000Z
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---

# [[Get the full error message (PHP)]]

Language:: [[PHP]] 
Type:: [[Back-end]] 
Context:: error handling
Description:: Display a complete error when working in a development environment

Snippet:

```php
protected function _getFullErrorMessage($error)
{
	if (APPLICATION_ENV != 'development')
	{
		return '';
	}
	$message = '';
	if (!empty($_SERVER['SERVER_ADDR'])) {
		$message .= "Server IP: " . $_SERVER['SERVER_ADDR'] . "n";
	}
	if (!empty($_SERVER['HTTP_USER_AGENT'])) {
		$message .= "User agent: " . $_SERVER['HTTP_USER_AGENT'] . "n";
	}
	if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
		$message .= "Request type: " . $_SERVER['HTTP_X_REQUESTED_WITH'] . "n";
	}
	$message .= "Server time: " . date("Y-m-d H:i:s") . "n";
	$message .= "RequestURI: " . $error->request->getRequestUri() . "n";
	if (!empty($_SERVER['HTTP_REFERER'])) {
		$message .= "Referer: " . $_SERVER['HTTP_REFERER'] . "n";
	}
	$message .= "Message: " . $error->exception->getMessage() . "nn";
	$message .= "Trace:n" . $error->exception->getTraceAsString() . "nn";
	
	$message .= "Request data: " . var_export($error->request->getParams(), true) . "nn";
	
	$it = $_SESSION;
	$message .= "Session data:nn";
	foreach ($it as $key => $value) {
		$message .= $key . ": " . var_export($value, true) . "n";
	}
	$message .= "n";
	$message .= "Cookie data:nn";
	foreach ($_COOKIES as $key => $value) {
		$message .= $key . ": " . var_export($value, true) . "n";
	}
	$message .= "n";
	return '< pre>' . $message . '< / pre>';
}

```

Dependencies:: – link to any other code or packages that are relevant or that you need to use this snippet


Type:: #type/snippet
