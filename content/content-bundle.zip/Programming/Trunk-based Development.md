---
uuid: 20230501100957
title: Trunk-based Development
created: 2023-05-01T10:09:57
updated: 2023-05-01T10:09:57
private: false
alias:
---

# [[Trunk-based Development]]

- Author:: Atlassian
- Category:: article
- URL:: [Trunk-based Development | Atlassian](https://www.atlassian.com/continuous-delivery/continuous-integration/trunk-based-development)
- Rating:: 4

## Learn by elaboration
- The new and more accepted way of working with a mature DevOps pipeline where the [[Continuous Integration and Continuous Delivery|CI/CD]] is up to scratch
- 

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/article 
- 🏷️ Tags:: [[Git]]
- 📡 Status:: #status/🌲 

