---
uuid: 20220429120811
title: Create table template for Processware Database
created: 2022-04-29T12:08:11.000Z
updated: 2022-06-09T16:15:28.337Z
private: true
alias: null
---

# [[Create table template for Processware Database]]
Language:: [[T-SQL]] 
Type:: [[Back-end]] [[Persistence]] 
Context:: Standard database script to create a table with standard columns. 
- [[ProcessWare 2019]]
- [[Upsert stored procedure template  for ProcessWare database]]
- [[Generate Stored Procs with Standards]]

Snippet 

```sql
CREATE TABLE TABLE_NAME (
	ID bigint NOT NULL IDENTITY(1,1),
	ProcessID BIGINT NOT NULL,
	-- Additional Columns
	
	-- Standard Columns
	CreatedDate DATETIME DEFAULT GetDate(),
	CreatedBy BIGINT NOT NULL,
	ModifiedDate DATETIME NULL,
	ModifiedBy BIGINT NULL,
	IsActive BIT NOT NULL DEFAULT (1),
	
	CONSTRAINT PK_TABLE_NAME PRIMARY KEY (ID)
)
```

Dependencies:: [[MS Sql]]

Type:: #type/snippet



