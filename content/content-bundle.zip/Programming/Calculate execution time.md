---
uuid: 20220515085158
title: Calculate execution time
created: 2022-05-15T08:51:58.000Z
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---
## Calculate execution time

Language:: [[PHP]] 
Type:: [[Back-end]] 

For debugging purposes, it is a good thing to be able to calculate the execution time of a script. This is exactly what this piece of code can do.

```php
//Create a variable for start time
$time_start  = microtime(true);

// Place your PHP/HTML/JavaScript/CSS/Etc. Here

//Create a variable for end time
$time_end  = microtime(true);
//Subtract the two times to get seconds
$time  = $time_end  - $time_start;

echo  'Script took '.$time.' seconds to execute';
```


Type:: #type/snippet 
**Source: http://phpsnips.com/snippet.php?id=26**