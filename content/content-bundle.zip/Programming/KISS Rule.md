---
uuid: 20220520090926
title: KISS Rule
created: 2022-05-20T09:09:26.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias:
  - KISS
---

# [[KISS Rule]]

- Keep
- It
- Simple
- Stupid

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- [[Programming]] [[Paradigms]]
