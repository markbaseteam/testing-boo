---
uuid: 20220701060212
title: How Senior Programmers ACTUALLY write code
created: 2022-07-01T06:02:12
updated: 2022-07-01T06:02:22
private: false
alias:
---

# [[How Senior Programmers ACTUALLY write code]]

- Author:: [Healthy Software Developer](https://www.youtube.com/c/JaymeEdwardsMedia)
- Category:: video
- URL:: https://www.youtube.com/watch?v=oJbfMBROEO0
- Status:: #status/🌿 
- Tags:: 
- Rating:: 


- [02:19](https://www.youtube.com/watch?v=oJbfMBROEO0#t=139.011636) Prevent Unfinished Work
	- Ensure that your work is actually finished.
	- Do not say that you are done, thinking that you can go back at a later stage, because chances are, that you will not be able with other work coming in.
- [03:50](https://www.youtube.com/watch?v=oJbfMBROEO0#t=230.91858678955455) Enforce Coding standards
	- Consistancy in the code is way better than every developer on the team having there own coding standards.
	- There are a bunch of tools that could enforce [[Coding Standards]] with plugins and the like.



- [05:20](https://www.youtube.com/watch?v=oJbfMBROEO0#t=320.090979) Document Chosen Patters
- [08:10](https://www.youtube.com/watch?v=oJbfMBROEO0#t=490.431832) Review New Patters Early
- [09:41](https://www.youtube.com/watch?v=oJbfMBROEO0#t=581.567836) Never Expose Refactoring
	- Exposing refactoring can allow management to remove it from the list
	- Developers have the responsibility to ensure management does not screw up the project
	- Discuss between each other to agree to 
		- Refactor within other works
		- Adding extra time to the task so the refactoring can happen.
- [11:29](https://www.youtube.com/watch?v=oJbfMBROEO0#t=689.861682) Assume Unexpected Change
	- There is **ALWAYS, ALWAYS** unexpected things that will happen when working on code.
	- By adding time ahead of time, you will be able to cater for these unexpected changes.
	- By raising unexpected changes and keep adding work to the tracker/board for these unexpected changes/documentation, you **will** start getting micro managed.


---
## 📇Additional Metadata
- 📁Type:: #type/resource 
- Source:: #source/video 

