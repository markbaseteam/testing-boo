---
uuid: 20220429120627
title: Laravel create db table
created: 2022-04-29T12:06:27.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---

# Laravel create db table

- `php artisan make:migration create_table`
- update newly created table with columns needed
- `php artisan migrate`
- generate seed
- `php artisan make:seeder TableSeeder`
- Add records to table
```php 
  DB::table('table')->insert([
		'name' => Str::random(10),
		'email' => Str::random(10).'@gmail.com',
		'password' => Hash::make('password'),
	]);
```
- `composer dump-autoload -o`
- `php artisan db:seed --class=TableSeeder`
***

- https://laravel.com/docs/9.x/migrations#creating-tables

Type:: #type/note 
Language:: [[PHP]] 
Framework:: #framework/laravel