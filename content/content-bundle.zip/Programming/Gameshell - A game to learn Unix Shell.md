---
uuid: 20220727074447
title: Gameshell - A game to learn Unix Shell
created: 2022-07-27T07:44:47
updated: 2022-07-27T07:44:47
private: true
alias:
---

# [[Gameshell - A game to learn Unix Shell]]

- Author:: the original author of the resource
- Category:: course
- URL:: https://github.com/phyver/GameShell
- Rating:: Not Rated

## Learn by elaboration

- Teaching first-year university students or high schoolers to use a Unix shell is not always the easiest or most entertaining of tasks. GameShell was devised as a tool to help students at the [Université Savoie Mont Blanc](https://univ-smb.fr) to engage with a _real_ shell, in a way that encourages learning while also having fun.
- The original idea, due to Rodolphe Lepigre, was to run a standard bash session with an appropriate configuration file that defined "missions" which would be "checked" in order to progress through the game.

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/course 
- 🏷️ Tags:: [[Unix]], [[Shell]]
- 📡 Status:: #status/🌲 

