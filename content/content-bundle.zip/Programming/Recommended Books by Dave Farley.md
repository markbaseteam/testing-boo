---
uuid: 20220429100633
title: Books
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---

# [[Recommended Books by Dave Farley]]

>[!note]   This was taken from a youtube video description by Dave Farley, just can't remember which one, I'll link to it then

BOOKS:

🚨 MY NEW BOOK! 👉 📖 Dave’s NEW BOOK "Modern Software Engineering" is now available on Amazon ➡️ https://amzn.to/3DwdwT3
In this book, Dave brings together his ideas and proven techniques to describe a durable, coherent and foundational approach to effective software development, for programmers, managers and technical leads, at all levels of experience.

📖 "Continuous Delivery Pipelines" by Dave Farley
paperback ➡️ https://amzn.to/3gIULlA
ebook version ➡️ https://leanpub.com/cd-pipelines

📖 The original, award-winning "Continuous Delivery" book by Dave Farley and Jez Humble 
➡️ https://amzn.to/2WxRYmx

- Domain Driven Design, by Eric Evans ➡️ https://amzn.to/2WXJ94m
- Specification By Example, by Gojko Adzic ➡️ https://amzn.to/2TlfYaH
- Growing Object Oriented Software Guided by Tests, By Nat Price & Steve Freeman ➡️ https://amzn.to/2Lt3jho
- Accelerate, The Science of Lean Software and DevOps, by Nicole Fosgren, Jez Humble & Gene Kim ➡️ https://amzn.to/2YYf5Z8
- The Phoenix Project, by Gene Kim ➡️ https://amzn.to/3csuuop
- Infrastructure As Code ➡️ https://amzn.to/3ppZXxJ
- Refactoring: Improving the Design of Existing Code (Addison-Wesley Signature Series (Fowler)) ➡️ https://amzn.to/30ntgaK
- Test Driven Development: By Example (The Addison-Wesley Signature Series), Kent Beck ➡️ https://amzn.to/2NcqgGh
- Fifty Quick Ideas to Improve Your User Stories - Gojko Adzic ➡️ https://amzn.to/3jXM481
- Team Topologies - Matthew Skelton & Manuel Pais ➡️ https://amzn.to/2Y0NdSO
- Refactoring Databases: Evolutionary Database Design Scott Ambler & Pramod Sadalage ➡️ https://amzn.to/36BjHrT
- Building Microservices: Designing Fine-Grained Systems, by Sam Newman ➡️ https://amzn.to/31PyXOS
- Extreme Programming Explained: Embrace Change, Kent Beck ➡️ https://amzn.to/2GpQRjE
- Impact Mapping: Making a big impact with software products and projects, Gojko Adzic ➡️ https://amzn.to/3gs3PL8
- Release It!, Michael Nygard ➡️ https://amzn.to/38zrINu
- Mythical Man-Month, The: Essays on Software Engineering, Anniversary Edition ➡️ https://amzn.to/3oCyPeU
- The Beginning of Infinity: Explanations That Transform the World, David Deutsch ➡️ https://amzn.to/2MrOEqA
- Clean Code: A Handbook of Agile Software Craftsmanship (Robert C. Martin) (Robert C. Martin Series) ➡️ https://amzn.to/3aLXGad
- Rapid Development: Taming Wild Software Schedules, by Steve McConnell ➡️ https://amzn.to/38OKgtP
- The Pragmatic Programmer: your journey to mastery, 20th Anniversary Edition ➡️ https://amzn.to/3EdXvBm

> [!note] NOTE: 
> Some of the above are 'Affiliate Links', which means that we get a very small fee if you buy one of these books using the link, but it does not increase the cost to you.

-------------------------------------------------------------------------------------


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Reading MOC]] 
- 📡 Status:: #status/🌲 
