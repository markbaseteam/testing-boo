---
uuid: 20220429120642
title: Programming Cartoons
created: 2022-04-29T12:06:42.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[Programming Cartoons]]

[XKCD](https://xkcd.com/):

![7ce99bc5c30a3eb6f42b387b78bcdbd8.png](../../_resources/7ce99bc5c30a3eb6f42b387b78bcdbd8.png)

[Commitstrip](https://www.commitstrip.com/en/):

![2d37ebddcdbc7ae2b1eb97b7f1b75048.png](../../_resources/2d37ebddcdbc7ae2b1eb97b7f1b75048.png)

----
Type:: #type/link 

