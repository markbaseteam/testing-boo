---
uuid: 20230530043945
title: Cloud Computing
created: 2023-05-30T04:39:45
updated: 2023-05-30T04:39:45
private: false
alias:
---

# [[Cloud Computing]]

## Providers
- [[Microsoft Azure]]

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: 
- 📡 Status:: #status/🌲 
