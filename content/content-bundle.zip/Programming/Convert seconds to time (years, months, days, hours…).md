---
uuid: 20220526080631
title: Convert seconds to time (years, months, days, hours…)
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---

# [[Convert seconds to time (years, months, days, hours…)]]

This useful function will convert a time in seconds to a time in years, months, weeks, days, and so on.

`01.function Sec2Time($time){`
`02.if(is_numeric($time)){`
`03.$value = array(`
`04."years" => 0, "days" => 0, "hours" => 0,`
`05."minutes" => 0, "seconds" => 0,`
`06.);`
`07.if($time >= 31556926){`
`08.$value["years"] = floor($time/31556926);`
`09.$time = ($time%31556926);`
`10.}`
`11.if($time >= 86400){`
`12.$value["days"] = floor($time/86400);`
`13.$time = ($time%86400);`
`14.}`
`15.if($time >= 3600){`
`16.$value["hours"] = floor($time/3600);`
`17.$time = ($time%3600);`
`18.}`
`19.if($time >= 60){`
`20.$value["minutes"] = floor($time/60);`
`21.$time = ($time%60);`
`22.}`
`23.$value["seconds"] = floor($time);`
`24.return (array) $value;`
`25.}else{`
`26.return (bool) FALSE;`
`27.}`
`28.}`
**» [Credits](http://ckorp.net/sec2time.php)**

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]