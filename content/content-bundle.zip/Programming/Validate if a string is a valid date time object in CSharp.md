---
uuid: 20221109051457
title: Validate if a string is a valid date time object in CSharp
created: 2022-11-09T05:14:57
updated: 2022-11-09T05:14:57
private: false
alias:
---

# [[Validate if a string is a valid date time object in CSharp]]

- Language:: [[CSharp]]
- Type:: [[Back-end]]
- Context:: Validate if a string is a valid DateTime object
- Description – a text-based description of the snippet

- Snippet

```csharp
DateTime value;
if (!DateTime.TryParse(startDateTextBox.Text, out value))
{
    startDateTextox.Text = DateTime.Today.ToShortDateString();
}
```

- Dependencies::

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[CSharp]]
- 📡Status:: #status/🌲 