---
uuid: 20220526080631
title: Basic PHP whois
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---

# [[Basic PHP whois]]

Whois services are extremely useful to get basic information about a domain name: owner, creation date, registrar, etc. Using PHP and the `whois` unix command, it is extremely easy to create a basic whois PHP function. Please note that the `whois` unix command must be installed on your server for this code to work.

`01.$domains = array('home.pl', 'w3c.org');`
`02.`
`03.function creation_date($domain) {`
`04.$lines = explode("\n", whois $domain);`
`05.foreach($lines as $line) {`
`06.if(strpos(strtolower($line), 'created') !== false) {`
`07.return $line;`
`08.}`
`09.}`
`10.`
`11.return false;`
`12.}`
`13.`
`14.foreach($domains as $d) {`
`15.echo creation_date($d) . "\n";`
`16.}`
**» [Credits: Snipplr](http://snipplr.com/view.php?codeview&id=48040)**

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]