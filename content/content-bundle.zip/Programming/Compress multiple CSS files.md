---
uuid: 20220515065158
title: Compress multiple CSS files
created: "2022-05-15T06:"
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---
## [[Compress multiple CSS files]]

If you’re using different CSS files on your site, they might take quite long to load. Using PHP, you can compress them into a single file with no unnecessary white spaces or comments.

This snippet has been previously discussed on my “[3 ways to compress CSS files using PHP](http://www.catswhocode.com/blog/3-ways-to-compress-css-files-using-php)” article.

```php

`01.``header(``'Content-type: text/css'``);`
`02.``ob_start(``"compress"``);`
`03.``function`  `compress(``$buffer``) {`
`04.``/* remove comments */`

`05.``$buffer`  `= preg_replace(``'!/\*[^*]*\*+([^/][^*]*\*+)*/!'``, ``''``, ``$buffer``);`

`06.``/* remove tabs, spaces, newlines, etc. */`

`07.``$buffer`  `= ``str_replace``(``array``(``"\n"``, ``""``, ``"\n"``, ``"\t"``, ``'  '``, ``'    '``, ``'    '``), ``''``, ``$buffer``);`

`08.``return`  `$buffer``;`
`09.``}`
`10.`
`11.``/* your css files */`
`12.``include``(``'master.css'``);`
`13.``include``(``'typography.css'``);`
`14.``include``(``'grid.css'``);`
`15.``include``(``'print.css'``);`
`16.``include``(``'handheld.css'``);`
`17.`
`18.``ob_end_flush();`
```

**Source: http://www.phpsnippets.info/compress-css-files-using-php**


---

## 📇 Additional Metadata

- 🗂 Type:: #type/snippet 
- 🏷️ Tags:: [[PHP]]
- 📡 Status:: #status/🌲 