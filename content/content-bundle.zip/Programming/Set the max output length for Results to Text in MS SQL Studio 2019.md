---
uuid: 20220919091444
title: Set the max varchar length in MS SQL Studio 2019
created: 2022-09-19T09:14:44
updated: 2022-09-19T09:14:44
private: true
alias:
---

# [[Set the max output length for Results to Text in MS SQL Studio 2019]]


- Tools->Options 
- Query Results -> SQL Server -> Results to Text
- Maximum number of characters displayed in each column: 2097152

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Sql Server]], [[Sql Server Management Studio]]
- 📡 Status:: #status/🌲 
