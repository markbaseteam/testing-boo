---
uuid: 20220515075724
title: Check if a string starts with a specific pattern
created: 2022-05-15T07:57:24.000Z
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---
## Check if a string starts with a specific pattern
Language:: [[PHP]] 
Type:: #type/snippet [[Back-end]] 

Some languages such as Java have a startWith method/function which allows you to check if a string starts with a specific pattern. Unfortunately, PHP does not have a similar built-in function.

Whatever- we just have to build our own, which is very simple:
`1.``function`  `String_Begins_With(``$needle``, ``$haystack`  `{`

`2.``return`  `(``substr``(``$haystack``, 0, ``strlen``(``$needle``))==``$needle``);`

`3.``}`
**Source: http://snipplr.com/view.php?codeview&id=2143**