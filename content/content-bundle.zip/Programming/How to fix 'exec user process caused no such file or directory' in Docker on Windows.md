---
uuid: 20220523161032
title: How to fix 'exec user process caused no such file or directory' in Docker
  on Windows
created: 2022-05-23T16:10:32.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

#### **Question**
[[How to fix 'exec user process caused no such file or directory' in Docker on Windows]]

#### **Answer**
The issue is the Line breaks in the [[Dockerfile]]
- Make sure that it is LF and not CRLF

#### **Links/related reading** 
- https://www.koskila.net/how-to-fix-exec-user-process-caused-no-such-file-or-directory-in-docker-on-windows/

---
## 📇Additional Metadata
Type:: #type/question-answer 
Tags:: [[Docker]], error, fix, [[Windows 10]]


