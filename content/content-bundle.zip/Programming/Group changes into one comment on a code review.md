---
uuid: 20220607203315
title: Group changes into one comment on a code review
created: 2022-06-07T20:33:15
last-modified: 2022-06-07T20:33:15
private: true
alias:
---

# [[Group changes into one comment on a code review]]

> [!quote] Multiple changes of the same kind.
  Rather than commenting every single occurrence of the problem (this can be overwhelming for coders. Simply add one comment and explain the issue occurs throughout multiple files, and suggest finding all occurrences and updating, e.g a spelling mistake, or repeated code. ([View Highlight](https://instapaper.com/read/1507273537/19667843))

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[My Opinion on What Makes a Good Code Review.]]
- Tags:: [[Code Review]]