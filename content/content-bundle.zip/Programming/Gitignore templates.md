---
uuid: 20220509081245
title: Gitignore templates
created: 2022-05-09T08:12:45.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

# [[Gitignore templates]]

Author:: [[Github]]
Category:: website
URL:: [GitHub - github/gitignore: A collection of useful .gitignore templates](https://github.com/github/gitignore)
Status:: #status/🌲 
Tags:: [[Git]] 
Rating:: 5

*** 
Type:: #type/resource 
Source:: #source/website

