---
uuid: 20220725075939
title: Lexical Scope in JavaScript – Beginner's Guide
created: 2022-07-25T07:59:39
updated: 2022-07-25T07:59:46
private: false
alias:
---

# [[Lexical Scope in JavaScript – Beginner's Guide]]

- Author:: [[freecodecamp.org]]
- Category:: article
- URL:: [ https://www.freecodecamp.org/news/lexical-scope-in-javascript/](https://www.freecodecamp.org/news/lexical-scope-in-javascript/)
- Rating:: 4

## Learn by elaboration

- Lexical Scope is the process of assigning scope for the variables/functions in the parsing phase in runtime. There are 2 phases to any language, parsing and execution.
- When reading a variable, the compiler first checks the current scope, then the parent, then the parents parent until it hits global scope, which, if there is no definition of the variable/function, an error is thrown.


---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/article 
- 🏷️ Tags:: [[Javascript]], [[Programming]]
- 📡 Status:: #status/🌲 