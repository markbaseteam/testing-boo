---
uuid: 20220726103201
title: Python
created: 2022-07-26T10:32:01
updated: 2022-07-26T10:32:01
private: false
alias:
---

# [[Python]]

Link::


---

## 📇 Additional Metadata

- 🗂 Type:: #type/source 
- 🏷️ Tags:: [[Programming]]
- 📡 Status:: #status/🌲 
