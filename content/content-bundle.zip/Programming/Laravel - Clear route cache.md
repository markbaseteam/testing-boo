---
uuid: 20230522174956
title: laravel clear route cache
created: 2023-05-22T17:49:56
updated: 2023-05-22T17:49:56
private: false
alias:
---

# [[Laravel - Clear route cache]]

- Language:: [[Laravel]]
- Type:: [[Back-end]]
- Context:: Commands for resetting routes after adding a new route

- Snippet 

```php
php artisan cache:clear
php artisan route:cache
```

- Dependencies:: [How to clear Laravel route caching on server - Stack Overflow](https://stackoverflow.com/questions/37878951/how-to-clear-laravel-route-caching-on-server)

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Laravel]] 
- 📡Status:: #status/🌲 