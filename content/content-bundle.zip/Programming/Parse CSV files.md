---
uuid: 20220516033953
title: Parse CSV files
created: 2022-05-16T03:39:53.000Z
updated: 2022-06-09T16:15:28.340Z
private: true
alias: null
---
## Parse CSV files
Language:: [[PHP]] 
Type:: #type/snippet [[Back-end]] 

Description:: CSV (Coma separated values) files are an easy way to store data, and parsing them using PHP is dead simple. Don’t believe me? Just use the following snippet and see for yourself.

```php
$fh  = fopen("contacts.csv", "r");
while($line  = fgetcsv($fh, 1000, ",")) {
	echo  "Contact: {$line[1]}";
}
```

**Source: http://phpbuilder.com/columns/Jason_Gilmore060210.php3?page=1**