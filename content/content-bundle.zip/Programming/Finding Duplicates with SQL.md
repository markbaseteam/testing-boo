---
uuid: 20220429100640
title: Finding Duplicates with SQL
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---

# [[Finding Duplicates with SQL]]

```sql
-- this is awesome testimg
SELECT email, COUNT(email) AS NumOccurrences FROM users GROUP BY email HAVING ( COUNT(email) > 1 )
```


---

## 📇 Additional Metadata

- 🗂 Type:: #type/snippet 
- 🏷️ Tags:: [[T-SQL]]
- 📡 Status:: #status/🌲 