---
uuid: 20220524190253
title: How to restore lost sa password for MS SQL
created: 2022-05-24T19:02:53.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

* **Question** – How to restore lost 'sa' password for MSSQL?
* **Answer** – 
Start CMD in administrator mode
```shell
net stop MSSQLSERVER && net start MSSQLSERVER -m #start in single user mode
sqlcmd
1>ALTER LOGIN sa enable
2>GO
1>CREATE LOGIN NewSA WITH PASSWORD = 'Password@1234';
2>ALTER SERVER ROLE sysadmin ADD MEMBER NewSA
3>GO
net stop MSSQLSERVER && net start MSSQLSERVER #start normally
```

Then reset the password through the security section

* **Tags** – [[MS Sql]] [[Sql Server]] 
* **Links/related reading** 
	* https://www.sqlshack.com/recover-lost-sa-password/
	* https://www.wikihow.com/Reset-SA-Password-in-SQL-Server
***

