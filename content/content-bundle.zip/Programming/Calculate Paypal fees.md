---
uuid: 20220526080631
title: Calculate Paypal fees
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.336Z
private: false
alias: null
---

# [[Calculate Paypal fees]]


Ah, Paypal fees. Every person who ever used the popular online payment service had to pay their fees. So what about a PHP function to easily calculate the fee for a specific amount?

```php
01.function paypalFees($sub_total, $round_fee) {
02.
03.// Set Fee Rate Variables

04.$fee_percent = '3.4'; // Paypal's percentage rate per transaction (3.4% in UK)

05.$fee_cash    = '0.20'; // Paypal's set cash amount per transaction (£0.20 in UK)

06.
07.// Calculate Fees

08.$paypal_fee = ((($sub_total / 100) * $fee_percent) + $fee_cash);

09.
10.if ($round_fee == true) {
11.$paypal_fee = ceil($paypal_fee);
12.}
13.
14.// Calculate Grand Total
15.$grand_total = ($sub_total + $paypal_fee);
16.
17.// Tidy Up Numbers
18.$sub_total   = number_format($sub_total, 2, '.', ',');
19.$paypal_fee = number_format($paypal_fee, 2, '.', ',');
20.$grand_total = number_format($grand_total, 2, '.', ',');
21.
22.// Return Array

23.return array('grand_total'=>$grand_total, 'paypal_fee'=>$paypal_fee, 'sub_total'=>$sub_total);

24.}
```
**» [Credits: Snipplr](http://snipplr.com/view.php?codeview&id=44373)**

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]
