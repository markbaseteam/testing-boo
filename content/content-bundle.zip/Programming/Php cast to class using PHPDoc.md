---
uuid: 20230525172857
title: Php typecast to class
created: 2023-05-25T17:28:57
updated: 2023-05-25T17:28:57
private: false
alias:
---

# [[Php cast to class using PHPDoc]]

- Language:: [[PHP]]
- Type:: [[Back-end]]
- Context:: When casting a variable to a specific type for hinting and to fix undefined method or property errors
- 

- Snippet 

```php
/** @var User $user */
$user = $u[0];
```

- Dependencies:: 

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[PHP]]
- 📡Status:: #status/🌲 