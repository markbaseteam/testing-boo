---
uuid: 20220502045508
title: Sql server management studio dark mode
created: 2022-05-02T04:55:08.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

#### Question
# [[Sql server management studio dark mode]]

#### Answer

- go to C:\Program Files (x86)\Microsoft SQL Server Management Studio 18\Common7\IDE for SSMS 18+ 
- locate the file ssms.pkgundef. 
- If you can’t find the file, you may just search that in your program files folder. 
- Open the file and scroll all the way down to locate the very last line. 
- Over here you will see command which removes the dark theme.
- Now go to the line and add two // before the command of root key. Once you add the // entire line will be commented. Now save the file.
```
// Remove Dark theme
[$RootKey$\Themes\{1ded0138-47ce-435e-84ef-9ec1f439b749}]
```

#### Links/related reading
- [Blog post](https://blog.sqlauthority.com/2019/09/12/sql-server-management-studio-18-enable-dark-theme/#:~:text=First%20of%20all%20%E2%80%93%20SQL%20Server%20Management%20Studio,not%20have%20any%20option%20for%20the%20dark%20theme.)
- [Blog post](https://sqlskull.com/2020/06/01/enable-dark-theme-in-sql-server-management-studio/)

----
Type:: #type/question-answer 
Tags:: Sql Server Management Studio, Dark Mode

----



