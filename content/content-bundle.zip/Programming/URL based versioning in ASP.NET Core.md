---
uuid: 20220624070114
title: URL based versioning in ASP.NET Core
created: 2022-06-24T07:01:14
updated: 2022-06-24T07:01:14
private: false
alias:
---

# [[URL based versioning in ASP.NET Core]]

## URL based Versioning
  In this type of versioning, we can define versions in a URL so that it is more readable. Most users prefer this type over other types. You can to URL based versioning by changing the routs as `[Route("api/{v:apiVersion}/Values")]`.
  Let's modify the Route attribute in our both controller, as follows.
```csharp
  using Microsoft.AspNetCore.Mvc;
  namespace api_versioning_demo.Controllers
  {
	  [ApiController]
	  [ApiVersion("1.0")]
	  [Route("api/{v:apiVersion}/employee")]
	  public class EmployeeV1Controller : ControllerBase
	  {
		  [HttpGet]
		  public IActionResult Get()
		  {
			  return new OkObjectResult("employees from v1 controller");
		  }
	  }
  }
  using Microsoft.AspNetCore.Mvc;
  namespace api_versioning_demo.Controllers
  {
	  [ApiController]
	  [ApiVersion("2.0")]
	  [Route("api/{v:apiVersion}/employee")]
	  public class EmployeeV2Controller : ControllerBase
	  {
		  [HttpGet]
		  public IActionResult Get()
		  {
			  return new OkObjectResult("employees from v2 controller");
		  }
	  }
  }
```
  To call EmployeeV1Controller, we have to hit as
  `https://localhost:44381/api/1.0/employee`
  
  To call EmployeeV2Controller we need: `https://localhost:44381/api/2.0/employee` ([View Highlight](https://instapaper.com/read/1508520253/19878900))

---
## Additional Metadata

- Type:: #type/snippet 
- Origin:: [[API Versioning in ASP.NET Core]]
- Status:: #status/🌲 
- Tags:: [[CSharp]]