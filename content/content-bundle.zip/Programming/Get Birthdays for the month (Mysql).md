---
uuid: 20220429120641
title: Get Birthdays for the month (Mysql)
created: 2022-04-29T12:06:41.000Z
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---

# [[Get Birthdays for the month (Mysql)]]
Language:: #database/mysql
Type:: [[Back-end]]
Context:: database query

Description – Get the birthdays for the month from a users table

Snippet – the actual snippet/boilerplate (wrapped in code tags)

```sql
SELECT `user`.firstName, user.lastName, birthday 
FROM `user`
WHERE (DAYOFYEAR('2012-05-15') <= DAYOFYEAR(DATE_ADD(`birthday`, INTERVAL(YEAR(NOW())-YEAR(`birthday`)) YEAR)))
AND (DAYOFYEAR('2012-05-31') >= DAYOFYEAR(DATE_ADD(`birthday`, INTERVAL(YEAR(NOW())-YEAR(`birthday`)) YEAR)))
AND (groupId >= 3)
ORDER BY substring(birthday, 6, 10) ASC;
```

Dependencies:: MySQL

Type:: #type/snippet
