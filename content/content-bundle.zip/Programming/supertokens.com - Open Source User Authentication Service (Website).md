---
uuid: 20220607050111
title: supertokens.com - Open Source User Authentication Service (Website)
created: 2022-06-07T05:01:11.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[supertokens.com - Open Source User Authentication Service (Website)]]

- Authentication 
- SSO SAML
- Used for authenticating users and setting up roles for the users
- 
- Url:: https://supertokens.com/
	- Quick to implement and easy to customize


### Roadmap
- https://supertokens.com/product-roadmap

---

## 📇 Additional Metadata

- 🗂 Type:: #type/source
- Source:: #source/website 
- 🏷️ Tags:: [[Web Authentication]] [[Web Security]]
- 📡 Status:: #status/🌲 
