---
uuid: 20220515075011
title: Split text up into 140 char array for Twitter
created: 2022-05-15T07:50:11.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

## Split text up into 140 char array for Twitter

Language:: [[PHP]] 
Type:: #type/snippet [[Back-end]] 

Description:: As you probably know, [Twitter](http://www.twitter.com/catswhocode) only accepts messages of 140 characters or less. If you want to interact with the popular social messaging site, you’ll enjoy this function for sure, which will allow you to truncate your message to 140 characters.

```
`01.``function`  `split_to_chunks(``$to``,``$text``){`
`02.``$total_length`  `= (140 - ``strlen``(``$to``));`
`03.``$text_arr`  `= ``explode``(``" "``,``$text``);`
`04.``$i``=0;`
`05.``$message``[0]=``""``;`
`06.``foreach`  `(``$text_arr`  `as`  `$word``){`

`07.``if`  `( ``strlen``(``$message``[``$i``] . ``$word`  `. ``' '``) <= ``$total_length`  `){`

`08.``if`  `(``$text_arr``[``count``(``$text_arr``)-1] == ``$word``){`
`09.``$message``[``$i``] .= ``$word``;`
`10.``} ``else`  `{`
`11.``$message``[``$i``] .= ``$word`  `. ``' '``;`
`12.``}`
`13.``} ``else`  `{`
`14.``$i``++;`
`15.``if`  `(``$text_arr``[``count``(``$text_arr``)-1] == ``$word``){`
`16.``$message``[``$i``] = ``$word``;`
`17.``} ``else`  `{`
`18.``$message``[``$i``] = ``$word`  `. ``' '``;`
`19.``}`
`20.``}`
`21.``}`
`22.``return`  `$message``;`
`23.``}`
```

**Source: http://www.phpsnippets.info/split-text-up-into-140-char-array-for-twitter**