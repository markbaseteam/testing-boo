---
uuid: 20230501093110
title: Gitflow
created: 2023-05-01T09:31:10
updated: 2023-05-01T09:31:10
private: false
alias:
---

# [[Gitflow]]

- Author:: Atlassian
- Category:: article
- URL:: [Gitflow Workflow | Atlassian Git Tutorial](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow)
- Rating:: 5

## Learn by elaboration
- The way [[Gitflow]] works is very flexible and allows for a rather flexible way of working
- There is a more modern flow that is becoming the better practice for modern software and [[Continuous Integration and Continuous Delivery|CI/CD]]
- I used this flow for the majority of the work that have been done in [[Britehouse Automotive]] as they did not have a fully matured [[DevOps]] pipeline implemented.
- Base way of work:
	- ![[Pasted image 20230501094519.png]]



```mermaid
%%{init: { 'logLevel': 'debug', 'theme': 'base' } }%%
      gitGraph
        commit tag: "v0.1"
        branch hotfix
        checkout hotfix
        commit
        branch develop
        checkout develop
        commit id:"ash" tag:"abc"
        branch featureB
        checkout featureB
        commit type:HIGHLIGHT
        checkout main
        checkout hotfix
        commit
        checkout develop
        commit
        checkout featureB
        commit
        checkout main
        merge hotfix tag: "v0.2"
        checkout featureB
        commit
        checkout develop
        branch featureA
        commit
        checkout develop
        merge hotfix
        checkout featureA
        commit
        checkout featureB
        commit
        checkout develop
        merge featureA
        branch release
        checkout release
        commit
        checkout main
        merge release tag: "v1.0"
        checkout develop
        merge release

	
```

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/article 
- 🏷️ Tags:: [[Git]], [[Source Code Management]], [[DevOps]]
- 📡 Status:: #status/🌲 

