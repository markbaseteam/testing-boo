---
uuid: 20220516051008
title: Determine date difference in MS Sql
created: 2022-05-16T05:10:08.000Z
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---

# [[Determine date difference in MS Sql]]
Language:: [[T-SQL]]
Type:: [[Persistence]] 
Context:: differences in dates, time-till

Description – Used for getting the time-till or time-since dates

Snippet – 
```sql
SELECT DATEDIFF(year, '2017/08/25', '2011/08/25') AS DateDiff;
```

Dependencies:: [[MS Sql]]

_interval_

Required. The part to return. Can be one of the following values:

-   year, yyyy, yy = Year
-   quarter, qq, q = Quarter
-   month, mm, m = month
-   dayofyear = Day of the year
-   day, dy, y = Day
-   week, ww, wk = Week
-   weekday, dw, w = Weekday
-   hour, hh = hour
-   minute, mi, n = Minute
-   second, ss, s = Second
-   millisecond, ms = Millisecond

_date1, date2_

Required. The two dates to calculate the difference between

Type:: #type/snippet