---
uuid: 20220512084807
title: JavaScript Factory Functions with ES6+ _ by Eric E
created: 2022-05-12T08:48:07.000Z
updated: 2022-06-09T16:15:28.339Z
private: false
alias: null
---

# JavaScript Factory Functions with ES6+


A **factory function** is any function which is not a class or constructor that returns a (presumably new) object. ==In JavaScript, any function can return an object. When it does so without the== ==`new`== ==keyword, it’s a factory function.==

Factory functions have always been attractive in JavaScript because they offer the ability to easily produce object instances without diving into the complexities of classes and the `new` keyword.


---

Type:: #source/article
Status:: #status/🌲 
Url:: https://medium.com/javascript-scene/javascript-factory-functions-with-es6-4d224591a8b1

---