---
uuid: 20220526080631
title: Get domain favicon using PHP and Google
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---

# [[Get domain favicon using PHP and Google]]


These days, many websites or webapps are using favicons from other websites. Displaying a favicon on your own site is pretty easy using Google and some PHP.

`1.function get_favicon($url){`
`2.$url = str_replace("http://",'',$url);`
`3.return "http://www.google.com/s2/favicons?domain=".$url;`
`4.}`
**» [Credits: Snipplr](http://snipplr.com/view.php?codeview&id=45928)**

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]
