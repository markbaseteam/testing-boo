---
uuid: 20220719182456
title: Template Transcoding in Laravel
created: 2022-07-19T18:24:56
updated: 2022-07-19T18:24:56
private: false
alias:
---

# [[Template Transcoding in Laravel]]

To escape data use

```php
{{ $data }}
```

If you don't want the data to be escaped use below

```php
{!! $data !!}
```


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Laravel]] [[Programming]] 
- 📡 Status:: #status/🌲 
