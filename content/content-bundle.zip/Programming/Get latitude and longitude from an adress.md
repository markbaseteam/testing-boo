---
uuid: 20220526080631
title: Get latitude and longitude from an adress
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---

# [[Get latitude and longitude from an adress]]

With the popularity of the Google Maps API, developers often needs to get the latitude and longitude of a particular place. This very useful function takes an adress as a parameter, and will return an array of data containing both latitude and longitude.

`01.function getLatLong($address){`

`02.if (!is_string($address))die("All Addresses must be passed as a string");`

`03.$_url = sprintf('http://maps.google.com/maps?output=js&;q=%s',rawurlencode($address));`

`04.$_result = false;`
`05.if($_result = file_get_contents($_url)) {`

`06.if(strpos($_result,'errortips') > 1 || strpos($_result,'Did you mean:') !== false) return false;`

`07.preg_match('!center:\s*{lat:\s*(-?\d+\.\d+),lng:\s*(-?\d+\.\d+)}!U', $_result, $_match);`

`08.$_coords['lat'] = $_match[1];`
`09.$_coords['long'] = $_match[2];`
`10.}`
`11.return $_coords;`
`12.}`
**» [Credits: Snipplr](http://snipplr.com/view.php?codeview&id=47806)**

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]