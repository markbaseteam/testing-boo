---
uuid: 20230526052748
title: Project Management Importance of keeping proper records
created: 2023-05-26T05:27:48
updated: 2023-05-26T05:27:48
private: true
alias:
---
Up:: [[Project Management]]

# [[Project Management Importance of keeping proper records]]

Url: [Don't overcommit? Got it new friend, thanks for the tip : r/MaliciousCompliance](https://www.reddit.com/r/MaliciousCompliance/comments/13o93r7/dont_overcommit_got_it_new_friend_thanks_for_the/)

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
