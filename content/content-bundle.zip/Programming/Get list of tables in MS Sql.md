---
uuid: 20220809073103
title: Get list of tables in MS Sql
created: 2022-08-09T07:31:03
updated: 2022-08-09T07:31:19
private: true
alias:
---

# [[Get list of tables in MS Sql]]

- Language:: [[T-SQL]]
- Type:: [[Back-end]]
- Context:: list all the tables for the database
- Description 

- Snippet 

```sql
SELECT * FROM [wfedev1-dm].INFORMATION_SCHEMA.TABLES 
where TABLE_NAME like '%_MWR_%';
```

- Dependencies:: 

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Programming]]
- 📡Status:: #status/🌲 
