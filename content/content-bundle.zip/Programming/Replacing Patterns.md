---
uuid: 20220525072205
title: Replacing Patterns
created: 2022-05-25T07:22:05.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[Replacing Patterns]]

In the above examples, we have searched for patterns in a string, leaving the search string untouched. The *preg_replace()* function looks for substrings that match a pattern and then replaces them with new text. *preg_replace()* takes three basic parameters and an additional one. These parameters are, in order, a regular expression, the text with which to replace a found pattern, the string to modify, and the last optional argument which specifies how many matches will be replaced.

preg_replace( pattern, replacement, subject [, limit ])

The function returns the changed string if a match was found or an unchanged copy of the original string otherwise. In the following example we search for the copyright phrase and replace the year with the current.

```
<?php

echo preg_replace("/([Cc]opyright) 200(3|4|5|6)/", "$1 2007", "Copyright 2005");

?>
```

In the above example we use back references in the replacement string. Back references make it possible for you to use part of a matched pattern in the replacement string. To use this feature, you should use parentheses to wrap any elements of your regular expression that you might want to use. You can refer to the text matched by subpattern with a dollar sign ($) and the number of the subpattern. For instance, if you are using subpatterns, $0 is set to the whole match, then $1, $2, and so on are set to the individual matches for each subpattern.

In the following example we will change the date format from "yyyy-mm-dd" to "mm/dd/yyy":

```
<?php
echo preg_replace("/(\d+)-(\d+)-(\d+)/", "$2/$3/$1", "2007-01-25");
?>
```

We also can pass an array of strings as *subject* to make the substitution on all of them. To perform multiple substitutions on the same string or array of strings with one call to *preg_replace()*, we should pass arrays of patterns and replacements. Have a look at the example:

```php
<?php
$search = array ( "/(\w{6}\s\(w{2})\s(\w+)/e",
                  "/(\d{4})-(\d{2})-(\d{2})\s(\d{2}:\d{2}:\d{2})/");

$replace = array ('"$1 ".strtoupper("$2")',
                  "$3/$2/$1 $4");

$string = "Posted by John | 2007-02-15 02:43:41";

echo preg_replace($search, $replace, $string);
?>
```

In the above example we use the other interesting functionality - you can say to PHP that the match text should be executed as PHP code once the replacement has taken place. Since we have appended an "e" to the end of the regular expression, PHP will execute the replacement it makes. That is, it will take strtoupper(name) and replace it with the result of the *strtoupper()* function, which is NAME.

![uparrow.gif](../../_resources/uparrow.gif)[Back to top](http://www.webcheatsheet.com/php/regular_expressions.php#top)



---
## Additional Metadata

Type:: #type/note
Origin:: [[Regular Expressions Starter for PHP]]
- Language:: [[PHP]]
- Tags:: [[Regular Expressions]] 