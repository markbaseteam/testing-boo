---
uuid: 20220515065158
title: Get short urls for Twitter
created: "2022-05-15T06:"
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---
## Get short urls for Twitter

Are you on [Twitter](http://www.twitter.com/catswhocode)? If yes, you probably use a url shortener such as bit.ly or TinyUrl to share your favorite blog posts and links on the network.

This snippet take a url as a parameter and will return a short url.
`1.``function`  `getTinyUrl(``$url``) {`

`2.``return`  `file_get_contents``(``"http://tinyurl.com/api-create.php?url="``.``$url``);`

`3.``}`
**Source: http://www.phpsnippets.info/convert-url-to-tinyurl**