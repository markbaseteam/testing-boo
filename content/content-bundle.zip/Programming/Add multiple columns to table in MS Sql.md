---
uuid: 20220621052107
title: Add multiple columns to table in MS Sql
created: 2022-06-21T05:21:07
updated: 2022-06-21T05:21:13
private: false
alias:
---

#### **Question**
# [[Add multiple columns to table in MS Sql]]

#### **Answer**
```sql
ALTER TABLE table_name
  ADD column_1 column_definition,
      column_2 column_definition,
      ...
      column_n column_definition;
GO
```

#### **Links/related reading** 
- https://www.techonthenet.com/sql_server/tables/alter_table.php
- https://docs.microsoft.com/en-us/previous-versions/sql/sql-server-2005/ms190273(v=sql.90)?redirectedfrom=MSDN#g-adding-several-columns-with-constraints

---
## 📇Additional Metadata
- Type:: #type/question-answer 
- Tags:: [[T-SQL]], [[MS Sql]]
- Status:: #status/🌲 

