---
uuid: 20220512135940
title: Laravel State Machine
created: 2022-05-12T13:59:40.000Z
updated: 2022-06-09T16:15:28.340Z
private: false
alias: null
---
# Laravel State Machine

```ad-note
title: A finite state machine
A finite-state machine (FSM) or finite-state automaton (FSA, plural: automata), finite automaton, or simply a state machine, is a mathematical model of computation. It is an abstract machine that can be in exactly one of a finite number of states at any given time. The FSM can change from one state to another in response to some inputs; the change from one state to another is called a transition.[1] An FSM is defined by a list of its states, its initial state, and the inputs that trigger each transition. Finite-state machines are of two types—deterministic finite-state machines and non-deterministic finite-state machines.[2] A deterministic finite-state machine can be constructed equivalent to any non-deterministic one.
- https://en.wikipedia.org/wiki/Finite-state_machine
```


- https://github.com/asantibanez/laravel-eloquent-state-machines
- https://gist.github.com/iben12/7e24b695421d92cbe1fec3eb5f32fc94
- https://itnext.io/using-state-machines-in-laravel-bbc07384c232
- https://github.com/sebdesign/laravel-state-machine

type:: #type/link
status:: #status/🌲 