---
uuid: 20220526080631
title: Get current weather using Google API
created: 2022-05-26T08:06:31.000Z
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---

# [[Get current weather using Google API]]

Want to know today’s weather? This snippet will let you know, in only 3 lines of code. The only thing you have to do is to replace ADDRESS by the desired adress, on line 1.

`1.$xml = simplexml_load_file('http://www.google.com/ig/api?weather=ADDRESS');`

`2.$information = $xml->xpath("/xml_api_reply/weather/current_conditions/condition");`

`3.echo $information[0]->attributes();`

**» [Credit: Ortanotes](http://ortanotes.tumblr.com/post/200469319/current-weather-in-3-lines-of-php)**

---
## Additional Metadata

Type:: #type/snippet 
Origin:: [[10 super useful PHP snippets - CatsWhoCode.com]]
Language:: [[PHP]]