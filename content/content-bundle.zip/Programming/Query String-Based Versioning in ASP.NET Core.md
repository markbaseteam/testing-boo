---
uuid: 20220624070025
title: Query String-Based Versioning in ASP.NET Core
created: 2022-06-24T07:00:25
updated: 2022-06-24T07:00:26
private: false
alias:
---

# [[Query String-Based Versioning in ASP.NET Core]]

## Query String-Based Versioning
  In the case of query string based versioning, we have to specify the API version in the query string to call the specific controller. Now we mention the specific version to each controller using [ApiVersion(version_name)] attributes. So our controller looks like the code below:
  
```csharp
  using Microsoft.AspNetCore.Mvc;
  namespace api_versioning_demo.Controllers
  {
	  [ApiController]
	  [ApiVersion("1.0")]
	  [Route("api/employee")]
	  public class EmployeeV1Controller : ControllerBase
	  {
		  [HttpGet]
		  public IActionResult Get()
		  {
			  return new OkObjectResult("employees from v1 controller");
		  }
	  }
  }
  using Microsoft.AspNetCore.Mvc;
  namespace api_versioning_demo.Controllers
  {
	  [ApiController]
	  [ApiVersion("2.0")]
	  [Route("api/employee")]
	  public class EmployeeV2Controller : ControllerBase
	  {
		  [HttpGet]
		  public IActionResult Get()
		  {
			  return new OkObjectResult("employees from v2 controller");
		  }
	  }
  }
```
  We can call controller using the below routes with the query string method.
  To call EmployeeV1Controller, we have to hit as https://localhost:44381/api/employee?api-version=1.0
  For EmployeeV2Controller we have to type: https://localhost:44381/api/employee?api-version=2.0 ([View Highlight](https://instapaper.com/read/1508520253/19878898))

---
## Additional Metadata

- Type:: #type/snippet 
- Origin:: [[API Versioning in ASP.NET Core]]
- Status:: #status/🌲 
- Tags:: [[CSharp]] 