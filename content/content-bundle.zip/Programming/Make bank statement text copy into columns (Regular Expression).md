---
uuid: 20220720111727
title: Make bank statement text copy into columns (Regular Expression)
created: 2022-07-20T11:17:27
updated: 2022-07-20T11:17:42
private: false
alias:
---

# [[Make bank statement text copy into columns (Regular Expression)]]

- Language:: [[Regular Expressions]]
- Type:: any
- Context:: Converting transactions copied from a bank statement to have splits/pipes in place. 

- Snippet 

```
Find: ^([0-9a-zA-Z\s]{6})\s(.*)\s([^\s]*)\s([^\s]*)$
Replace: $1 | $2 | $3 | $4
```

```
01 Feb Magtape Debit Multid Formealswheel 64557398 360.00 64,900.04Cr
01 Feb Magtape Debit Liberty04858383447500C/P01Feb 1,377.38 63,522.66Cr
01 Feb POS Purchase Uber Eats 412752*6292 29 Jan 20.00 63,502.66Cr
01 Feb POS Purchase Engen Codonia Quick 412752*6292 30 Jan 149.90 63,352.76Cr
01 Feb POS Purchase Mr D Food.Com 412752*6292 30 Jan 361.38 62,991.38Cr
01 Feb POS Purchase Mcd Waverley (195) 412752*6292 28 Jan 368.70 62,622.68Cr
```
->
```
01 Feb | Magtape Debit Multid Formealswheel 64557398 | 360.00| 64,900.04Cr
01 Feb | Magtape Debit Liberty04858383447500C/P01Feb | 1,377.38| 63,522.66Cr
01 Feb | POS Purchase Uber Eats 412752*6292 29 Jan | 20.00| 63,502.66Cr
01 Feb | POS Purchase Engen Codonia Quick 412752*6292 30 Jan | 149.90| 63,352.76Cr
01 Feb | POS Purchase Mr D Food.Com 412752*6292 30 Jan | 361.38| 62,991.38Cr
01 Feb | POS Purchase Mcd Waverley (195) 412752*6292 28 Jan | 368.70| 62,622.68Cr
```

- Dependencies:: regexr.com/6q4rs

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[Regular Expressions]]
- 📡Status:: #status/🌲 
---

