---
uuid: 20220905154503
title: Switch php version on Ubuntu
created: 2022-09-05T15:45:03
updated: 2022-09-05T15:45:03
private: false
alias:
- "Multiple PHP Versions on Ubuntu"
- "Install multiple PHP versions"
---

# [[Switch php version on Ubuntu]]

[How to Change Default PHP Version on Ubuntu – TecAdmin](https://tecadmin.net/switch-between-multiple-php-version-on-ubuntu/)

## Switch to PHP 8.2

Before switching to PHP 8.2, you have to deactivate the previously activated Apache module. The following commands will deactivate the already activated Apache module and then activate PHP 8.2 Apache module. Then the next commands will set PHP 8.2 as the default version for the command line interface (CLI).

-   **Apache:**
```
sudo a2dismod php* 
sudo a2enmod php8.2
sudo systemctl restart apache2
```
-   **Command line interface:**
```cli
sudo update-alternatives --set php /usr/bin/php8.2
sudo update-alternatives --set phar /usr/bin/phar8.2
sudo update-alternatives --set phar.phar /usr/bin/phar.phar8.2
sudo update-alternatives --set phpize /usr/bin/phpize8.2
sudo update-alternatives --set php-config /usr/bin/php-config8.2
```
   

**Note:** The **phpize8.2** and **php-config8.2** command is available in **php8.2-dev** package. This is more useful for compiling [PHP modules](https://tecadmin.net/enable-disable-php-modules-ubuntu/) using pecl.

If you want a different version (eg: PHP 8.1 or PHP 8.0) to be configured as default, just replace 8.2 with the required version.

The same can be done for v7.4 and v5.6, just change the version number on the commands itself.

[How To Install PHP (8.2, 8.1, 7.4) on Ubuntu 22.04 – TecAdmin](https://tecadmin.net/how-to-install-php-on-ubuntu-22-04/)

---

## 📇 Additional Metadata

- 🗂 Type:: #type/snippet 
- 🏷️ Tags:: [[PHP]]
- 📡 Status:: #status/🌲 
