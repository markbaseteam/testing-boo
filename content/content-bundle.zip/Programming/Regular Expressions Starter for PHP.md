---
uuid: 20220502122055
title: Regular Expressions Starter for PHP
created: 2022-05-02T12:20:55.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[Regular Expressions Starter for PHP]]

Regular expressions are a powerful tool for examining and modifying text. Regular expressions themselves, with a general pattern notation almost like a mini programming language, allow you to describe and parse text. They enable you to search for patterns within a string, extracting matches flexibly and precisely. However, you should note that because regular expressions are more powerful, they are also slower than the more basic string functions. You should only use regular expressions if you have a particular need.

This tutorial gives a brief overview of basic regular expression syntax and then considers the functions that PHP provides for working with regular expressions.

- [The Basics](http://www.webcheatsheet.com/php/regular_expressions.php#basics)
- [Matching Patterns](http://www.webcheatsheet.com/php/regular_expressions.php#match)
- [Replacing Patterns](http://www.webcheatsheet.com/php/regular_expressions.php#replace)
- [Array Processing](http://www.webcheatsheet.com/php/regular_expressions.php#array)

PHP supports two different types of regular expressions: POSIX-extended and Perl-Compatible Regular Expressions (PCRE). The PCRE functions are more powerful than the POSIX ones, and faster too, so we will concentrate on them.

See Also:: [[The Basics]]
See Also:: [[Matching Patterns]]
See Also:: [[Replacing Patterns]]
See Also:: [[Array Processing]]


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- Language:: [[PHP]]
- Tags:: [[Regular Expressions]] 
