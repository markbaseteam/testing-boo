---
uuid: 20220511071744
title: Swagger API Integration Generators
created: "2022-05-11T07:"
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---

# How can I generate interfaces and code for integrating with a SwaggerAPI

2 ways - SwaggerUI:

- Unchase OpenAPI VSStudio Plugins

- Using docker:
 ``` bash
docker run --rm -v C:/tmp:/local openapitools/openapi-generator-cli generate -i https://devedmtapi.azurewebsites.net/swagger/v1/swagger.json -g csharp -o /local/out/edmt
```

swagger openapi
