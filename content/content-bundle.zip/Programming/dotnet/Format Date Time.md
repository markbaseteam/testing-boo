---
uuid: 20220429100621
title: Format Date Time
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---
* Language – C#
* Type – back-end
* Context – Date formatting
* Date format
	* [Standard Datetime formats](https://docs.microsoft.com/en-us/dotnet/standard/base-types/standard-date-and-time-format-strings)
	* [C# DateTime Format](https://www.c-sharpcorner.com/blogs/date-and-time-format-in-c-sharp-programming1)
* Snippet – 
```C#

Console.WriteLine(DateTime.UtcNow.ToString("o"));  
Console.WriteLine(DateTime.Now.ToString("o"));

Console.WriteLine(DateTime.UtcNow.ToString("s") + "Z");

// 2012-07-09T19:22:09.1440844Z  
// 2012-07-09T12:22:09.1440844+02:00

// 2012-07-09T19:22:09Z -- no milliseconds

```
***