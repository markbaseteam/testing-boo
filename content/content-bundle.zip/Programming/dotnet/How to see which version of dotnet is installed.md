---
uuid: 20220609182201
title: How to see which version of dotnet is installed
created: 2022-06-09T18:22:01
updated: 2022-06-09T18:21:08
private: true
alias:
---

#### **Question**
# [[How to see which version of dotnet is installed]]

#### **Answer**

I'm not sure when it was added, but the info command now includes this information in its output. It will print out the installed runtimes and SDKs, as well as some other info:

`dotnet --info`

If you only want to see the SDKs: `dotnet --list-sdks`

If you only want to see installed runtimes: `dotnet --list-runtimes`

I'm on Windows, but I'd guess that would work on Mac or Linux as well with a current version.

Also, you can reference the [.NET Core Download Archive](https://github.com/dotnet/core/blob/master/release-notes/download-archive.md#net-core-runtime-and-sdk-download-archive ".NET Core Runtime and SDK download archive") to help you decipher the SDK versions.

#### **Links/related reading** 
- [https://stackoverflow.com/questions/38567353/how-to-determine-if-net-core-is-installed](https://stackoverflow.com/questions/38567353/how-to-determine-if-net-core-is-installed)

---
## 📇Additional Metadata
- 📁Type:: #type/question-answer 
- 🏷️Tags::  [[DotNet]], [[CSharp]], [[Programming]]
- 📡Status:: #status/🌲 

