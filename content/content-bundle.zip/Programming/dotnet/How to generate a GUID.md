---
uuid: 20220429100621
title: How to generate a GUID
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---
* Language – C#
* Type – back-end
* Context – Creating GUID to use 
* (Description) – a text-based description of the snippet
* Snippet – the actual snippet/boilerplate (wrapped in code tags)
```csharp
	using System;
	namespace DemoApplication{
	   class Program{
		  static void Main(string[] args){
			 Guid demoGuid = Guid.NewGuid();
			 Console.WriteLine(demoGuid);
			 Console.WriteLine(Guid.NewGuid());
			 Console.ReadLine();
		  }
	   }
	}
```

