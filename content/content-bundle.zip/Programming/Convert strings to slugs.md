---
uuid: 20220525094622
title: Convert strings to slugs
created: "2022-05-25T09:"
updated: 2022-06-09T16:15:28.337Z
private: false
alias: null
---
## Convert strings to slugs
Language:: [[PHP]] 
Type:: #type/snippet [[Back-end]] 

Description:: Need to generate slugs (permalinks) that are SEO friendly? The following function takes a string as a parameter and will return a SEO friendly slug. Simple and efficient!
```
`1.``function`  `slug(``$str``){`
`2.``$str`  `= ``strtolower``(trim(``$str``));`
`3.``$str`  `= preg_replace(``'/[^a-z0-9-]/'``, ``'-'``, ``$str``);`
`4.``$str`  `= preg_replace(``'/-+/'``, ``"-"``, ``$str``);`
`5.``return`  `$str``;`
`6.``}`
```
**Source: http://snipplr.com/view.php?codeview&id=2809**