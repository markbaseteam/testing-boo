---
uuid: 20221207044341
title: Read JSON in MS Sql
created: 2022-12-07T04:43:41
updated: 2022-12-07T04:43:41
private: true
alias:
---

# [[Read JSON in MS Sql]]

- Language:: [[T-SQL]]
- Type:: [[Back-end]]
- Context:: Read JSON from SQL
- Description – a text-based description of the snippet

- Snippet

```sql
declare
@JSON nvarchar(max) = '[1,2,3,4]',
@JSON2 nvarchar(max) = '[1,2,0,0]'

-- SELECT *, value
-- FROM OPENJSON(@JSON)

-- select *, value from OPENJSON(@JSON2)

SELECT * FROM openjson(@json) where value not in (select value from openjson(@json2))
```

- Dependencies:: 

----
## 📇Additional Metadata

- 📁Type:: #type/snippet
- 🏷️Tags:: [[MS Sql]] [[T-SQL]]
- 📡Status:: #status/🌲 