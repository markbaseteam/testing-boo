---
uuid: 20220429120643
title: Simple email tracking in PHP
created: 2022-04-29T12:06:43.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[Simple email tracking in PHP]]

## Tracking Click-Throughs: The Email HTML

```html
<a href="http://mydomain.com/landing.php?e=email@address.com">Click here</a> for more information!
```

## Tracking Click-Throughs: The PHP
```php
// (inside "landing.php")
if(isset($_GET['e']))
{
//validate and record click-through here
}
```
Tracking click-throughs was the easy part. All you do is attach a $_GET variable to the link and listen for that variable on the website. Simple!


## Tracking Opens: The HTML

```html
<div style="display: none;"><img src="http://mydomain.com/emails/record.php?e=email@address.com" alt="Tracker" /></div>
```


## Tracking Opens: The PHP

```php
// (inside "record.php")
header('Content-Type: image/gif');
if(isset($_GET['e'])){   
	//validate and record click-through here
}  
//push out image
if(ini_get('zlib.output_compression'))  {  
	ini_set('zlib.output_compression', 'Off'); 
}
header('Pragma: public');  
// required
header('Expires: 0');  
// no cache
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Cache-Control: private',false);
header('Content-Disposition: attachment; filename="blank.gif"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: '.filesize('blank.gif'));  
// provide file size
readfile('blank.gif');  
// push it out
exit();
```

This involves a bit more. You need to first tell the PHP file that it should be served as an image. Then, you read the $_GET variable value and record that the user had requested the file. Lastly, you push out the actual image.

Type:: #type/note #programming/how-to
Language:: [[PHP]] 

