---
uuid: 20220516033955
title: Get the text between $start and $end
created: 2022-05-16T03:39:55.000Z
updated: 2022-06-09T16:15:28.338Z
private: false
alias: null
---
## Get the text between $start and $end
Language:: [[PHP]] 
Type:: #type/snippet [[Back-end]] 

This is the kind of function every web developer should have in their toolbox for future use: give it a string, a start, and an end, and it will return the text contained with $start and $end.

```php
function GetBetween($content, $start, $end){
	$r = explode($start, $content);
	if  (isset($r[1])){
		$r = explode($end, $r[1]);
		return  $r[0];
	}
	return  '';
}
```
Source: http://www.jonasjohn.de/snippets/php/get-between.htm