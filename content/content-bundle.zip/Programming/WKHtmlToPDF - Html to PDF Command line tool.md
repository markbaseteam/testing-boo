---
uuid: 20220526152237
title: WKHtmlToPDF - Html to PDF Command line tool
created: 2022-05-26T15:22:37.000Z
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---

# [[WKHtmlToPDF - Html to PDF Command line tool]]


## What is it?

`wkhtmltopdf` and `wkhtmltoimage` are open source (LGPLv3) command line tools to render HTML into PDF and various image formats using the Qt WebKit rendering engine. These run entirely "headless" and do not require a display or display service.

There is also a C library, if you're into that kind of thing.


- Category:: Command line tool
- URL:: [wkhtmltopdf](https://wkhtmltopdf.org/)
- Status:: #status/🌲 
- Tags:: [[Command Line]], [[PDF]], [[HTML]]
- Rating:: ??

---
## 📇Additional Metadata
Type:: #type/resource 
Source:: #source

