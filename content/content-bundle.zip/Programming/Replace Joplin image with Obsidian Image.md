---
uuid: 20220512083126
title: Replace Joplin image with Obsidian Image
created: 2022-05-12T08:31:26.000Z
updated: 2022-06-09T16:15:28.341Z
private: false
alias: null
---

# [[Replace Joplin image with Obsidian Image]]

Language:: #language/regex
Type:: back-end
Context:: Replace Markdown image tags with Wiki image tags

Snippet

```regex
search: /\[(<img\s+[^>]*)(src\s*=\s*["|'])(.+?)(["|'])\/>\]\([^\)]+\)/
replace: ![img]($3)]
```

Dependencies:: 
tags:: regex, regular expression, image tag
link: regexr.com/4g6he

Type:: #type/snippet
