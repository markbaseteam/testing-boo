---
uuid: 20230531094910
title: ChatGPT
created: 2023-05-31T09:49:10
updated: 2023-05-31T09:49:10
private: false
alias:
---
Up:: [[Programming]]

# [[ChatGPT]]

LLM - AI using a Large Language Model to generate coherent and more often than not good results

---

## 📇 Additional Metadata

- 🗂 Type:: #type/resource  
- 🏷️ Tags:: 
- 📡 Status:: #status/🌲 
