---
uuid: 20220726101549
title: Jacaranda FM
created: 2022-07-26T10:15:49
updated: 2022-07-26T10:15:49
private: true
alias:
---

# [[Jacaranda FM]]

Radio station
94.2 FM

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Radio Station]]
- 📡 Status:: #status/🌲 
