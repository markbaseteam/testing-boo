---
uuid: 20220614120056
title: Guitar MOC
created: 2022-06-14T12:00:56
updated: 2022-06-14T12:00:56
private: true
alias:
 - Guitar
---
Up:: [[Music MOC]]

# [[Guitar MOC]]

## Goal
- My goal is to learn and know at least 10 songs that I can play without chords in front of me.

Current Song List:
- Halleluja - 
- Time of your life - Green day
- Whats going on - 4 non blondes
- Zombie - Cranberries
- Brown Eyed Girl - Van Morrison
- Wild World - Cat Stevens
- Country Roads - 
- Suspicious Minds - Elvis Presley
- All I want - Kalindo

- Black Bird - Paul McCartney - Beatles
- House of the Rising Sun
- 

## Courses

- [[Justin Guitar]] - 
![[Guitar MOC 2023-03-15 05.18.49.excalidraw]]
## Resources

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
