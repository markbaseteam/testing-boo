---
uuid: 20220614123644
title: Justin Guitar - Grade 2 - Module 12
created: 2022-06-14T12:36:44
updated: 2022-06-14T12:36:44
private: true
alias:
---

# [[Justin Guitar - Grade 2 - Module 12]]


- Started::
- Finished::
  
## Lessons

- Power Chords
- A Minor Pentatonic
- Palm Muting
- Enter Sandman Riff

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Music MOC|Music]], [[Guitar MOC|Guitar]]
- 📡 Status:: #status/🌿 
