---
uuid: 20220526104429
title: Frission - Getting goosebumps from listening to music
created: 2022-05-26T10:44:29
last-modified: 2022-05-26T10:44:29
private: false
alias:
---

# [[Frisson - Getting goosebumps from listening to music]]

> The study suggests that the denser fiber in the brain means that the auditory and emotion-processing areas of the [brain of those who get chills are better able to communicate with each other](https://www.classicfm.com/music-news/music-gives-goosebumps/), thus the stronger reaction they have to what is called [musical stimuli](https://psycnet.apa.org/record/2013-12326-004).

> Piloerection (goosebumps), the physical part of frisson

Wiki:: https://en.wikipedia.org/wiki/Frisson
Links:
- https://www.classicfm.com/music-news/music-gives-goosebumps/
  > “People who get the chills have an enhanced ability to experience intense emotions,” Sachs said.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Music]]
- Status:: #status/🌲 
