---
uuid: 20220720091652
title: Gridfinity - 3D printed modular organizational system
created: 2022-07-20T09:16:52
updated: 2022-07-20T09:16:52
private: true
alias:
---

# [[Gridfinity - 3D printed modular organizational system]]

- Author:: https://www.youtube.com/c/ZackFreedman
- Category:: video
- URL:: 
	- Video:
		- https://www.youtube.com/watch?v=ra_9zU-mnl8
	- 3D Files:
		- https://thangs.com/designer/ZackFreedman/3d-model/Gridfinity%20Divider%20Bins-60721?manualModelView=true&utm_source=youtube&utm_medium=video&utm_campaign=zack_f
		- https://thangs.com/designer/ZackFreedman/3d-model/Gridfinity%20Window%20Divider%20Bin-60754?manualModelView=true&utm_source=youtube&utm_medium=video&utm_campaign=zack_f
		- https://thangs.com/designer/ZackFreedman/3d-model/Gridfinity%20Baseplates-60925?manualModelView=true&utm_source=youtube&utm_medium=video&utm_campaign=zack_f
		- https://www.printables.com/search/models?q=%23gridfinity
		- https://thangs.com/search/gridfinity?scope=all&utm_source=youtube&utm_medium=video&utm_campaign=zack_f
	- Template:
		- https://myhub.autodesk360.com/ue2b114c8/g/shares/SH35dfcQT936092f0e439591db365903a026

## Learn by elaboration


---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/video 
- 🏷️ Tags:: [[3D Printing]], [[Fusion 360 (App)]], [[Organization]]
- 📡 Status:: #status/🌲 
