---
uuid: 20220608220838
title: Octopi - Rendering Timelapse failed with returned error code
created: 2022-06-08T22:08:38.000Z
updated: 2022-06-09T16:15:28.331Z
private: false
alias: null
---

# [[Octopi - Rendering Timelapse failed with returned error code]]

**Camera model**
Logitech C920

**What is the problem?**
Timelapse fails with no error code mentioned

Example Error: "Rendering of timelapse COLLAPSING\_PIRATE\_SWORD\_small\_20200404163307 failed with return code "

**What did you already try to solve it?**
I have tried updating the camera\_usb\_options to "-r 1280x720 -f 10" as mentioned in the supported camera section on the octopi wiki.

I researched the octopi.log file and found it mentioning an error related to /usr/bin/avconv. This file does not exist and I imagine it is the root cause of the problem. I do not know how to resolve this issue. I have tried running various apt-get commands. avconv does not have a package and seems to be a part of ffmpeg which is installed and up to date.



**Additional information about your setup** (OctoPrint version, OctoPi version, ...)
OctoPrint version : 1.4.0
OctoPi version : 0.17.0
Running on Raspberry pi 3
I recently upgraded to those versions by reflashing my SD card per the instructions provided on the Octopi and Raspberry pi sites. Before upgrading I downloaded a backup of Octopi via the web UI. After upgrading I applied the backup. I believe the previous version I was on was 1.3.12. I could not update through the web UI due to issues related to python. So i opted to update by flashing and restoring a backup.

- #### created
    
    Apr '20
    
- [#### last reply May '21](https://community.octoprint.org/t/rendering-timelapse-failed-with-returned-error-code-none/17962/6)
- 1.9k

    

I can't access any octopi pi right now so I'm not sure if this could be backup related.

I would check the `ffmpeg` path in the recording settings.
Iirc it should be `/usr/bin/ffmpeg`

`which ffmpeg` will show you the path in ssh if that doesn't work.

And for the `avconv` part try `sudo find / -name avconv`

Thank you for the reply. I think you've set me on the right path for this.

The path for `ffmpeg` was correct and existed.

`avconv` could not be found anywhere on the file system.
* * *
 > [!note] **Solve**
 I took a closer look at the settings in octoprint and found the WebCam & Timelapse settings had 'Path to FFMPEG' set to '/usr/bin/avconv', which the test button failed because the file did not exist.
>
>I changed 'Path to FFMPEG' from '/usr/bin/avconv' to '/usr/bin/ffmpeg'. Clicked test and that it returned successful!
>
I'm going to be running print jobs tomorrow and will test out the timelapse again.

Thank you for your help!

UPDATE: Decided I could just run a short job before hitting the hay. That did it! thanks for the suggestion of looking at the settings for FFMPEG in the web UI.

Thanks It has helped me too <img width="20" height="20" src="../../_resources/slight_smile_f2bbac0dca7b4204adc3927b620f45fd.png"/>

This worked for me as well. Thank you. Once i changed the file path i was able to render the same time-lapse that was previously failing as well so didn't need to do a new print.


---

## 📇 Additional Metadata

- 🗂 Type:: #type/question-answer 
- 🏷️ Tags::
- 📡 Status:: #status/🌲 