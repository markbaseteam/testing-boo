---
uuid: 20230530050633
title: Atrial Fibrillation
created: 2023-05-30T05:06:33
updated: 2023-05-30T05:06:33
private: true
alias:
---

# [[Atrial Fibrillation]]

- Irregular Hearth Rhythm.
- Increased risk of stroke or Alzheimer's.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Medical Conditions]]
- 📡 Status:: #status/🌲 
