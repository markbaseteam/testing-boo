---
uuid: 20230329045533
title: Shoulder Impingement Syndrom
created: 2023-03-29T04:55:33
updated: 2023-03-29T04:55:33
private: false
alias:
---

# [[Shoulder Impingement Syndrome]]

Causes:
- [Shoulder Impingement Syndrome: Causes & Treatment](https://www.shoulder-pain-explained.com/shoulder-impingement-syndrome.html)

Exercises:
- [Shoulder Impingement Exercises: What To Do And What To Avoid!](https://www.shoulder-pain-explained.com/shoulder-impingement-exercises.html)


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Health]] [[Personal Health MOC]]
- 📡 Status:: #status/🌲 
