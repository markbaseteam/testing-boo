---
uuid: 20230107094033
title: How I tricked my brain to like doing hard things
created: 2023-01-07T09:40:33
updated: 2023-01-07T09:40:46
private: false
alias:
---

# [[How I tricked my brain to like doing hard things]]

- Author:: Better Ideas
- Category:: video
- URL:: https://www.youtube.com/watch?v=yM0tQabjYYg
- Rating:: 5

## Learn by elaboration
- Habit Bunching
	- Taking a new habit you want to learn and 'bunching' it with an existing habit
		- Coffee every morning - Tied to reading
		- Listen to favorite music - Go to gym and only allowed to listen to it there
- Enjoy the journey
- Come from a place of abundance instead of scarcity
	- I need to get jacked - implies you are not jacked and makes you not identify as someone who is jacked
	- I am going to the gym because I am healthy and live a healthy life implies it is something you do to stay healthy for all the reasons you started in the first place
	- 

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/video 
- 🏷️ Tags:: [[Habit]] [[Motivation]] [[Health]]
- 📡 Status:: #status/🌲 

