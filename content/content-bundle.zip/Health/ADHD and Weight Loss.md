---
uuid: 20230504060641
title: ADHD and Keto Diet
created: 2023-05-04T06:06:41
updated: 2023-05-04T06:06:41
private: true
alias:
---

# [[ADHD and Weight Loss]]

- [ADHD Obesity Link](https://www.additudemag.com/slideshows/adhd-obesity-link/)
	- Medical research[1](https://www.additudemag.com/slideshows/adhd-obesity-link/#footnote1) shows that obese individuals are five to ten times more likely to have attention deficit hyperactivity disorder (ADHD) than are members of the general population. The link between ADHD and obesity is very real — though not yet fully understood. Certainly impulsivity, poor planning, and high-intensity emotions don't help in the fight to lose weight, but there could be more at play here.
- [The ketogenic diet causes a reversible decrease in activity level in Long-Evans rats - PubMed](https://pubmed.ncbi.nlm.nih.gov/16750194/)
- 

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[ADHD]] 
- 📡 Status:: #status/🌲 
