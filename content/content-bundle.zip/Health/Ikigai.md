---
uuid: 20220516082038
title: Ikigai
created: 2022-05-16T08:20:38.000Z
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---

# [[Ikigai]]

Ikigai (生き甲斐, 'a reason for being') is a Japanese concept referring to something that gives a person a sense of purpose, a reason for living. 

[Wikipedia](https://en.wikipedia.org/wiki/Ikigai)

![1ef9a8763eae42849f722d1b622efa3d.png](../../_resources/1ef9a8763eae42849f722d1b622efa3d.png)



from  [[How I organize my life]]

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- ℹ️ Source:: #source/video [[How I organize my life]]

