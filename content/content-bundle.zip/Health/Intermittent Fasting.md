---
uuid: 20230202093350
title: Intermittent Fasting
created: 2023-02-02T09:33:50
updated: 2023-02-02T09:33:50
private: true
alias:
---

# [[Intermittent Fasting]]

## Goal
- the goal of intermittent fasting is to reset your insulin resistance and reduce the insulin made by the body by stretching out the time between the last meal and the first meal the next day.

## Different Protocols

- 16/8
- 24

https://www.youtube.com/watch?v=5BXOkgwQTjk&t=367s


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Personal Health MOC]], [[Fasting]], [[Health]], [[Nutrition]]
- 📡 Status:: #status/🌿 
