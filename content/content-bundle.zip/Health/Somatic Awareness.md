---
uuid: 20220704125501
title: Somatic Awareness
created: 2022-07-04T12:55:01
updated: 2022-07-04T12:55:01
private: false
alias:
---

# [[Somatic Awareness]]

## What is it?

> Somatic awareness is **when a person acknowledges their own self within their environment and uses sensations to identify the psychological, physiological and social factors to promote healing and self-regulation** [1]
> - https://www.eatingdisorderhope.com/blog/eds-somatic-awareness-integration



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Emotions]], 
- 📡 Status:: #status/🌲 
