---
uuid: 20220515203230
title: Draw-A-Box
created: 2022-05-15T20:32:30.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---

# [[Draw-A-Box]]

Anyone can learn to draw. It's not some magical talent a few people are born with. It's a skill you can train. We can help.

Drawabox is a set of free exercise-based lessons that focus on the fundamentals - the skills you'll need to make sense of all the other resources and tutorials out there. First we focus on the basic mechanics of mark making, and how to use your arm. By the end, we develop a strong understanding of form, 3D space and construction.

I won't lie to you - our approach is tough and involves a lot of hard work. It's also structured and gives you a clear path with concise explanations and assignments you can complete and submit for review.

You can read more about Drawabox and how it came about here.

Or you can join the community of thousands of beginners and professionals alike and [get started](https://drawabox.com/lesson/0).

- Author:: the original author of the resource
- Category:: website
- URL:: https://drawabox.com/
- Status:: #status/🌲 
- Tags:: [[Drawing]]
- Rating:: 

---
## 📇Additional Metadata
- Type:: #type/resource 
- Source:: #source/website 