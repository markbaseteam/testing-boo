---
uuid: 20220815041902
title: Fortnite
created: 2022-08-15T04:19:02
updated: 2022-08-15T04:19:02
private: true
alias:
---

# [[Fortnite]]

## Keybinds

URL:: https://charlieintel.com/the-best-keybinds-and-settings-for-fortnite-on-mouse-keyboard/84934/

## Beginner Guides

- https://www.reddit.com/r/FORTnITE/comments/dnh9xg/building_and_tunnels_for_beginners/
- https://www.reddit.com/r/FORTnITE/comments/dnuf0o/beginners_guide_to_heroes/
- https://www.reddit.com/r/FortniteSavetheWorld/comments/ijwwa3/a_beginners_guide_for_new_save_the_world_players/
- https://www.reddit.com/r/STWguides/comments/tvdi7v/guide_megathread_for_easier_access_to_guides/
- 

---

## 📇 Additional Metadata

- Type:: #type/game 
- Game:: #game/mmorpg
- Status:: #status/🟢
- Release Date:: 2012-08-28
- Platform:: PC
- Store:: [[Epic Games]]
- Publisher:: [[Arena Net]]
