---
uuid: 20220516154641
title: Idle Champions of the Forgotten Realms
created: 2022-05-16T15:46:41.000Z
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---

Up: [[Gaming MOC]]

# [[Idle Champions of the Forgotten Realms]]

## About
Idle Champions of the Forgotten Realms is a Dungeons & Dragons strategy management game uniting characters from throughout the D&D multiverse into a grand adventure.

## 🛠️Tools
- Hero Table
	- URL: [Idle Champions Data Viewer (kleho.ru)](https://idle.kleho.ru/list/)
- Idle Champions Utils
	- URL: [Dashboard - Idle Champions Utils (byteglow.com)](https://ic.byteglow.com/)


## Azaka Gold Farm
- [[Azaka Gold Farm]]

## Party Setup
### Party 1 - Campaigners/Trails/Quests

### Party 2 - Events/Time Gates/Quests

### Party 3 - Gem Farms

### Party 4 - Patron Weeklies and Patron Variants

----
## 📇 Additional Metadata

- 🗂 Type:: #type/game
- 🎮 Game:: #game/idle-clicker
- Status:: #status/🟢
- Release Date:: 2021-02-16
- Platform:: PC
- Store:: [[Epic Games]]
- Publisher:: [[Codename Entertainment]]
