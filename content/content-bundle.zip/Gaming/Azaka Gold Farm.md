---
uuid: 20220727035823
title: Azaka Gold Farm
created: 2022-07-27T03:58:23
updated: 2022-07-27T03:58:23
private: false
alias:
---

Up: [[Idle Champions of the Forgotten Realms]]
# [[Azaka Gold Farm]]


>[!note] Update: [Ultimate Azaka gold farming guide - Google Docs](https://docs.google.com/document/d/1TT5g3BjKDreYQ3MutCRgeSRGYD8a7GrFfZ96bIllT7o/edit#heading=h.bb7oqkaqv7m6)


URL:: https://www.reddit.com/r/idlechampions/comments/iacthj/azaka_farming_gold_find_guide_aghairons_day_2020/

Azaka Farming / Gold Find Guide (Aghairon's Day 2020)
guide

Psylisa's most recent guide to their Azaka farming concept is a fantastic introduction. A lot has changed since my latest guide - three new strong gold find champions with unique mechanics have been released. This update describes how best to take advantage of them. A chart I've uploaded here may help in understanding how much different gold champions will help you. As always, if you've got insights to share please do so in the comments to help make this guide better.
What is Azaka farming?

Azaka is an evergreen champion unlocked by completing Azaka's Progression Part II in the Tomb of Annihilation campaign. If you choose her Resist the Curse specialization, her ultimate summons two tigers who make gold drop from enemies when they attack even if they do not kill the enemy. Azaka farming is a way of exploiting this ability to get massive gold (and therefore favor) gains. The basic strategy is to isolate a single enemy on a boss level, then swap in an optimized gold find team while Azaka's ult farms the increased gold.
What do you need to Azaka farm?

Required: Azaka (Resist the Curse spec)

Recommended Formation:
Krull (Pilfer Spec, Venomous Touch feat, Increase Toxicity feat, Lucky Feat, Golden Rule feat)
Freely (Lawful Spec, Fortuitous Feat, Fortune's Favor Feat)
Jarlaxle (Master of Piracy spec, Fortune's Favor feat, Lucky feat)
Omin (Rules Lawyer feat, Lucky feat, positioned behind the biggest column possible)
Drizzt (Leader of the Companions spec, Lucky feat, Frugal feat)
Nrakk (Unerring Accuracy spec, positioned adjacent to Drizzt and Omin)
Barrowin Lawful fast attacker for Freely, Healer
Qillek Lawful for Freely, Healer
Dragonbait Lawful for Freely, Tank

Recommended Swaps:
Beadle (Order Up! feat)
Jim
Donaar (Oh Yeaaaaah!)
Havilar (Ult slows mobs)

Backups to Recommended Champions:
Alternate Lawful Champs: Slots 1, 2, 5, 10, and 11 are available to pick from, giving Turiel (with Lucky feat) and Celeste as alternatives to Barrowin, Qillek, and Dragonbait.
If Freely has no slot 2 epic: Bruenor with Wisdom feat adjacent to Nrakk is probably slightly better than Turiel (depends on Freely ilvl)
If no Freely: Replace Freely, Barrowin, Qillek, and Dragonbait with Bruenor (adjacent Nrakk, Wisdom feat), Cattie-Brie, Regis, and Wulfgar
If no Omin: Replace with Artemis (Lucky feat) or Nayeli if you have Freely, otherwise replace with Pwent (adjacent a CotH)
Rogues/Drow: Krydle, Artemis (Lucky feat), Spurt, Xander, Shandie, Black Viper, Hitch (Not K'thriss - Bruenor is always better)
Healers: Celeste, Calliope, Tyril, etc. if you do not have Havilar

Other Recommendations:
Clairvoyance Potions (1 Huge, 1 Large, 1 Medium, 3 Small)
Speed Potions (1 Huge, 1 Large, 1 Medium)
Three Familiars
Azaka farming step by step

STEP 1: Isolate a Mob at your Wall

If you have Krull, make sure Krull is in Pilfer spec (you lose his stacks if you respec him, and Pilfer is worth more gold than pushing a little further with more damage). Also make sure his Venomous Touch and Increase Toxicity feats are equipped if you have them.

Go to the furthest boss level you can reach.

Kill all but one mob:
Basic Method: Get a high BUD by whatever method you can and kill the boss right after it spawns by using an ult like Hitch's that attacks the back of the formation. You can then use single or limited target ults like Bruenor, Nayeli, or (if there are enough mobs left) Jamilah to whittle the 10 spawns down to a single enemy. Cycling through Hitch's ult twice will also give you 1 mob left if everything dies in a single hit.
Using Krull: Krull's traitor ability multiplies attack damage on enemies next to the one that got hit. Since the traitor does not take the increased damage itself, this often means that there is a single heavily debuffed mob left on boss levels.
Optimization Note: Delay as long as you can before wiping the level (20-30 enrage stacks seems to work well). This gives Krull time to tag all 10 mobs plus the boss with a full Pilfer stack. When they all die at once, Krull's virulent strain ability gives a change for each of these to transfer to the last surviving mob. Krull's Venomous Touch and Increase Toxicity feats help immensely here.
Using Jim: Jim's wand of wonder ability to turn mobs into instant-kill abyssal chickens is great for cleaning up after Krull (see above). The same ability can also randomly make armored Mimics that drop extra gold. When at your wall, swap in Jim until he forms a mimic. Once the mimic is there, swap Jim out immediately so he doesn't accidentally turn it into a chicken or make more. Then you can debuff and nuke all of the enemies with any ultimate you want. Since the mimic is armored, it will tend to survive the carnage, giving you your single mob. You can use Jim and Krull together, too, of course.
Boss method: You can also leave just the boss behind instead of a mob. This is risky because the boss will be building enrage stacks, but if you use knockback abilities and Havilar's slow it is manageable. This prevents you from applying Jim's mimic debuff, though.

Remove your DPS and let BUD decay enough that you don't accidentally kill the newly isolated mob.

If you have Krull, you may want to try steps 2-4 again if you're trying to follow the Krull optimization until you get a large stack . Multi-stacking pilfer can result in massively higher gold gains.

STEP 2: Debuff the Mob

If you have Havilar, swap her in and put a familiar on her ult while you do the other debuffs and swapping. Her ult slows down a mob every time it hits. It seems to stack with each ult, so after a good number of her very short cooldown cycles, the mob can barely move at all. This is great for letting your farm run unattended. Once you are satisfied with the slow mob, she can be swapped out.

If you have Jim and the mob is not already a mimic, swap him in to change it into a mimic. This might accidentally kill the mob, which means you'd need to do step 1 again.
Optimization Note: Do NOT do this if the mob has more than 10 of Krull's Pilfer stacks; the extra stacks are worth more than the Mimic bonus.

If you have Donaar, swap him in until his coin drop debuff appears on the mob. He can then be swapped out.

If you have Beadle, swap him in until his chicken leg debuff appears on the mob. He can then be swapped out.

STEP 3: Setup Gold Find Formation

Put all the recommended champions in place, with a few notes.

It is a good idea to keep some healing champion in the formation until the very last swap, just to make sure the mob doesn't plow through your formation while you aren't paying attention. Also, don't swap a tank out until you're sure the mob won't attack that slot. Note that with Freely, it is possible to use a large number

Krull must not be removed or respeced, or the pilfer stacks on the mob will disappear. You can (and should) swap his feats. If you had Venomous Touch and Increase Toxicity, replace them with Lucky and Golden Rule if you have them.

A tank should be at the front of the formation. Best tanks are Dragonbait (if you have Freely) or Wulfgar (if you don't have Freely) as others have better gold finders in their slot or aren't lawful. You may have to use a knockback ability (like Donaar's attack) or ult (like the ults for Asharra, Pwent, Warden, Farideh, or Turiel) to allow you to put your chosen tank in front.

If the formation is multi-tank, you need to keep pushing the mob back until it decides to attack your tank. Turiel helps immensely here, since the mob will never wind up attacking him. Once Dragonbait or Wulfgar is tanking, you can swap the other tanks with gold find champions (Sentry -> Jarlaxle, Aila-> Drizzt, etc.) Swap Turiel with Bruenor if you don't have Freely or your Freely slot 2 isn't epic.

If you use him, make sure Nrakk is next to everyone who can benefit. Drizzt and Bruenor (if he has his Wisdom feat) get gold find boosts. Barrowin and Qillek will heal better and it can make Barrowin attack extremely quickly to boost Omin and Freely. I tested Omin and while he is eligible and Formation Buffs indicate his gold find increases with Nrakk, the gold produced while his ability was active didn't change whether or not Nrakk was next to him.

If you use him, make sure Omin is behind the largest column in the formation

If you use him, make sure Pwent is next to one of the CotH

If you use him, make sure Freely has his gold find feats equipped (Fortune's Favor and Fortuitous)

If you think you'll need to swap in a healer to keep your tank alive, make sure that swap is in the right place (for example, if you swap Pwent -> Calliope, make sure she's within 2 slots of Wulfgar). Note that if you have Freely, you can just use lawful Qillek, neatly solving this problem.

Put a familiar on Azaka's ult. If you have all tanks in your front line, you can also put familiars on pushback ults (Turiel, Pwent). Any stunning ults (Wulfgar) should also get familiars. The first one is obvious, the second two will help keep your tank(s) alive by stunning and pushing back the mob so it attacks less. If you have Havilar, you can slow enough that the mob cannot travel the distance between where it gets pushed back and your tanks before it gets pushed back again.

STEP 4: Pop Your Potions

If you've taken the time to push deep to you wall, it's worth the investment to use potions and get as much favor as possible. I always use a full set of Clairvoyance potions when doing my last Azaka farm, and usually max out speed potions (one of each except for small) as well. A full set of Clairvoiyance potions is worth something like e0.7 more favor than with no potions.

Also, make sure your Modron Core is active with as many gold nodes at as high a flow as possible. This is worth an extra e0.8 to e1 gold find per node, so pretty significant.

STEP 5: Sustain Your Farm

If everything is set up perfectly, you can just walk away at this point and let the formation do its thing. However, if your combination of stuns from Nrakk, Wulfgar, and Cattie-Brie, miss chance from Drizzt, slow from Havilar's ult debuff, knockback from Pwent and heal from Regis isn't enough to keep Wulfgar alive, you'll need to periodically swap in a healing champ. Pwent/Qillek, Pwent/Calliope, or Regis/Celeste are recommended. Just watch Azaka's ult cooldown so you can make sure to put the gold find champ back in before it fires. Note that if you use the recommended Freely formation it comes with a free healer (Qillek).

STEP 6: Stop Your Farm

You get diminishing returns with a long farm. Whatever gold you get in the first 5 minutes, you will only get +e1.1 gold if you keep it up over the next hour (this translates to about +e0.3 favor). It's not insignificant, but you do have to keep up all your potions for that period. I recommend farming for at least 15 minutes, and if you've got a good setup (40 stack mimic at your extreme wall) it's worth going longer if you've got the time.

If you have Omin, it's a good idea to farm a while to make sure his gold find ability's cooldown fires at the same time as Azaka's ability enough times. You can do this manually if you wish, but it's a pain.

If you have Freely, before you reset, remember to swap in his Excitable feat to maximize favor gains (if you have it)
FAQ

Q: What about Paultin / Ishi?
A: After the Y1P2 update, neither of these champions is competitive with Jarlaxle for gold find, and Jarlaxle is easier to gear.

Q: What about Stoki / Makos?
A: While both have quite good gold find (albeit with very high ki stacks for Stoki), they both require kills to activate their gold find. This defeats the purpose of the Azaka farm, which decouples killing mobs from getting their gold.

Q: What about K'thriss - he's a Drow!?
A: He has a gold find penalty. Bruenor has a gold find bonus. One of these is better.

Q: How does Beadle's Long Rest ability interact with his Special Order ability?
A: The text says Special Order is only affected by Long Rest for Grimm, not Beadle, so there is no interaction.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
