---
uuid: 20230106050520
title: Speed Champions Blacksmith Priorities
created: 2023-01-06T05:05:20
updated: 2023-01-06T05:05:20
private: true
alias:
---

# [[Speed Champions Blacksmith Priorities]]

if you do not have   /   yet, just save the BS, you will need a lot of them and using scrolls on anything else is basically destroying the scrolls ( until very late game that is, then some other heroes might become viable targets, but that is not a point you should expect to reach within 6months)

BS prio 

1)   (Hewmaan) 3 progress/kill (3/1) this assumes 4 adjacent heroes until stated otherwise
2)   (Briv) 100% chance to skip 1 extra zone (1j)
3)   (Hewmaan) 5/1
4)   (Briv) 2j
5)  (Hewmaan)7/1 
6)  (Briv) 3j 
7)  (Hewmaan) 13/1
8)  (Briv) 4j ( important! do not exceed 400% skip, if you have a shiny epic, stay at 395% as any number above 400% and below 600% will make you land on bosses, which is bad for speed and on some adventures can mean you have to restart)
9)  (Hewmaan) 25/1  // think this is not possible anymore
10)  25/1 (3 adjacent heroes)

After that, you can save up to push   from 4j to 6j or higher in 1 go, or dump absolutely everything on   Artimas as he is the best scaling endgame dps, if you go the   6j+ route you will want to aim for 9j, 900% pure, for the same reason as going above 400%.   9j (a goal that is likely going to take you more than a year) makes you go 1-11-21-31

- https://discord.com/channels/357247482247380994/447160455694123028/965688262255583252

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Idle Champions of the Forgotten Realms]]
- 📡 Status:: #status/🌲 
