---
uuid: 20220516220017
title: Online Resources (GW2)
created: 2022-05-16T22:00:17.000Z
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---
Up:: [[Guild Wars 2]]

# [[Online Resources (GW2)]]

##### Websites
- [GW2Efficiency](https://gw2efficiency.com/)




---

## 📇 Additional Metadata

- 🗂 Type:: #type/game 
- Game:: #game/resources
  