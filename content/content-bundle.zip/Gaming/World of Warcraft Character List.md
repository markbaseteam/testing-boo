---
uuid: 20220510041337
title: World of Warcraft Character List
created: "2022-05-10T04:"
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---
Up:: [[Gaming MOC]]

http://eu.battle.net/wow/en/character/earthen-ring/bludskar/advanced
http://eu.battle.net/wow/en/character/earthen-ring/whytfethur/advanced

[http://eu.battle.net/wow/en/character/earthen-ring/Nekro](http://eu.battle.net/wow/en/character/earthen-ring/nekroseas/advanced)[seas/advanced](http://eu.battle.net/wow/en/character/earthen-ring/nekroseas/advanced)

http://eu.battle.net/wow/en/character/earthen-ring/longhschot/advanced

[http://eu.battle.net/wow/en/character/earthen-ring/Greyfli/advanced](http://eu.battle.net/wow/en/character/earthen-ring/greyfli/advanced)

http://eu.battle.net/wow/en/character/earthen-ring/shademon/advanced
http://eu.battle.net/wow/en/character/earthen-ring/euphoshas/advanced
http://eu.battle.net/wow/en/character/earthen-ring/blydeturner/advanced