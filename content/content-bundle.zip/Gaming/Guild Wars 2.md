---
uuid: 20220513065907
title: Guild Wars 2
created: 2022-05-13T06:59:07.000Z
updated: 2022-06-09T16:15:28.333Z
private: false
alias:
  - GW2
---

Up: [[Gaming MOC]]
# Guild Wars 2

## Time Played
- Joined:  Thursday, 17 December 2015
- To get time played: `/age`

## Review
- So far so good

## Guild
- Ghost Riders of Tyria

## Characters
- https://gw2efficiency.com/c/Ragthoru


[[Online Resources (GW2)]]

Gold Farm vid:
[Gold farm VID](https://www.youtube.com/watch?v=OdbqNNs3Ssg)

![[Pasted image 20220519165440.png]]


## Builds

Power Firebrand
https://metabattle.com/wiki/Build:Firebrand_-_Power_Firebrand

## Tools
- [GW2 Efficiency](https://gw2efficiency.com/)
	- Account Value
	- Dailies


### Gemstore Tier List:

![0f3ccbee929a21ab64270dd77be79cfa.png](../../../_resources/0f3ccbee929a21ab64270dd77be79cfa.png)

[GW2 Gemstore Items Tier List Maker](https://tiermaker.com/create/guild-wars-2-gemstore-items-tier-list-maker-1332377)


## Guides
- [[Galadbolg Guide - Ascended Weapon]]

## Addons

- [[Blish HUD]]


## Youtubers/Streamers

- Mukluk
- MightyTeapot

---
## 📇 Additional Metadata

- Type:: #type/game 
- Game:: #game/mmorpg
- Status:: #status/🟢
- Release Date:: 2012-08-28
- Platform:: PC
- Store:: [[Arena Net]]
- Publisher:: [[Arena Net]]