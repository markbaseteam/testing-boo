---
uuid: 20230531083105
title: Gaming MOC
created: 2023-05-31T08:31:05
updated: 2023-05-31T08:31:05
private: true
alias:
---

# [[Gaming MOC]]

## Currently actively playing

- [[Idle Champions of the Forgotten Realms]]
- [[Satisfactory (Game)]]
- [[Guild Wars 2]]
- [[Fortnite]]

---

## 📇 Additional Metadata

- 🗂 Type:: #type/moc 
- 🏷️ Tags:: 
- 📡 Status:: #status/🌲 
