---
uuid: 20220429100630
title: Galadbolg Guide - Ascended Weapon
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---
Up:: [[Guild Wars 2]]

# [[Galadbolg Guide - Ascended Weapon]]

Nice ascended weapon, easy peasy.

https://www.youtube.com/watch?v=SwLdE_CDPy8

