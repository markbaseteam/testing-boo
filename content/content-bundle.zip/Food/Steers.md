---
uuid: 20220726100814
title: Steers
created: 2022-07-26T10:08:14
updated: 2022-07-26T10:08:14
private: false
alias:
---

# [[Steers]]



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Food MOC]] [[Fast food]]
- 📡 Status:: #status/🌲 
