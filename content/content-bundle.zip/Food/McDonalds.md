---
uuid: 20220726102051
title: McDonalds
created: 2022-07-26T10:20:51
updated: 2022-07-26T10:20:51
private: false
alias:
---

# [[McDonalds]]

Fast Food Restaurant - Take aways

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::[[Fast food]] [[Food MOC]]
- 📡 Status:: #status/🌲 
