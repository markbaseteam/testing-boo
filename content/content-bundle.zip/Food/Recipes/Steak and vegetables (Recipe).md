---
uuid: 20220429120626
title: Steak and vegetables (Recipe)
created: 2022-04-29T12:06:26.000Z
updated: 2022-06-09T16:15:28.333Z
private: true
alias: null
---

# [[Steak and vegetables (Recipe)]]

- Prep-Time:: 15min    
- Cook-Time:: 45min   
- Meal:: Dinner
- Serves:: 4

## Ingredients
|             | Serving 1  | Serving 2  |
| ----------- | ---------- | ---------- |
| Ingredients | Qty/Wt/Vol | Qty/Wt/Vol |
| Steak       | 500g       |            |
|             |            |            |


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1

Type:: #type/recipe
