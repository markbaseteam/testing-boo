---
uuid: 20220521105642
title: Hotdogs (Recipe)
created: 2022-05-21T10:56:42.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
Meal:
  - Dinner
  - Lunch
  - Snack
---
Up:: [[Recipes Dashboard]]

# [[Hotdogs (Recipe)]]

Prep-Time:: 5min    
Cook-Time:: 10min   

Serves:: 4

## Ingredients
|                 | Serving 1  | Serving 2  |
| --------------- | ---------- | ---------- |
| Ingredients     | Qty/Wt/Vol | Qty/Wt/Vol |
| Cheese Grillers | 200g       |            |
| Hotdog Buns     | 12         |            |
| Smoked Viennas  | 250g       |            |
| Onion           | 1 sliced   |            |
|                 |            |            |


## Directions
- Heat cheese grillers in a pan
- Heat viennas either in microwave or in pot with a bit of water
- Brown the onions 
- Open the hot dog buns 
- Put either griller on vienna with a bit of the onion onto roll.

## Serving
- Serving 4

## Notes
- Notes 1

Type:: #type/recipe

