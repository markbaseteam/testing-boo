---
uuid: 20220520072241
title: Mash (Recipe)
created: 2022-05-20T07:22:41.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
Meal:
  - Breakfast
  - Dinner
  - Lunch
  - Snack
---

Up:: [[Recipes Dashboard]]
# [[Mash (Recipe)]]

Prep-Time:: 10 min    
Cook-Time:: 30min   

Serves:: 4-6

## Ingredients
|                 | Serving 1  | Serving 2  |
| --------------- | ---------- | ---------- |
| Ingredients     | Qty/Wt/Vol | Qty/Wt/Vol |
| Potatoes        | 1kg        |            |
| Butter          | 20g        |            |
| Salt and Pepper |            |            |

^db1e3d

## Directions
- Peel potatoes
- Cut into 8ths (half->half->half)
- Put on stove with water
- When soft, drain water.
- Use a masher or fork and mash potatoes
- Add 20g of butter, salt and pepper to taste

## Serving
- Serving 1

## Notes
- Notes 1

Type:: #type/recipe
