---
uuid: 20220726103209
title: Chicken and Vegetable (Recipe)
created: 2022-07-26T10:32:09
updated: 2022-07-26T10:32:10
private: false
alias:
---

# [[Chicken and Vegetable (Recipe)]]

Prep-Time:: 10min    
Cook-Time:: 30min   
Meal:: Dinner
Serves:: 2-4

## Ingredients
|                   | Serving 1  | Serving 2  |
| ----------------- | ---------- | ---------- |
| Ingredients       | Qty/Wt/Vol | Qty/Wt/Vol |
| Chicken Breasts   | 2          | 4          |
| Frozen Vegetables | 500g       | 1kg        |
|                   |            |            |


## Directions
- Put vegetables in a pot and put on the stove, bring to boil
- Season the chicken breasts, put in roasting pan and put in oven at 180C
- Check every 10min
- Cook till ready right through

## Serving
- Serving 2-4

## Notes
- [[Chicken]]
- [[Vegetables]]

Type:: #type/recipe
