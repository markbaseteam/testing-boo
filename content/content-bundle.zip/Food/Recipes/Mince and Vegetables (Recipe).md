---
uuid: 20220502143201
title: Mince and Vegetables (Recipe)
created: 2022-05-02T14:32:01.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---

# [[Mince and Vegetables (Recipe)]]

Prep-Time:: 5min    
Cook-Time:: 35min   
Meal:: Dinner
Serves:: 4

## Ingredients
| **Qty/Wt/Vol** | **Ingredients** |
| --- | --- |
|500g | mince|
|1kg| frozen vegetables|
|1| onion|
|20ml| coconut oil|
|30ml| Worcester Sauce|
|20ml| butter|
|To Taste | Salt|
|To taste | Pepper4

## Directions
- Put veg in pot, put stove on high heat.
- Cut onion 
- Brown onion in coconut oil
- Add mince and brown
- Add worcester sauce, salt and pepper to taste
- Add salt to veg while boiling
- Drain veg while hot and add butter.

## Serving
- Serving 1

## Notes
- Notes 1

Type:: #type/recipe 
