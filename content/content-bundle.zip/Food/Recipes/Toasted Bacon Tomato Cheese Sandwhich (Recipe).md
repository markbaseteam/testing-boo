---
uuid: 20220521110153
title: Toasted Bacon Tomato Cheese Sandwhich (Recipe)
created: 2022-05-21T11:01:53.000Z
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---
Up:: [[Recipes Dashboard]]
# [[Toasted Bacon Tomato Cheese Sandwhich (Recipe)]]

Prep-Time:: 15min    
Cook-Time:: 20min   
Meal:: Dinner
Serves:: 4

## Ingredients
|                            | Serving 1  | Serving 2  |
| -------------------------- | ---------- | ---------- |
| Ingredients                | Qty/Wt/Vol | Qty/Wt/Vol |
| Shoulder Bacon             | 500g       |            |
| Bread (White or Brown)     | 1          |            |
| White cheddar with peppers | 200g       |            |
| Onion                      | 1 sliced   |            |
| Tomato                     | 2 sliced   |            |
|                            |            |            |


## Directions
- Brown bacon till nice and crispy
- Slice onion and tomato
- Slice cheese into small slices
- Put bacon, tomato, onion and cheese on bread.
- Put in toaster (Sandwhich Press)
- Let toast till bread is toasted and cheese starts to melt.

## Serving
- Serving 4

## Notes
- Notes 1

Type:: #type/recipe
