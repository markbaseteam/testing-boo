---
uuid: 20220429120842
title: Steak with Broccoli and Potato Wedges (Recipe)
created: 2022-04-29T12:08:42.000Z
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---

# [[Steak with Broccoli and Potato Wedges (Recipe)]]

Prep-Time::  20 min    
Cook-Time::  45 min   
Meal:: Dinner
Serves:: 4

## Ingredients
|                 | Serving 1      | Serving 2      |
| --------------- | -------------- | -------------- |
| **Ingredients** | **Qty/Wt/Vol** | **Qty/Wt/Vol** |
| Rump            | 500g           |                |
| Broccoli        | 1kg            |                |
| Potato          | 500g (wedges)  |                |
|                 |                |                |


## Directions
1. Cut potatoes in wedges
2. Put in oven @ 180 degrees C till crispy brown
3. Spice meat and put in oven as well or pan fry
4. Put brocolli in pot with water and then put pot onto stove.
5. Add salt to brocolli.

## Serving
- Serving 4

## Notes
- Notes 1


Type:: #type/recipe
