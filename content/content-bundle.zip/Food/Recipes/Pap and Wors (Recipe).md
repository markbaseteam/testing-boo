---
uuid: 20220517074912
title: Pap and Wors (Recipe)
created: 2022-05-17T07:49:12.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
up:: [[Recipes Dashboard]]
# [[Pap and Wors (Recipe)]]

Prep-Time:: 10min    
Cook-Time:: 25min   
Meal:: Dinner 
Serves:: 4

## Ingredients
|                 | Serving 1      | Serving 2      |
| --------------- | -------------- | -------------- |
| **Ingredients** | **Qty/Wt/Vol** | **Qty/Wt/Vol** |
| Wors            | 500g           |                |
|                 |                |                |


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1

Type:: #type/recipe
