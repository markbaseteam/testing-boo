---
uuid: 20220517075812
title: BBQ chicken schnitzel and chips (Recipe)
created: 2022-05-17T07:58:12.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
up:: [[Recipes Dashboard]]
# [[BBQ chicken schnitzel and chips (Recipe)]]

Prep-Time:: 5min    
Cook-Time:: 35 min

Serves:: 4

## Ingredients
|                   | Serving 1  | Serving 2  |
| ----------------- | ---------- | ---------- |
| Ingredients       | Qty/Wt/Vol | Qty/Wt/Vol |
| Chicken Schnitzel | 6 pieces   |            |
| Oven bake chips   | 1 kg       |            |
| Mayonnaise        | 2 tbsp.     |            |


## Directions
- Bake Chicken Schnitzel and chips in oven till crispy.
- Server with a spoon of mayonnaise for dip.

## Serving
- Serving 4

## Notes
- Notes 1

Type:: #type/recipe
Meal:: Breakfast, Dinner
