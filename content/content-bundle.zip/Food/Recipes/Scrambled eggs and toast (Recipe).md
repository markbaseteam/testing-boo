---
uuid: 20220726102534
title: Scrambled eggs and toast (Recipe)
created: 2022-07-26T10:25:34
updated: 2022-07-26T10:25:34
private: true
alias: null
---
Up:: [[Recipes Dashboard]]

# [[Scrambled eggs and toast (Recipe)]]

Prep-Time:: 0min    
Cook-Time:: 0min   
Meal:: Breakfast
Serves:: 0

## Ingredients
|             | Serving 1  | Serving 2  |
| ----------- | ---------- | ---------- |
| Ingredients | Qty/Wt/Vol | Qty/Wt/Vol | 
|             |            |            |


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1

Type:: #type/recipe
