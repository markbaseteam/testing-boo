---
uuid: 20220726103118
title: Vetkoek with cheese and ham (Recipe)
created: 2022-07-26T10:31:18
updated: 2022-07-26T10:31:27
private: false
alias:
---
Up:: [[Recipes Dashboard]]

# [[Vetkoek with cheese and ham (Recipe)]]

Prep-Time:: 0min    
Cook-Time:: 0min   
Meal:: Dinner
Serves:: 0

## Ingredients
|             | Serving 1  | Serving 2  |
| ----------- | ---------- | ---------- |
| Ingredients | Qty/Wt/Vol | Qty/Wt/Vol | 
|             |            |            |


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1

Type:: #type/recipe
