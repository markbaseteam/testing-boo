---
uuid: 20220429120841
title: Mince and Macaroni (Recipe)
created: 2022-04-29T12:08:41.000Z
updated: 2022-06-09T16:15:28.332Z
private: true
alias: null
---

# [[Mince and Macaroni (Recipe)]]

Prep-Time::  10min    
Cook-Time::  10min   

## Ingredients
|                 | Serving 1      | Serving 2      |
| --------------- | -------------- | -------------- |
| **Ingredients** | **Qty/Wt/Vol** | **Qty/Wt/Vol** |
| Mince           | 1kg            |                |
| Macaroni        | 500g           |                |
| Onions          | 2 chopped      |                |
| Mushrooms       | 200g chopped   |                |
| Tomato Relish   | 1 can          |                |
| Spices          |                |                |
| Coconut Oil     | 10ml           |                |


## Directions
- Put macaroni on to cook
- Prepare the onions and brown with mushrooms
- Put in mince
- Add relish when mince is browned
- Drain macaroni when done
- Put in mince, mix, leave for 10min

## Serving
- Serving 6

## Notes
- Notes 1


Type:: #type/recipe
Meal:: Dinner

from  [[Mealplan 2022-04-06]]