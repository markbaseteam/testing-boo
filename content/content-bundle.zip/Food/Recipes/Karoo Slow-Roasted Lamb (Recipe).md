---
uuid: 20220429120841
title: Karoo Slow-Roasted Lamb (Recipe)
created: 2022-04-29T12:08:41.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
Meal:: Dinner

# [[Karoo Slow-Roasted Lamb (Recipe)]]

4 hr 10 min cooking time

10 minutes preparation time

Serves 6

Log in to bookmark recipe

Culinary Tip

Get to know your oven – all ovens even the expensive ones tend to change as they age so it is a good idea to get to know your oven by doing the bread test. Cover a baking tray with slices of bread – place into the oven at 180°C to bake for a few minutes. Remove the tray from the oven and observe which slices have browned the most – this will give you a good indication of where the “hot spots” are in your oven. When baking try to avoid placing a cake tin in the hot spot.

Ingredients

- 2 kg Leg of Lamb
- 2 - 3 Tablespoons of Olive Oil
- Robertsons MasterBlend for Roasts Rosemary and Garlic
- 3 Onions quarter
- 500 ml Stock
- 250 ml Dry Red Wine
- 1 Tablespoon of Treacle Sugar
- 700 g Medium-Sized Potatoes peeled and halved

Instructions

- Pre-heat oven to 120°C.
- Brush lamb with olive oil and rub Robertsons MasterBlend all over the Lamb.
- Place onions in a casserole dish just large enough to take the lamb (a cast iron casserole dish is ideal). Place lamb on top of the onions.
- Mix stock, red wine and treacle sugar together and pour around the lamb. Cover with a tight-fitting lid or foil.
- Roast at 150°C for approximately 3–4 hours or until meltingly tender.
- Add potatoes 1 hour before the end of cooking.
- Remove lamb and keep warm while reducing cooking liquids on top of the stove to a saucy consistency.

![Karoo Slow-Roasted Lamb](73ebb5a6a8f6c5b431718d80429f7362.jpg)