---
uuid: 20220520071917
title: Mash and Sausage (Recipe)
created: 2022-05-20T07:19:17.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
Up:: [[Recipes Dashboard]]
# [[Mash and Sausage (Recipe)]]

Prep-Time:: 20min    
Cook-Time:: 45min   
Meal:: Dinner
Serves:: 4

## Ingredients
|                 | Serving 1  | Serving 2  |
| --------------- | ---------- | ---------- |
| Ingredients     | Qty/Wt/Vol | Qty/Wt/Vol |
| Wors            | 500g       |            |
| Potatoes        | 1kg        |            |
| Salt and Pepper |            |            |

![[Mash (Recipe)#^db1e3d]]

## Directions
[[Mash (Recipe)]]

- Put Sausage (Wors) into pan into oven
- Check regularly

## Serving
- Serving 4

## Notes
- Notes 1

Type:: #type/recipe
