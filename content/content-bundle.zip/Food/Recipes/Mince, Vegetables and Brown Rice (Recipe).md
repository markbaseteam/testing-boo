---
uuid: 20220609043642
title: Mince, Vegetables and Brown Rice (Recipe)
created: 2022-06-09T04:36:42
last-modified: 2022-06-09T04:36:42
private: false
alias:
---

Up:: [[Recipes Dashboard]]
# [[Mince, Vegetables and Brown Rice (Recipe)]]

Prep-Time:: 10min    
Cook-Time:: 45min   
Meal:: Dinner 
Serves:: 6

## Ingredients
|                   | Serving 1  | Serving 2  |
| ----------------- | ---------- | ---------- |
| Ingredients       | Qty/Wt/Vol | Qty/Wt/Vol |
| Mince             | 500g       |            |
| Frozen Vegetables | 1kg        |            |
| Brown Rice        | 1cup       |            |


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1

---

## 📇 Additional Metadata

- 🗂 Type:: #type/recipe 
- 🏷️ Tags:: Variation of [[Mince and Vegetables (Recipe)]]
- 📡 Status:: #status/🌲 
