---
uuid: 20220429120841
title: Boerewors Rolls (Recipe)
created: 2022-04-29T12:08:41.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
Meal:
  - Dinner
  - Lunch
---

# [[Boerewors Rolls (Recipe)]]

Prep-Time::  5min    
Cook-Time::  30min   

## Ingredients
|                 | Serving 1      | Serving 2      |
| --------------- | -------------- | -------------- |
| **Ingredients** | **Qty/Wt/Vol** | **Qty/Wt/Vol** |
| Wors            | 500g           |                |
| Hot dog buns    | 12             |                |
| Onion           | 1 chopped      |                |
|                 |                |                |


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1


Type:: #type/recipe

