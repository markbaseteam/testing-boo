---
uuid: 20220520052258
title: Potato and Leak Soup (Recipe)
created: 2022-05-20T05:22:58.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
Up:: [[Recipes Dashboard]]
# [[Potato and Leak Soup (Recipe)]]

Prep-Time:: 2min    
Cook-Time:: 15min   
Meal:: Dinner
Serves:: 4

## Ingredients
|             | Serving 1  | Serving 2  |
| ----------- | ---------- | ---------- |
| Ingredients | Qty/Wt/Vol | Qty/Wt/Vol | 
|             |            |            |


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1

Type:: #type/recipe
