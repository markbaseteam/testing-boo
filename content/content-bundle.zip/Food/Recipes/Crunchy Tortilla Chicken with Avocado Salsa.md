---
uuid: 20220429120841
title: Crunchy Tortilla Chicken with Avocado Salsa
created: 2022-04-29T12:08:41.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
Meal:: Lunch
# [[Crunchy Tortilla Chicken with Avocado Salsa]]

04/11/2012 · by [Reeni](http://www.cinnamonspiceandeverythingnice.com/author/Cinnamon%20Girl/) · [56 Comments](http://www.cinnamonspiceandeverythingnice.com/crunchy-tortilla-chicken-with-avocado-salsa/#comments)

[![](de65d165c280659aeffe3483d5a939ab.jpg)](http://www.cinnamonspiceandeverythingnice.com/crunchy-tortilla-chicken-with-avocado-salsa/tortilla-chicken-with-avocado-salsa-1/)

I know the picky eater all too well. . . I have one in my family and I used to be one.

When you coat chicken in a seasoned mayonnaise mixture and adhere crushed up tortilla chips to it the picky eater will be the first one to the table. Especially since the smells wafting through the cracks in the oven door as it bakes is enough to drive anyone crazy with hunger!

I fully expected the picky eater to skip the avocado salsa but was I surprised when they not only ate it but really, *really* liked it. So much so that they almost broke out in a happy dance the next day at lunch time when they found out the leftovers had their name written all over them.

Super crunchy on the outside, a little bit spicy, tender and juicy on the inside with a Tex-mex flair – how can anyone resist?

*Not* this recovering picky eater!

[![](c480322143fcfdce9babd88e9fba8ae1.jpg)](http://www.cinnamonspiceandeverythingnice.com/crunchy-tortilla-chicken-with-avocado-salsa/tortilla-chicken-2/)

Crunchy Tortilla Chicken with Avocado Salsa

Rating: 5
Prep Time: 5 minutes
Cook Time: 20 minutes
Total Time: 25 minutes

Yield: 4 servings

 ![Crunchy Tortilla Chicken with Avocado Salsa](de65d165c280659aeffe3483d5a939ab.jpg)

Chicken coated in seasoned tortilla chips with an avocado salsa, super crunchy on the outside, tender and juicy in the middle!

Ingredients
1/2 cup mayonnaise

1 tablespoon lime juice

2 cloves garlic, finely chopped

2 tablespoons chopped fresh cilantro

1 teaspoon chili powder

4 boneless, skinless chicken breast halves (about 1-1/4 lbs.)

1 cup tortilla crumbs*
Salsa:
1 large ripe avocado, cut into cubes
2 roma tomatoes, seeds removed, diced
1/4 cup red onion, diced
1 tablespoon fresh cilantro or parsley, chopped
1 lime
sea salt and fresh black pepper
Instructions
1. Preheat oven to 425° F.

2. Combine mayonnaise, lime juice, garlic, cilantro and chili powder in small bowl; set aside.

3. Coat chicken with mayonnaise mixture, then tortilla crumbs. Arrange chicken on aluminum-foil-lined baking pan.

4. Bake 20 minutes or until chicken is thoroughly cooked.

5. Make the salsa while the chicken cooks. Combine avocado, tomato, onion and cilantro. Toss with a tablespoon or two of lime to taste and season to taste with salt and pepper.

6. Garnish, if desired, with the salsa and cilantro.

* For homemade tortilla crumbs, process 6 cups tortilla chips in food processor.

