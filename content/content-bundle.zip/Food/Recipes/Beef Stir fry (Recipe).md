---
uuid: 20220429120841
title: Beef Stir fry (Recipe)
created: 2022-04-29T12:08:41.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
Up:: [[Recipes Dashboard]]

# [[Beef Stir fry (Recipe)]]

Prep-Time::  10min    
Cook-Time::  10min   

## Ingredients
|                 | Serving 1      | Serving 2      |
| --------------- | -------------- | -------------- |
| **Ingredients** | **Qty/Wt/Vol** | **Qty/Wt/Vol** |
| Goulash         | 500g           |                |
| Frozen Stir Fry | 600g           |                |
|                 |                |                |

## Directions
- Brown goulash in 10ml coconut oil
- Add seasoning
- Place vegetables on top until thawed
- Stir till veggies nice and ready

## Serving
- Serving 1

## Notes
- Notes 1


Type:: #type/recipe
Meal:: Dinner
Category:: Keto


