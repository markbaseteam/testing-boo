---
uuid: 20220608220737
title: Bobotie - South African curried mince pie (Recipe)
created: 2022-06-08T22:07:37.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---
Meal:: Dinner, Lunch

Up:: [[Recipes Dashboard]]


# [[Bobotie - South African curried mince pie (Recipe)]]

This traditional South African dish incorporates mildly spiced curried mince with a savoury custard topping.

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| *0:10* To Prep | *1:07* To Cook | *22* INGREDIENTS | *CAPABLE COOKS* DIFFICULTY | *4* SERVINGS | 4.5 AVG RATING (2 Members) |


![Bobotie (South African curried mince pie)](7c041e01101e9ef721356b5b31f3cea8.jpg)

delicious.
delicious. - August 2013	, Page 58
Recipe by Valli Little
Photography by Simon Barnes, Ben Dearnley & Jeremy Simons

- Ingredients
- Nutrition
- Specials
- 1/2 cup (35g) fresh breadcrumbs
- 1 cup (250ml) milk
- 2 tablespoons olive oil
- 1 each onion and carrot, finely chopped
- 2 garlic cloves, crushed
- 5cm piece ginger, grated
- 1kg beef mince
- 2 tablespoons mild curry powder
- 6 fresh curry leaves, chopped, plus extra to serve (see notes)
- 1/2 cup (85g) raisins
- 2 tablespoons slivered almonds, toasted
- 2 tablespoons fruit chutney (see notes) or spiced tomato chutney
- 1 cup (250ml) beef stock
- Juice of 1 lemon
- 2 eggs
- 1/2 teaspoon ground turmeric

#### Apple salad

- 1 rooibos tea bag (see notes)
- 2 teaspoons honey
- 1 teaspoon Dijon mustard
- Juice of 1/2 lemon
- 150g mixed rocket and baby spinach
- 1 apple, thinly sliced

Select all ingredients
Add to my Shopping List

- Method
- Notes

1. Step 1
Preheat oven to 180°C. Soak breadcrumbs in 1/2 cup (125ml) milk until needed.
2. Step 2

Meanwhile, heat the oil in a large, deep frypan over medium heat. Add onion and carrot, then cook, stirring, for 3-4 minutes until soft. Add the garlic and ginger, then cook for a further 2 minutes or until fragrant. Add the mince and cook, breaking up lumps with a wooden spoon, for 5-6 minutes until browned. Stir in the curry powder, curry leaves, raisins and almonds, then cook for 2 minutes. Stir in the chutney, beef stock, lemon juice and breadcrumb mixture. Season, bring to a simmer, then divide mixture among four 2-cup (500ml) ovenproof dishes. Cover with foil and bake for 25-30 minutes.

3. Step 3

Beat the egg, turmeric and remaining 1/2 cup (125ml) milk in a bowl. Remove dishes from oven, then discard foil and pour over egg mixture. Bake for a further 20-25 minutes or until the topping is golden and set. Cool for 5 minutes.

4. Step 4

Meanwhile, for the salad, soak tea bag in 1/4 cup (60ml) hot water for 10 minutes to infuse, then cool. Discard tea bag and mix with honey, mustard and lemon juice. Season, then toss with leaves and apple

5. Step 5
Garnish the bobotie with the extra curry leaves, and serve with the salad.

Find recipes that make the most of seasonal produce in our [spring collection](http://www.taste.com.au/recipes/collections/spring+recipes). You may also enjoy our [salad collection](http://www.taste.com.au/recipes/collections/salad+recipes) and [healthy mains](http://www.taste.com.au/recipes/collections/healthy+mains) collection.
