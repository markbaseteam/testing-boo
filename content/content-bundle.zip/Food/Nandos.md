---
uuid: 20220726102605
title: Nandos
created: 2022-07-26T10:26:05
updated: 2022-07-26T10:26:05
private: false
alias:
---

# [[Nandos]]

Fast Foods, take aways, healthiest of the lot imo.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Food MOC]] [[Fast food]]
- 📡 Status:: #status/🌲 
