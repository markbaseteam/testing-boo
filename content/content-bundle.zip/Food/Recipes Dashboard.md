---
uuid: 20220517075535
title: Recipes Dashboard
created: 2022-05-17T07:55:35.000Z
updated: 2022-06-09T16:15:28.332Z
private: false
alias: null
---

# [[Recipes Dashboard]]

```dataview
TABLE Meal, Serves, Prep-Time, Cook-Time
FROM #type/recipe AND -"_meta"
SORT Cook-Time ASC

```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/dashboard 