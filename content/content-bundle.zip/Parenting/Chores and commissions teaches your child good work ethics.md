---
uuid: 20220802071609
title: Chores and commissions teaches your child good work ethics
created: 2022-08-02T07:16:09
updated: 2022-08-02T07:16:09
private: false
alias:
---
Up:: [[Parenting]]

# [[Chores and commissions teaches your child good work ethics]]

- If you start your kids on commission at a young age, they’re off to a great start for earning money outside of the home as teens. And that work ethic will stick with them into adulthood. ([View Highlight](https://instapaper.com/read/1507305524/19778458))
    - Note: starting early with letting your children earn commission for work done, will set them up for success later on in life.

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[Why Your Kids Don't Need an Allowance]]
- Status:: #status/🌲 
- Tags:: [[Finance]], [[Parenting]], [[Money]]