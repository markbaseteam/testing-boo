---
uuid: 20220520071449
title: Chore system for our children
created: 2022-05-20T07:14:49.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

Up:: [[Parenting]]

# [[Chore system for our children]]

- Watched [[@Dave Ramsey]] - [Equipping Your Kids to Handle Money - Dave Ramsey Part 1 - YouTube](https://www.youtube.com/watch?v=2fAWF5Ih5JQ)
	- 3 types of chores
		- Cause I said so and we need some help
		- Act of love to your mom (helping in the kitchen)
		- Attach monetary value
	- [[What is a chore|Chore]] is paid on the week, meaning, if they skip a day, they do not get paid for that chore
	- 5 chores
	- 2 easy, 3 not so easy
	- R20 per chore per week
	- R100 per week
	- R400 per month


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- Tags:: [[Parenting]] [[Money]]
