---
uuid: 20220802071531
title: Chore commission should be what you think it should be
created: 2022-08-02T07:15:31
updated: 2022-08-02T07:15:31
private: true
alias:
---

# [[Chore commission should be what you think it should be]]

- First, keep the jobs and the pay age-appropriate. ([View Highlight](https://instapaper.com/read/1507305524/19778441))
    - Note: keep commission for chores age appropriate. and it is what you think, there is no set value to use.

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[Why Your Kids Don't Need an Allowance]]
- Status:: #status/🌲 
- Tags:: [[Parenting]], [[Money]], [[Finance]], [[Chores]]