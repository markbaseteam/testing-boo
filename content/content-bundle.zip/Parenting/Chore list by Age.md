---
uuid: 20220429120842
title: Chore list by Age
created: 2022-04-29T12:08:42.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

Up:: [[Parenting]]

# [[Chore list by Age]]


- https://childdevelopmentinfo.com/chores/the-ultimate-list-of-age-appropriate-chores/#gs.yt2u7c
- https://www.focusonthefamily.com/parenting/age-appropriate-chores-for-kids/#two
- https://www.thespruce.com/age-appropriate-chore-charts-1900357
*** 

2-3
-   Help [make the bed](https://www.thespruce.com/how-to-make-a-bed-1900312).
-   Pick up toys and books.
-   Put laundry in the hamper or to the laundry room.
-   Help feed pets.
-   Help wipe up messes.
-   Dust with socks on their hands.
-   [Mop](https://www.thespruce.com/how-to-mop-a-floor-1901114) in areas with help.

4-5
-   Clear and set the table.
-   Dust.
-   Help out in cooking and preparing food.
-   Carrying and putting away groceries.

6-8:
-   Take care of pets.
-   Vacuum and mop.
-   Take out ​the trash.
-   Fold and put away laundry.

9-12
-   Help wash the car.
-   Learn to [wash dishes](https://www.thespruce.com/best-dish-scrubbers-4164819) or load the dishwasher.
-   Help prepare simple meals.
-   [Clean the bathroom](https://www.thespruce.com/clean-the-bathroom-in-15-minutes-1900093).
-   Rake leaves.
-   Operate the washer and dryer.

![[55b6bdc99e7252809c8e06e0f2aa5592.jpg]]

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
