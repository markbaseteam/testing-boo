---
uuid: 20220806065503
title: How to Solve a Rubik's Cube, Step by Step
created: 2022-08-06T06:55:03
updated: 2022-08-07T21:54:35
private: false
alias:
---

# How to Solve a Rubik's Cube, Step by Step

> Follow the eight steps described in this video and you too can start solving Rubik's cubes faster ... and faster ... and faster.

**Step Three: Solve the First Layer**

Time to learn your first algorithms. The following “trigger moves” are the most basic of the bunch:

*   Right Trigger = R U R’
*   Left Trigger = L’ U’ L

Look for white stickers on the top layer that face the sides. (If you find a white sticker on the top face of the cube, or on the bottom layer of the cube pointing outward, we’ll deal with it later.) Each white sticker should be on a corner piece with three stickers. Rotate the top face of the cube so that the sticker beside the white sticker that is also outward facing (i.e., not the sticker on the top) diagonally matches the center of the same color.

Once you’ve paired them, face the color-matched stickers toward you. If the matched sticker in the top layer is right of the center, perform the Right Trigger. If the matched sticker is left of center, perform the Left Trigger.

If you have a white sticker facing the top, position the white sticker over something that is not white (because it will disrupt whatever is underneath), and, depending on if the piece is on the right or on the left, perform the following algorithm:

**R, U, R’, R, U, R’**

Or

**L’, U, L, L’, U, L**

If you have an outward facing white sticker in the bottom layer, face it toward you and position the cube so that it is either in the bottom left or bottom right corner of the side facing you, and perform either the left or right trigger, respectively, to relocate it to the top face of the cube.

**Step Four: Solve the Middle Layer**

Identify edge pieces on the top layer that do not have yellow stickers. (If it has a yellow sticker, it belongs on the top and not in the middle.) Once you find an edge without a yellow sticker, rotate the top face of the cube until the outward facing sticker on that edge piece is directly over the center piece of the same color.

Once it matches, look at the upward-facing sticker on that edge piece. That sticker will match the center on either the left or the right.

If it matches on the right, perform the following algorithm:

**U + Right Trigger**

Doing so will disturb the first layer. Fix the displaced white corner sticker as you did in step three.

If it matches on the left, perform the following algorithm:

**U’ + Left Trigger**

Doing so will disturb the first layer. Fix the displaced white corner sticker as you did in step three.

Occasionally you will find no edge pieces in the top layer without yellow stickers but the middle layer is not solved. In such cases, displace them is-matched middle-layer edge piece by performing the left or right trigger. There should now be an edge piece in the top layer without a yellow sticker. Solve for it as described above.

**Step Five: Create the Yellow Cross**

The goal of this step is to create a yellow cross on the upward-pointing face of the cube. This entire step hinges on the following algorithm:

**F U R U’ R’ F’**

If your top face has no yellow edge pieces, perform ***F U R U’ R’ F’. If your top face has two yellow edge pieces such that they form a line with the center yellow piece, orient the cube such that the three yellow stickers form a vertical line and perform ***F U R U’ R’ F’. If your top face has two yellow edge pieces such that they form a backwards L, rotate the top face of the cube until the edge pieces are at the 12 and 9 positions of a clock and perform ***F U R U’ R’ F’. At this point, the top face of your cube should resemble a yellow cross.

![row of 3 by 3 grids](https://media.wired.com/photos/5d703a6565761f0009b65274/master/w_1600%2Cc_limit/Science_2.jpg)

Tyson Mao

---

**Step Six: Solve the Yellow Face**  
The goal of this step is to completely solve the top face of your cube. When you’re finished, that face should be entirely yellow. For this step, you will use the following algorithm:

**R U R’ U R U2 R’**

Begin by inspecting the top face of your cube. How many corners have yellow stickers on top?

If you have zero or two, hold the cube so a yellow sticker is in the upper right hand corner of the face in your left hand, i.e. here:


![a 4 by 3 grid with x at bottom left](https://media.wired.com/photos/5d703a65838bb50008a01be4/master/w_1600%2Cc_limit/Science_3.jpg)

---

...and perform the algorithm **R U R’ U R U2 R’**.

If you have one corner with yellow on top, it will look like there’s a fish on the top face of your cube. Rotate that face until the fish is pointing down and to the left, like so:

![3 by 3 grid](https://media.wired.com/photos/5d703a65434da5000814caaa/master/w_1600%2Cc_limit/Science_4.jpg)

Tyson Mao

...and perform the algorithm **R U R’ U R U2 R’**.

You might have to orient the fish and perform the algorithm one last time. Once you have, the yellow face will be entirely solved.

**Step Seven: Position the Corners of the Cube**

Time for a new algorithm:

**L’ U R U’ L U R’ R U R’ U R U2 R’**

The above algorithm swaps corners A and B. Note that the eighth step of the algorithm undoes the seventh. That’s intentional, because it will make memorizing the algorithm easier: Notice that R U R’ U R U2 R’ is the same algorithm you used in step six.

Use this new algorithm to position all four corners in the correct place. If you have to switch two corners diagonally, perform the algorithm once, then reposition and perform it a second time.

![an A and B in a grid](https://media.wired.com/photos/5d703a650a42d80009628cd9/master/w_1600%2Cc_limit/Science_5.jpg)


**Step Eight: Position Edges**  
The goal of this step is to cycle the position of the cube’s edge pieces. The following algorithms will cycle the positions of the edge pieces labeled X, Y, and Z in a clockwise or counter-clockwise fashion, respectively:

**F2 U R’ L F2 L’ R U F2 (clockwise)**

**F2 U’ R’ L F2 L’ R U’ F2 (counter-clockwise)**



![a grid with letters](https://media.wired.com/photos/5d703a659f42280008fb943e/master/w_1600%2Cc_limit/Science_last.jpg)

Tyson Mao

If one face’s edge pieces are already correctly positioned, orient that face away from you and perform whichever algorithm will cycle the remaining edge pieces in the appropriate direction.

If all four edge pieces are misplaced, perform the counterclockwise algorithm once, position the side with the solved corners away from you, and perform it a second time.


# [[How to Solve a Rubik's Cube, Step by Step]]

- Author:: Wired
- Category::  website
- URL::  [Source](https://www.wired.com/story/how-to-solve-a-rubiks-cube-step-by-step/)
- Youtube:: https://www.youtube.com/watch?v=R-R0KrXvWbc
- Rating:: 5

## Learn by elaboration


---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/website 
- 🏷️ Tags:: [[Puzzles]]
- 📡 Status:: #status/🌲 

