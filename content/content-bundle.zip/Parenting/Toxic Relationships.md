---
uuid: 20220726103231
title: Toxic Relationships
created: 2022-07-26T10:32:31
updated: 2022-07-26T10:32:31
private: false
alias:
---

# [[Toxic Relationships]]

A relationship can be classified as toxic in my opinion when you are being manipulated, taken advantage of or made to feel guilty by people that are overstepping your personal boundaries.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Boundaries]]
- 📡 Status:: #status/🌲 
