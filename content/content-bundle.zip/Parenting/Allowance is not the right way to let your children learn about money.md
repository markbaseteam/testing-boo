---
uuid: 20220802071501
title: Allowance is not the right way to let your children learn about money
created: 2022-08-02T07:15:01
updated: 2022-08-02T07:15:01
private: true
alias:
---

# [[Allowance is not the right way to let your children learn about money]]

- Even the word “allowance” implies a child is entitled to a certain amount of money just for living and breathing. ([View Highlight](https://instapaper.com/read/1507305524/19778409))
    - Note: allowance can cause your child to get a sense of entitlement. it can also mean that they are not good enough, so you have to make an allowance for them.

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[Why Your Kids Don't Need an Allowance]]
- Status:: #status/🌲 
- Tags:: [[Parenting]], [[Money]], [[Chores]], [[Finance]]