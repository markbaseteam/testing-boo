---
uuid: 20220527041149
title: How to properly Socialize Children
created: "2022-05-27T04:"
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---
Up:: [[Parenting]]

# [[How to properly Socialize Children]]

URL:: [[@Jordan Peterson]] [How to Properly Socialize Children](https://www.youtube.com/watch?v=FXwZtg85zgU)

---

## 📇 Additional Metadata

- 🗂 Type:: #type/resoure
- Source:: #source/video 
- 🏷️ Tags:: [[Socialize Child]]
- 📡 Status:: #status/🌲 