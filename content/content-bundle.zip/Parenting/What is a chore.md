---
uuid: 20220520071551
title: What is a chore
created: 2022-05-20T07:15:51.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias:
  - chore
  - What is a chore?
---

Up:: [[Parenting]]

# [[What is a chore|What is a chore?]]

> A chore is **a duty or task you're obligated to perform, often one that is unpleasant but necessary**. Washing the dishes is a chore, and so is completing a homework assignment you aren't excited about. Sometimes a thing that you wanted to do can become a chore if it ceases to be fun or interesting.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 📡 Status:: #status/🌲 
