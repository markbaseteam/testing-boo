---
uuid: 20230531081332
title: Parenting
created: 2023-05-31T08:13:32
updated: 2023-05-31T08:13:32
private: true
alias:
---

# [[Parenting]]

The constant and daily pursuit of creating healthy and well-adjusted human beings.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: 
- 📡 Status:: #status/🌲 
