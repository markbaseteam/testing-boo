---
uuid: 20220503111114
title: Socialize Child
created: "2022-05-03T11:"
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

# [[Socialize Child]]

- https://www.youtube.com/watch?v=FXwZtg85zgU 