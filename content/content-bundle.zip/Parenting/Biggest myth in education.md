---
uuid: 20220520214804
title: Biggest myth in education
created: 2022-05-20T21:48:04.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

# [[Biggest myth in education]]


- Watched [The biggest Myth in Education](https://www.youtube.com/watch?v=rhgwIhB58PA)
	- VARK learning styles
	- No evidence for learning styles actually work or exist
	- Best to work with as many different learning tools as you can
		- Multi-modal approaches
			- Where you use words and pictures together
			- Multimedia-effect
		- People learn best when they are actively thinking about the material and solving problems
		- To Watch [The Science of Thinking](https://www.youtube.com/watch?v=UBVV8pch1dM)

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- Source:: #source/video 
- URL:: https://www.youtube.com/watch?v=rhgwIhB58PA
- Tags:: [[Parenting]] [[Learning]]
- 
