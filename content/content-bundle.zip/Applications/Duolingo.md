---
uuid: 20220502034243
title: Duolingo
created: 2022-05-02T03:42:43.000Z
updated: 2022-06-09T16:15:28.331Z
private: false
alias: null
---

# [[Duolingo]]


- Category:: mobile application
- URL:: https://www.duolingo.com/
- Status:: #status/🌲 
- Tags:: [[Learning]] [[Language]] 
- (Rating):: 4/5