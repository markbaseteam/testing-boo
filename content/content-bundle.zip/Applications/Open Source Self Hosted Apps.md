---
uuid: 20220429120809
title: Open Source Self Hosted Apps
created: 2022-04-29T12:08:09.000Z
updated: 2022-06-09T16:15:28.331Z
private: false
alias: null
---

# [[Open Source Self Hosted Apps]]


- A list of self hosted applications available for install on your own locally hosted server, either with [[Docker]] or other means.
	- Some examples:
		- 
* Url:: https://github.com/awesome-selfhosted/awesome-selfhosted
* 

---
## 📇 Additional Metadata

* Tags:: [[Self Hosted Applications]]
* Status:: #status/🌿
