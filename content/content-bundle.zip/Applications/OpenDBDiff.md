---
uuid: 20220502155626
title: OpenDBDiff
created: 2022-05-02T15:56:26.000Z
updated: 2022-06-09T16:15:28.331Z
private: false
alias: null
---

# [[OpenDBDiff]]

Sql Compare tool