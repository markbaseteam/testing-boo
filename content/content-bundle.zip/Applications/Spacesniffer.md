---
uuid: 20220503193936
title: Spacesniffer
created: 2022-05-03T19:39:36.000Z
updated: 2022-06-09T16:15:28.331Z
private: false
alias: null
---

# [[Spacesniffer]]

- Author:: Uderzo Umberto
- Category:: Desktop application
- URL:: http://www.uderzo.it/main_products/space_sniffer/
- (Rating):: 5

---
## 📇 Additional Metadata

- 🏷 Tags:: space, windows, hdd, hard, disk, drive
- 📡 Status:: #status/🌲 



