---
uuid: 20220609182138
title: Ali Abdaal
created: 2022-06-09T18:21:38
updated: 2022-06-14T08:49:33
private: false
alias:
- "Ali"
- "Ali Abdaal"
---

# [[@Ali Abdaal|Ali Abdaal]]

## Contact Info

Email::
Phone::
Birthday::
Occupation::

## Reminders
- 

## Notes 
- 

## Log

### 2022-06-09 18:21 - Initial Creation
- How did you meet?


----
## 📇Additional Metadata

- 📁 Type:: #type/person 
- 👤 Person:: #person/public 
- 🏷️Tags:: [[Productivity  MOC]], [[Writing]]