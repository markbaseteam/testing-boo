---
uuid: 20220513061509
title: "@Jordan Peterson"
created: 2022-05-13T06:15:09.000Z
updated: 2022-06-09T16:20:14.565Z
private: false
alias:
  - Jordan
  - Jordan Peterson
---

# [[@Jordan Peterson]]

## ℹ️ About
- 

## Resources
- 

---
Type:: #type/person 
Person:: #person/public 
