---
uuid: 20220513075540
title: @Dave Ramsey
created: 2022-05-13T07:55:40.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: 
  - Dave
  - Dave Ramsey
---

Up:: [[People Dashboard]]
# [[@Dave Ramsey|Dave Ramsey]]
### Resources
- 


Type:: #person/public