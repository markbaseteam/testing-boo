---
uuid: 20220429120841
title: "@Naval Ravikant"
created: 2022-04-29T12:08:41.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias:
  - Naval
  - Naval Ravikant
---

# [[@Naval Ravikant|Naval Ravikant]]

## Contact Info

[WikiPedia Link](https://en.wikipedia.org/wiki/Naval_Ravikant)
[Twitter](https://twitter.com/naval)
[Blog](https://nav.al/)

from  [[Naval Ravikant - Retirement is when you don_t have to sacrifice today in hope of a better tomorrow]]
## Reminders
- 

## Notes 
- 

## Log

### 2022-04-29 12:08 - Initial Creation
- How did you meet?


----
## 📇Additional Metadata

- 📁 Type:: #type/person 
- 👤 Person: #person/public

