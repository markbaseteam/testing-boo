---
uuid: 20220726102238
title: Dunbar's number
created: 2022-07-26T10:22:38
updated: 2022-07-26T10:22:38
private: true
alias:
---

# [[Dunbar's number]]

The number of relationships that you can maintain reliably is 150, ranging from 5-10 Familial, up to 20 close friends, 50 friends and 100 acquaintances.



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Social]] [[Goals MOC]]
- 📡 Status:: #status/🌲 
