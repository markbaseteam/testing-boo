---
uuid: 20220517054521
title: "@Ben Hong"
created: 2022-05-17T05:45:21.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias:
  - Ben
  - Ben Hong
---

# [[@Ben Hong|Ben Hong]]

Youtube:: https://www.youtube.com/channel/UC0cNqew5aUOzYB5XmmkriWw
Twitch:: 


#### How did we meet?
- Was looking at videos of [[Obsidian (App)]]

## Log

### 2022-05-17 05:45 - Initial Creation

----
## 📇Additional Metadata

📁 Type:: #type/person 
👤 Person: #person/public 