---
uuid: 20220502211406
title: Drink sayings
created: 2022-05-02T21:14:06.000Z
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---
> [!quote]
Heres to love
Heres to honour
If u cant cum in her
Cum on her


---
Type:: #type/quote 
