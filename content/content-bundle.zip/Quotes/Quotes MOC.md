---
uuid: 20221110112700
title: Quotes MOC
created: 2022-11-10T11:27:00
updated: 2022-11-10T11:27:00
private: true
alias:
---

# [[Quotes MOC]]

```dataview
LIST 
FROM [[Quotes MOC]]
```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/moc 
- 🏷️ Tags::
- 📡 Status:: #status/🌲  
