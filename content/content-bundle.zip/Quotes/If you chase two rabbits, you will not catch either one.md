
---
uuid: 20220610065742
title: If you chase two rabbits, you will not catch either one
created: 2022-06-10T06:57:42
last-modified: 2022-06-10T06:58:05
private: false
alias:
---

# [[If you chase two rabbits, you will not catch either one]]


> _"If you chase two rabbits, you will not catch either one."_
 _-Russian Proverb_

- This to me means that if you try to do too many things, you will not complete anything to a satisfactory degree

---

## 📇 Additional Metadata

- 🗂 Type:: #type/quote 
- 🏷️ Tags:: [[Productivity  MOC]], [[Multitasking]], [[Monotasking]]
- 📡 Status:: #status/🌲 
