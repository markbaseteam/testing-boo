---
uuid: 20220526083526
title: Curiosity is one of the permanent and certain characteristics of a
  vigorous intellect
created: 2022-05-26T08:35:26.000Z
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---

# [[Curiosity is one of the permanent and certain characteristics of a vigorous intellect]]

> [!quote]
> _"Curiosity is one of the permanent and certain characteristics of a vigorous intellect."_
>
_-Samuel Johnson_ ^411699

---
## Additional Metadata

Type:: #type/quote 
Origin:: [[2022-05-26]]