---
uuid: 20220525043422
title: Naval Ravikant - Retirement is when you don_t have to sacrifice today in
  hope of a better tomorrow
created: "2022-05-25T04:"
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---

> [!quote] 
> [[@Naval Ravikant]] - Retirement is when you don't have to sacrifice today in hope of a better tomorrow

