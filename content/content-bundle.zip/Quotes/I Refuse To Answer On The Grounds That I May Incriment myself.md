---
uuid: 20220513060439
title: I Refuse To Answer On The Grounds That I May Incriment myself
created: "2022-05-13T06:"
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---

> [!quote]
I Refuse To Answer On The Grounds That I May Incriminate Myself Or Get My Butt Kicked By Loved Ones



#### Internal context
Was speaking with Dewald about perks of married life with Riana bringing coffee, this quote was a funny when he said he is missing out


***