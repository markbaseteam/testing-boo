---
uuid: 20221004081315
title: A jack of all trades is a master of none
created: 2022-10-04T08:13:15
updated: 2022-10-04T08:13:15
private: true
alias:
---

# [[A jack of all trades is a master of none]]

but oftentimes better than a master of one

- https://medium.com/@tabithawasserman/the-complete-saying-was-originally-a-jack-of-all-trades-is-a-master-of-none-but-oftentimes-5f4af01a72c6
- 

---

## 📇 Additional Metadata

- 🗂 Type:: #type/quote 
- 🏷️ Tags:: [[Quotes MOC]]
- 📡 Status:: #status/🌲  
