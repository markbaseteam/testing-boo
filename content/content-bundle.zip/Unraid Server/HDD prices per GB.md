---
uuid: 20220429100643
title: HDD prices per GB
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---
# HDD prices per GB

Hard disk drive gigabyte

Newegg: https://edwardbetts.com/price_per_tb/
Amazon: https://diskprices.com/?locale=us&condition=new&disk_types=external_hdd,internal_hdd,internal_sshd,internal_sas