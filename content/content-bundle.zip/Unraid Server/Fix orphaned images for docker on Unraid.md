---
uuid: 20221214040738
title: Fix orphaned images for docker on Unraid
created: 2022-12-14T04:07:38
updated: 2022-12-14T04:07:44
private: true
alias:
---

#### **Question**
# [[Fix orphaned images for docker on Unraid]]

#### **Answer**
This can happen if you’re [manually messing around](http://dtbaker.net/random-linux-posts/how-to-replace-drives-on-unraid/) with the location of docker configuration files on the hard drives.

If the orphan image is from a Community Applications installed docker image, simply follow these steps:

1.  Go to the App menu
2.  Choose Previous Apps on the left hand side
3.  Click the reinstall icon on the app associated with the orphan image
4.  Confirm the data/config directories match those that already exist on unraid
5.  Run the reinstall
6.  The broken docker app will be back up and running with all the saved config and data available

#### **Links/related reading** 
- https://dtbaker.net/blog/fix-orphan-image-in-unraid-docker/

---
## 📇Additional Metadata

- 📁Type:: #type/question-answer 
- 🏷️Tags:: [[Unraid MOC]]
- 📡Status:: #status/🌲 

