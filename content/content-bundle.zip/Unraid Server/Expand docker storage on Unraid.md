---
uuid: 20220620202638
title: Expand docker storage on Unraid
created: 2022-06-20T20:26:38
updated: 2022-06-20T20:30:02
private: false
alias:
 - "How do I increase the size of my docker.img file?"
---

#### **Question**
# [[Expand docker storage on Unraid]]

#### **Answer**
- Go to settings - Docker Settings.
- Set Enable Docker to be "No"
- Apply.
- Switch to Advanced View (Top Right)
- Change the size of the image.
- Set Enable Docker to be "yes"
- Apply
- Done.

#### **Links/related reading** 
- https://forums.unraid.net/topic/57181-docker-faq/#comment-565307

---
## 📇Additional Metadata
- 📁Type:: #type/question-answer 
- 🏷️Tags:: [[Unraid MOC]], [[Docker]]
- 📡 Status:: #status/🌲 


