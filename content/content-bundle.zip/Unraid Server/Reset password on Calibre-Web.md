---
uuid: 20230105130844
title: Reset password on Calibre-Web
created: 2023-01-05T13:08:44
updated: 2023-01-05T13:08:44
private: true
alias:
---

# [[Reset password on Calibre-Web]]

1.  using putty.exe to connect to your NAS, login in with `sudo -i`
2.  run command  
    `docker exec -ti linuxserver-calibre-web1 bash` , note that `linuxserver-calibre-web1` is the container's name and the container should be running.
3.  run `cd /app/calibre-web`
4.  run `python3 cps.py -s admin:admin123`
5.  What I got: `Error starting server: [Errno 98] Address already in use: ('', 8083)`  
    Can you share how to fix this? Thanks.

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
