---
uuid: 20221108155319
title: Nextcloud
created: 2022-11-08T15:53:19
updated: 2022-11-08T15:53:19
private: true
alias:
---

# [[Nextcloud]]

Fixes:
- Invalid or negative modification date
	- https://github.com/nextcloud/desktop/wiki/How-to-fix-the-error-invalid-or-negative-modification-date#files-stored-on-the-server
	- https://github.com/nextcloud/desktop/issues/4378#issuecomment-1239807009 (Specific for the Unraid images)
		- Add additional packages on the image
		- `apk add --update findutils mysql mysql-client`


### Updating:

![[https://forums.unraid.net/uploads/monthly_2022_12/image.png.76ad812be088c36d15a367318c7c427a.png]]


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Unraid (Bruce)]]
- 📡 Status:: #status/🌲 
