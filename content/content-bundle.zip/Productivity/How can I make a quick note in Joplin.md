---
uuid: 20220516091440
title: How can I make a quick note in Joplin
created: "2022-05-16T09:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

* **Question** – How can I make a quick note in Joplin
* **Answer**
just add this to your Autohotkey script and adjust the path for joplin:
```
;joplin 'new note'
#n::
IfWinExist Joplin
{
  WinActivate, Joplin
}
Else run c:\_office_\joplin\joplinportable.exe
WinWaitActive, Joplin
Send, ^n
return
```
* **Tags** – joplin workaround shortcut, autohotkey
* **Links/related reading** – [Joplin Windows + N Create a new note](https://discourse.joplinapp.org/t/windows-n-creates-a-new-note/4409/6)

---

