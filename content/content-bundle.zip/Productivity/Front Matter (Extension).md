---
uuid: 20220614055007
title: Front Matter (Extension)
created: 2022-06-14T05:50:07
updated: 2022-06-14T05:50:07
private: false
alias:
---

# [[Front Matter (Extension)]]

Front Matter is an integral Visual Studio Code extension that simplifies operating and managing your markdown articles. ([View Highlight](https://instapaper.com/read/1507305736/19778511))
    - Note: a vs code extension to edit MD files. works well with many static site generators, including GatsbyJS, Hugo, Jeckyll

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[Introduction  Front Matter]]
- Status:: #status/🌲 
- Tags:: [[VS Code Extension]], [[Markdown]], [[Personal Knowledge Management MOC]]