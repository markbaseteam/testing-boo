---
uuid: 20220726212016
title: Common searches in Obsidian
created: 2022-07-26T21:20:16
updated: 2022-07-26T21:20:16
private: false
alias:
---

# [[Common searches in Obsidian]]

## Find Articles Read:

```
path: "2 Areas/Daily Journal" /^- read/`
```


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Obsidian (App)]]
- 📡 Status:: #status/🌲 
