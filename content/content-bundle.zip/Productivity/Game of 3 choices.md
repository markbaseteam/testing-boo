---
uuid: 20220517054112
title: Game of 3 choices
created: 2022-05-17T05:41:12.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

# [[Game of 3 choices]]

- Give the other person 3 choices for a decision to be made ie: KFC, McDonalds or Pizza Perfect
- They may respond with: McDonalds or Pizza Perfect
	- They feel like they contributed
	- Emotionally safe
- Since I started the process/game, I then say: Pizza Perfect, that good?
	- Both parties engaged and both safe in regards to emotionally being so


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note 
- Inspired By:: [[@Ben Hong]]
- Tags:: [[Decision Making]]
- 