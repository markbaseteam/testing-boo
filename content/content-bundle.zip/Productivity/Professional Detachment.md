---
uuid: 20220802074938
title: Professional Detachment
created: 2022-08-02T07:49:38
updated: 2022-08-02T07:49:38
private: false
alias:
---

# [[Professional Detachment]]

2. Practice Professional Detachment
  This might be a new term in your vocabulary. However, it’s also one of the most powerful things you can do to break free of toxic productivity and avoid burnout.
  Coined by Laurie Ruettimann, “professional detachment” is defined as an understanding that your role at work is not the core of your identity. The idea is that you can be productive and committed without your whole life and sense of self-worth revolving around your job. ([View Highlight](https://instapaper.com/read/1507305467/19763211))
    - Note: realize that you are not your job and that your worth is not defined by your job

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[What Is Toxic Productivity 5 Tips to Overcome It  Trello]]
- Status:: #status/🌲 
- Tags:: [[Productivity  MOC|Productivity]], [[Toxic Productivity]]