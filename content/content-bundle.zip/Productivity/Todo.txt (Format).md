---
uuid: 20220523094413
title: Todo.txt (Format)
created: 2022-05-23T09:44:13.000Z
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

# [[Todo.txt (Format)]]

### Apps:
- [[Sleek (App)]] Desktop
- Todo.txt for Android


### Additional links 
- https://github.com/brosell/todotxt-kanban (Convert to Kanban)


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
