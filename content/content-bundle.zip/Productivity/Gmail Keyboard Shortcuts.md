---
uuid: 20220512025006
title: Gmail Keyboard Shortcuts
created: "2022-05-12T02:"
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---
# [[Gmail Keyboard Shortcuts]]

| Action                                    | Shortcut  |
| ----------------------------------------- | --------- |
| Move focus to toolbar                     | ,         |
| Select conversation                       | x         |
| Toggle star/rotate among superstars       | s         |
| Archive                                   | e         |
| Mute conversation                         | m         |
| Report as spam                            | !         |
| Delete                                    | #         |
| Reply                                     | r         |
| Reply in a new window                     | Shift + r |
| Reply all                                 | a         |
| Reply all in a new window                 | Shift + a |
| Forward                                   | f         |
| Forward in a new window                   | Shift + f |
| Update conversation                       | Shift + n |
| Archive conversation and go previous/next | ] or \[   |
| Undo last action                          | z         |
| Mark as read                              | Shift + i |
| Mark as unread                            | Shift + u |
| Mark unread from the selected message     | _         |
| Mark as important                         | + or =    |
| Mark as not important                     | -         |
| Snooze                                    | b         |
| Expand entire conversation                | ;         |
| Collapse entire conversation              | :         |
| Add conversation to Tasks                 | Shift + t |
|                                           |           |

Test link: [Test Mail link](https://mail.google.com/mail/u/0/#inbox/FMfcgzGmtNlcwWTnwpJFBBRZDQnrnsnC)