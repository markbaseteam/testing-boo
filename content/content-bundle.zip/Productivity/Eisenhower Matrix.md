---
uuid: 20220531040637
title: Eisenhower Matrix
created: 2022-05-31T04:06:37
last-modified: 2022-05-31T04:06:37
private: true
alias:
---

# [[Eisenhower Matrix]]

## About


## Links
- https://todoist.com/productivity-methods/eisenhower-matrix


## How to use

## Use the matrix below to organize your tasks in order of priorities

| **DO IT NOW** - DO FIRST <br /> Urgent & Important       | **SCHEDULE** - DO LATER <br /> Important but Not Urgent |
| -------------------------------------------------------- | ------------------------------------------------------- |
| Task                                                     | Task                                                    |
| **DELEGATE** - OUTSOURCE <br /> Urgent but Not Important | **AVOID** - ELIMINATE <br /> Not Important & Not Urgent |
| Task                                                     | Task                                                    |



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Productivity  MOC]] [[Decision Making]] [[Todoist (App)]] [[Prioritisation]]
- 📡 Status:: #status/🌱
