---
uuid: 20220523093553
title: How to always run an app as administrator on Windows 10
created: 2022-05-23T09:35:53.000Z
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

#### **Question**
# [[How to always run an app as administrator on Windows 10]]?

#### **Answer**
To set a particular application to always run as an administrator, use these steps:

1.  Open **Start**.
2.  Search for the app that you want to run elevated.
3.  Right-click the top result, and select **Open file location**.
   
> **Quick Tip:** If you're running the October 2018 Update, as you search, you can click the **Open file location** option on the list of actions that appears on the right.

4.  Right-click the app shortcut and select **Properties**.
5.  Click on the **Shortcut** tab.
6.  Click the **Advanced** button.
7.  Check the **Run as administrator** option.
8.  Click the **OK** button.
9.  Click the **Apply** button.
10.  Click the **OK** button.

Once you've completed the steps, every time that you start the app, it'll run with elevated privileges. Of course, if you're using the default User Account Control Settings (recommended), you'll still need to approve the UAC dialog to continue with the application.

At any time, you can revert the changes with the same instructions, but on **step No.7**, make sure to clear the **Run as administrator** option.

#### **Links/related reading** 
- [How to set apps to always run as an administrator on Windows 10 | Windows Central](https://www.windowscentral.com/how-set-apps-always-run-administrator-windows-10)

---
## 📇Additional Metadata
Type:: #type/question-answer 
Tags:: [[Windows 10]], Administrator, UAC

