---
uuid: 20220614095430
title: Burnout
created: 2022-06-14T09:54:30
updated: 2022-06-14T09:54:30
private: false
alias:
---

# [[Burnout]]

- 

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Productivity  MOC]]
- 📡 Status:: #status/🌱 
