---
uuid: 20220608063204
title: Mermaid Markdown Graph
created: 2022-06-08T06:32:04
last-modified: 2022-06-08T06:32:04
private: true
alias:
---

# [[Mermaid Markdown Graph]]

- docs: [Entity Relationship Diagram (mermaid-js.github.io)](https://mermaid-js.github.io/mermaid/#/entityRelationshipDiagram)

```
erDiagram  
    CUSTOMER ||--o{ ORDER : places  
    ORDER ||--|{ LINE-ITEM : contains  
    CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
```


```mermaid
erDiagram  
    CUSTOMER ||--o{ ORDER : places  
    ORDER ||--|{ LINE-ITEM : contains  
    CUSTOMER }|..|{ DELIVERY-ADDRESS : uses
```
## Sequence Diagram
- [Sequence diagrams | Mermaid](https://mermaid.js.org/syntax/sequenceDiagram.html)

```mermaid
sequenceDiagram
    Alice->>John: Hello John, how are you?
    John-->>Alice: Great!
    Alice-)John: See you later!
```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Markdown]], [[Graphs]]
- 📡 Status:: #status/🌲 
