---
uuid: 20220802074729
title: Toxic Productivity (Concept)
created: 2022-08-02T07:47:29
updated: 2022-08-02T07:47:29
private: false
alias:
---

# [[Toxic Productivity]]

- Toxic productivity is a mindset that manifests as the need to constantly “do.” You may feel that you can’t rest or take any downtime. And when you’re forced to, you can’t turn your mind off and enjoy it—you’re too busy worrying about what else you “should” do. ([View Highlight](https://instapaper.com/read/1507305467/19763322))
    - Note: when all you 'have' to do is be productive, it can become toxic

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[What Is Toxic Productivity 5 Tips to Overcome It  Trello]]
- Status:: #status/🌲 
- Tags:: [[Productivity  MOC|Productivity]]