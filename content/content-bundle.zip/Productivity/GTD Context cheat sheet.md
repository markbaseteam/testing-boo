---
uuid: 20220506051920
title: GTD Context cheat sheet
created: "2022-05-06T05:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---
# [[GTD Context Cheat Sheet]]

Remember these are just suggestions, a starting point for choosing the contexts that make sense for your system.

## Places

Where do you need to go?

-   `@home`
-   `@work`
-   `@errands`
-   `@church`
-   `@library`
-   `@anywhere`

## Things

What tool, equipment, or resource do you need?

-   `@computer`
-   `@phone`
-   `@online`
-   `@scanner`

## People

Who do you need to talk to?

-   `@Nicole`
-   `@Jerry`
-   `@Jennifer`
-   etc…

## Modes

What similar tasks could you group together?

-   `@study`
-   `@read`
-   `@review`
-   `@email`
-   `@calls`

## Temporal Contexts

The most important decision you’ll make about a task is when you’re going to do it. Until then, the resource, person, or location isn’t important.

### Days

-   `@today`
-   `@tomorrow`

### Weeks

-   `@thisweek`
-   `@nextweek`

### Months

-   `@thismonth`
-   `@nextmonth`

-   `@january`
-   `@february`
-   `@march`
-   `@april`
-   `@may`
-   `@june`
-   `@july`
-   `@august`
-   `@september`
-   `@october`
-   `@november`
-   `@december`

### Quarters

-   `@thisquarter`
-   `@nextquarter`

-   `@q1`
-   `@q2`
-   `@q3`
-   `@q4`

### Years

-   `@thisyear`
-   `@nextyear`

-   `@2024`
-   `@2025`
-   `@2026`
-   etc…