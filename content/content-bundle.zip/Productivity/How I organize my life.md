---
uuid: 20220429120842
title: How I organize my life
created: 2022-04-29T12:08:42.000Z
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

# [[How I organize my life]]

- Uses roam research to do note taking
- Roam
	- Opens to Daily Note
	- Read: Blog post Paul Graham - 5 regrets of the dying
- Evergreen Notes
	- used as info that will stand the test of time
	- eg: Words, sayings, topics? 
	- eg in video: [[Ikigai]]
- The Nibble Framework
	- Add tag [[Nibble]] to article to be read
	- Add tag [[DIGESTED]] when done with note taking and digesting
- Nebula App 
	- Streaming service 
	- [Ali Abdaal Workflow Series](https://nebula.app/search?q=Workflow)


Author:: [[@Ali Abdaal]]

Status:: #status/🌲
Tags:: Nibble framework, 
Rating:: 5

Type:: #type/resource 
Source:: #source/video
URL:: [How I organize my life](https://www.youtube.com/watch?v=bpikCLhpIRY)
*** 
