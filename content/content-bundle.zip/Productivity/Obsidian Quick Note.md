---
uuid: 20220516111529
title: Obsidian Quick Note
created: 2022-05-16T11:15:29.000Z
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

# [[Obsidian Quick Note]]
Language:: #language/ahk
Type:: #programming/desktop
Context:: @desktop
Description – a text-based description of the snippet

Snippet

```
Snippet herea
```

Dependencies:: – link to any other code or packages that are relevant or that you need to use this snippet


Type:: #type/snippet 
Tags:: [[Productivity  MOC|Productivity]]
Status:: #status/🌲 
