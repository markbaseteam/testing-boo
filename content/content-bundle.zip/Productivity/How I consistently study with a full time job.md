---
uuid: 20220616102156
title: How I consistently study with a full time job
created: 2022-06-16T10:21:56
updated: 2022-06-16T10:21:56
private: true
alias:
---

# [[How I consistently study with a full time job]]

- Author:: the original author of the resource
- Category:: video
- URL:: https://www.youtube.com/watch?v=INymz5VwLmk
- Status:: #status/🌲 
- Tags:: [[Goals MOC]], [[Motivation]]
- Rating:: 4
	
## Formula
- [01:51](https://www.youtube.com/watch?v=INymz5VwLmk#t=111.625636) 5 Ingredient run down
	- Have an overarching goal and sub-goals
	- Find out what pushes your buttons
	- Adapting your mindset
	- Find the right support system
	- Measure your progress

## Real life Implementation 
- [08:14](https://www.youtube.com/watch?v=INymz5VwLmk#t=494.232029)  Ingredient 1
	- Have a goal
- [09:04](https://www.youtube.com/watch?v=INymz5VwLmk#t=544.995599) Ingredient 2 -
	- Find out what pushes your buttons
		- What is it that compels you to do something (Social accountability, hearing you can't do something, what triggers you to action?)
- 
- [10:42](https://www.youtube.com/watch?v=INymz5VwLmk#t=642.203287) Ingredient 3
	- Adapting your mindset
		- Consistent
		- Growth
		- Habit of showing up
- [11:39](https://www.youtube.com/watch?v=INymz5VwLmk#t=699.701137) Ingredient 4
	- Find the right support system
		- Community (Birds of a feather flock together)
		- Have people a group of people that you trust to hold you to your goals/intentions.
		- Not really friends as then you may seem a bit too lax about the achievement requirement or goal that you did not reach.
- [13:14](https://www.youtube.com/watch?v=INymz5VwLmk#t=794.260563) Ingredient 5
	- Measure your progress
		- Scoreboards
		- The 4 Disciplines of Execution - Book Recommendation

---
## 📇Additional Metadata
- Type:: #type/resource 
- Source:: #source/video 

