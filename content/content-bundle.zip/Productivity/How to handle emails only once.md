---
uuid: 20220917114253
title: How to handle emails only once
created: 2022-09-17T11:42:53
updated: 2022-09-17T11:42:53
private: true
alias:
---

# [[How to handle emails only once]]

https://www.youtube.com/watch?v=uXdEVeoGRRc


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Productivity  MOC|Productivity]], [[@Tiago Forte]], [[Building a Second Brain]]
- 📡 Status:: #status/🌲 
