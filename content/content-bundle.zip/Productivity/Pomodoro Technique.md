---
uuid: 20220719043823
title: Pomodoro Technique
created: 2022-07-19T04:38:23
updated: 2022-07-19T04:38:23
private: true
alias:
---

# [[Pomodoro Technique]]



## Timers

- Habitica SiteKeeper Browser Extension
	- https://habitica.fandom.com/wiki/Habitica_Pomodoro_SiteKeeper

## Setup of Pomodoro on Home Assistant
- https://medium.com/recursive-automation-by-eyecreality/automate-your-pomodoro-process-today-2ed62d063c33


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Home assistant]], [[Productivity  MOC|Productivity]], [[Automation]]
- 📡 Status:: #status/🌲 
