---
uuid: 20220513132232
title: Project management for Individuals
created: 2022-05-13T13:22:32.000Z
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

# [[Project management for Individuals]]

Author:: [[@Ben Hong]]
Category:: video
URL:: [Productivity Power Hour (#7): Project Management for Individuals](https://www.youtube.com/watch?v=hRTltxen6H4)
Status:: #status/🌲 
Tags:: project management, 
Rating:: 

Type:: #type/resource 
Source:: #source/video 
*** 

> [!quote] 
> Why is it necessary for an employee to provide information as to why they can get the promotion, when traditional systems should be able to provide this information

- Watched # 
	- [[TEPOD Framework]]
		- Tasks
		- Epics
		- Projects
		- Objects
		- Directions (I wanna be a better developer)
```mermaid
graph TD;

Tasks --> Epics & Projects & Directions
Epics --> Projects
Projects --> Objectives & Directions
Objectives --> Directions
Directions
```

---