---
uuid: 20220614054402
title: Practice your writing by rewriting what you read - Benjamin Franklin
created: 2022-06-14T05:44:02
updated: 2022-06-14T05:44:02
private: true
alias:
---

# [[Practice your writing by rewriting what you read - Benjamin Franklin]]

Franklin would read newspaper articles, take detailed notes, and attempt to rewrite the passages in his own words in order to improve his writing style. Here’s how he described the process in his autobiography. 👇
  
  > [!quote] 
  > “[…] I took some of the papers, and, making short hints of the sentiment in each sentence laid them by a few days, and then, without looking at the book, tried to complete the papers again, by expressing each hinted sentiment at length, and as fully as it had been expressed before, in any suitable words that should come hand. Then I compared my Spectator with the original, discovered some of my faults, and corrected them.”
  > 
  > *- The Autobiography of Benjamin Franklin(10)*

Following Franklin’s imitation technique, rewriting and repurposing the contents of your knowledge management system should become your key PKM habit. It’ll also prevent your knowledge from going stale over time. ([View Highlight](https://instapaper.com/read/1507305039/19672034))

- Note: practice writing by taking notes on what is read, then rewriting in own words

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[Personal Knowledge Management (PKM)  Organize Your Work and Life - Taskade Blog]]
- Status:: #status/🌲 
- Tags:: [[Productivity  MOC]], [[Writing]], [[Personal Knowledge Management MOC]]