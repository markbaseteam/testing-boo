---
uuid: 20230426045352
title: How I Manage My Time - The Trident Calendar System
created: 2023-04-26T04:53:52
updated: 2023-04-26T04:53:53
private: false
alias:
---
Up:: [[Productivity  MOC|Productivity]]

# [[How I Manage My Time - The Trident Calendar System]]

- Author:: [[@Ali Abdaal]]
- Category:: video
- URL:: [How I Manage My Time - The Trident Calendar System - YouTube](https://www.youtube.com/watch?v=6o2tm00Ar8A)
- Rating:: 5

## Learn by elaboration
- Three prongs
	- Yearly overview of what is to come...
	- Ideal week - Schedule your complete week based on what you would like it to be like, while being flexible to allow for **EMERGENCIES**
	- Ideal day - Schedule your day and do what you are scheduled to do for that day, trying not to stray from it at all.

- Templates:



- [01:17](https://www.youtube.com/watch?v=6o2tm00Ar8A#t=77.922251) The year at a glance
	- [Google Sheets: Sign-in](https://docs.google.com/spreadsheets/d/1yQmiNSlRyRfNG2KWarloIinbhRR1J8sWwEwR34i6gRQ/edit#gid=0)
	- 
- [03:30](https://www.youtube.com/watch?v=6o2tm00Ar8A#t=210.856823) Planning an Ideal week
	- 112 hours per week to use and advance your life
	- 

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/video 
- 🏷️ Tags:: [[Time Management]]
- 📡 Status:: #status/🌲 
