---
uuid: 20220810052958
title: Productivity Porn
created: 2022-08-10T05:29:58
updated: 2022-08-10T05:29:58
private: true
alias:
---

# [[Productivity Porn]]

- **Productivity porn** is anything that after having been consumed makes you feel like you were productive when in reality you didn’t actually do anything. Just like regular pornography it stimulates you without even performing the act. It is a hollow imitation of the real thing.
	- Constantly consuming content that makes you think that you are productive instead of you actually doing something can be considered to be productivity porn. 
	- Creates a vicious cycle where spend all your time thinking instead of doing, and as this cycle continues your productivity approaches zero.

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[2022-08-10]]
- Status:: #status/🌲 
- Tags:: [[Productivity  MOC|Productivity]], [[Toxic Productivity]]