---
uuid: 20220526111358
title: Decision Matrix - How to prioritize tasks
created: 2022-05-26T11:13:58.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

# [[Decision Matrix - How to prioritize tasks]]


A matrix divided into quadrants

1.   High urgency, low effort
2.   High urgency, high effort
3.   Low urgency, high effort
4.   Low urgency, low effort

When you are stuck with tasks overwhelm, use the matrix to list all the tasks in the quadrant they belong. 

High urgency, High effort tasks needs to be time estimated and low effort tasks should be done first.

Low urgency, low effort tasks should be delegated


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note 
- Status:: #status/🌲
- 🏷️ Tags:: [[Decision Making]], [[Productivity  MOC]], [[GTD]]
