---
uuid: 20220726104455
title: Monotasking
created: 2022-07-26T10:44:55
updated: 2022-07-26T10:44:55
private: true
alias:
---

# [[Monotasking]]



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌱 
