---
uuid: 20220502085938
title: Apps
created: "2022-05-02T08:"
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---
# Apps

- [[Obsidian (App)]] Note taking / link your thinking
- [[Joplin]] OSS Notes
- [[Sleek]] (Todo.txt Editor)


Type:: #type/link 
#on/productivity