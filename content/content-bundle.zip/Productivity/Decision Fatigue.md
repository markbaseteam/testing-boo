---
uuid: 20220614095324
title: Decision Fatigue
created: 2022-06-14T09:53:24
updated: 2022-06-14T09:53:24
private: false
alias:
---

# [[Decision Fatigue]]

- It occurs ==when you have too many choices== on how to spend your time, and this can lead to [[Burnout]].
- Recovering from decision fatigue can be done by getting some distance between you and your choices, this can be accomplished by ==writing down all your tasks== , be it in analogue or digital formats.


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Productivity  MOC]]
- 📡 Status:: #status/🌲 
