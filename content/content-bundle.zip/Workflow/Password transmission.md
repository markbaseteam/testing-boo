---
uuid: 20220429100644
title: Password transmission
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.345Z
private: false
alias: null
---
# [[Password transmission]]

- Any password related items that wants to be saved, should go into Bitwarden as a secure note if it is to be reference only. 
- It should then only be shared from there. 
- Transfer via Email or any instant messaging service should be prevented as far as possible

* * *

Tags: SOP, Standard Operating Procedures, Process

