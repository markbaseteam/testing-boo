---
uuid: 20220429120849
title: VIM 7.3 Highlight long lines
created: 2022-04-29T12:08:49.000Z
updated: 2022-06-09T16:15:28.343Z
private: false
alias: null
---


# [VIM 7.3 Highlight long lines](http://thecatatemysourcecode.posterous.com/vim-73-highlight-long-lines)

VIM 7.3 introduced the "`colorcolumn`" option, which highlights a specific column. PEP8 recommends a maximum line length of 79 characters for Python code, so setting colorcolumn to 80:

```
set colorcolumn=80
```

will give you a vertical line at the 80th column:

See "`:help colorcolumn`" for more information.

