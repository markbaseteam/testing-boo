---
uuid: 20220705051419
title: Photo-Voltaic cells
created: 2022-07-05T05:14:19
updated: 2022-07-05T05:14:19
private: false
alias:
---

# [[Photo-Voltaic cells]]

- Have a short description of the process and the chemical reactions and things, should be interesting.

- It is what solar panels are made up of and generates the power in the panels.
- Made from silicone
- 

---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Solar power]], [[Sustainability]]
- 📡 Status:: #status/🌲 
