---
uuid: 20220429100635
title: How do I reset the DNS cache
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---
* **Question** – How do I reset the DNS cache
* **Answer** – Flush DNS
	* Windows 10
		* `ipconfig /flushdns`
* **Tags** – dns, network, connection issues
* **Links/related reading** – https://www.ionos.com/digitalguide/server/configuration/flush-dns/
2022-04-20 04:51
***

