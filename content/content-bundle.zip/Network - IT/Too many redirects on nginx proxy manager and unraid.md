---
uuid: 20230517081051
title: Too many redirects on nginx proxy manager and unraid
created: 2023-05-17T08:10:51
updated: 2023-05-17T08:11:14
private: false
alias:
---

#### **Question**
# [[Too many redirects on nginx proxy manager and unraid]]

#### **Answer**

The sites I was having an issue with were all http sites that I was proxying a connection to. I did however find part of the configuration issues that I had. ==Force SSL may not work with CloudFlare proxying==. Since I was not able to get it to work at the server level, I ==enabled Strict SSL Enforcement on CloudFlare==.

When you have enabled the SSL enforcement on CloudFlare, you can force to https again.

I think I found the answer to my situation. I found it when reading a blog [https://www.smarthomebeginner.com/traefik-2-docker-tutorial/ 364](https://www.smarthomebeginner.com/traefik-2-docker-tutorial/)  
The tutorial is very good by the way, but one of the messages in there was that with cloudflare ==you need to set the domain SSL/TLS encryption mode to Full.== “In addition to creating the DNS records, you will have to adjust Cloudflare’s SSL settings to avoid indefinite redirects.”.

#### **Links/related reading** 
- [Too Many Redirects · Issue #852 · NginxProxyManager/nginx-proxy-manager · GitHub](https://github.com/NginxProxyManager/nginx-proxy-manager/issues/852#issuecomment-786798702)
- [NGINX Proxy Manager - Too Many Redirects - #16 by Isablend - Configuration - Home Assistant Community](https://community.home-assistant.io/t/nginx-proxy-manager-too-many-redirects/347688/16)

---
## 📇Additional Metadata
- 📁Type:: #type/question-answer 
- 🏷️Tags:: [[Unraid (Bruce)]] [[Nginx Proxy Manager]]
- 📡Status:: #status/🌲 
