---
uuid: 20220530071505
title: My PKM Process
created: 2022-05-30T07:15:05.000Z
updated: 2022-06-09T16:15:28.335Z
private: true
alias: null
---

# [[My PKM Process]]

## General Flow

- Tasks goes into [[Todoist (App)]] 
	- If it is in there, it gets done
	- If it is not in there, it can be done, but not should
- Daily Journal
	- bit more detailed log of what I am working on and daily happenings
	- Small Startup tasks - Look into doing that in [[Todoist (App)]]
	- Capture all things interesting
- Reading
	- [[Readwise.io (App)]] for bringing in notes on books, tweets, articles and more
	- [[Instapaper (App)]] Read it later app for articles
	- [[Apple iBooks (App)]] books reading app
		- [[Kindle (App)]] also works nice but having issues with it wrt importing my own books
	- [[Twitter]] - use the `@readwise save` or `@readwise save thread`
- Email: 
	- [[Gmail (App)]] all my mails goes through here.
	- A mail only gets opened ONCE!


![[Drawing 2022-05-30 15.27.48.excalidraw]]


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Personal Knowledge Management MOC]] [[Note-Making]]
