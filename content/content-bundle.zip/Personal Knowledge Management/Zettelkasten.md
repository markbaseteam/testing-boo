---
uuid: 20220527220304
created: 2022-05-27T22:03:04
last-modified: 2022-05-27T22:03:04
alias:
---

# [[Zettelkasten]]

Zettelkasten systems rely on discrete pieces of knowledge, such as those in atomic notes, linked together. A Zettelkasten has three types of notes:
  - Fleeting notes
  - Permanent notes
  - Project notes
  For a deep dive into the world of Zettelkasten, check out the English-language section of Zettelkasten.de for a thorough overview and guidelines on implementation. ([View Highlight](https://instapaper.com/read/1508601383/19650244))

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[How to Build a Personal Knowledge Management System]]
- Tags:: [[Personal Knowledge Management MOC|PKM]] [[Note-Making]]
