---
uuid: 20220504142549
title: Obsidian (App)
created: 2022-05-04T14:25:49.000Z
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---
Up:: [[Personal Knowledge Management MOC|PKM]]

# [[Obsidian (App)]]




### Plugins

- [Top 10 Obsidian Plugin I can't do without](https://www.youtube.com/watch?v=W7kTtn9empU)
- [How to use the Obsidian Dataview Plugin](https://www.youtube.com/watch?v=JTObSymEvWA)
- [How to get started with Obsidian in 2022 - from scratch!](https://www.youtube.com/watch?v=OUrOfIqvGS4)
- [Obsidian task management with Dataviewjs, Templates, Daily Notes - YouTube](https://www.youtube.com/watch?v=ccN5vJzXwvo)

***

## 📇 Additional Metadata

- 🗂 Type:: #type/tool
- Source:: #tool/app