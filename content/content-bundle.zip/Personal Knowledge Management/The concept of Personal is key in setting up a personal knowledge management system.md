---
uuid: 20220527215951
title: The concept of "Personal" is key in setting up a personal knowledge management system
created: 2022-05-27T21:59:51
last-modified: 2022-05-27T21:59:51
private: false
alias:
---

# [[The concept of Personal is key in setting up a personal knowledge management system]]

The concept of the “personal” is absolutely key in understanding the best way to set up a personal knowledge management system. There simply is no one-size-fits-all personal knowledge management method or app.
  You need to build a flexible tailored system that fits your life ([View Highlight](https://instapaper.com/read/1508601383/19650098))

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[How to Build a Personal Knowledge Management System]]
- Tags:: [[Personal Knowledge Management MOC|PKM]]
- Status:: #status/🌲 