---
uuid: 20220512061237
title: Check second brain note template
created: "2022-05-12T06:"
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---
A note template to get better at note taking

* Internal Context
* External context
* 2 more...


https://fortelabs.co/blog/the-official-second-brain-note-template/
