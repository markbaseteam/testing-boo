---
uuid: 20220520070833
title: Obsidian Boiler Plate by @Ben Hong
created: 2022-05-20T07:08:33.000Z
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

Up:: [[Personal Knowledge Management MOC|PKM]]

# [[Obsidian Boiler Plate by @Ben Hong]]

URL:: https://github.com/bencodezen/bens-obsidian-boilerplate
Author:: [[@Ben Hong]]


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- Tags:: [[Obsidian (App)]]
- Resource:: #source/website 