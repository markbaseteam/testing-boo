---
uuid: 20220527215714
title: What is personal knowledge management?
created: 2022-05-27T21:57:14
last-modified: 2022-05-27T21:57:14
private: false
alias:
---
Up:: [[Personal Knowledge Management MOC|PKM]]

# [[What is personal knowledge management]]

What is personal knowledge management?
  The definition of personal knowledge management, simply put, is to have a structured system in place to organize your thoughts, notes, and files. ([View Highlight](https://instapaper.com/read/1508601383/19650082))
From my perspective, all personal knowledge management means is this: having an intentional, mindful way to organize and manage all the information that flows into your life on a daily basis. ([View Highlight](https://instapaper.com/read/1508601383/19650084))

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[How to Build a Personal Knowledge Management System]]
- Tags:: [[Personal Knowledge Management MOC]]