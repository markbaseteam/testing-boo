---
uuid: 20220614062129
title: Tools are there to serve your goals - choose appropriately
created: 2022-06-14T06:21:29
updated: 2022-06-14T06:21:29
private: true
alias:
---

# [[Tools are there to serve your goals - choose appropriately]]

> [!info] The truth is, all these tools and all these layers only matter to the extent they bring you more of what you want in life.
>Instead of dutifully starting at the bottom and painstakingly working your way up the stack, start at the top and ask yourself.
>“What do I want?”
>Remember, ==the only purpose of productivity is to move you toward your goals== – the experiences and feelings that you want to have more of.
>Identify what you are trying to accomplish, and work backward from there.
>You may find that you don’t need nearly as many new tools as you think. ([View Highlight](https://instapaper.com/read/1507305084/19728603))
  
- Note: tools are there to serve your goals, choose appropriately

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[How to Build Your Personal Productivity Stack]]
- Status:: #status/🌲 
- Tags:: [[Personal Knowledge Management MOC|PKM]], [[Productivity  MOC]]