---
uuid: 20220429100637
title: Mem AI Note app
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---
Up:: [[Personal Knowledge Management MOC|PKM]]

# [[Mem AI Note app]]

https://get.mem.ai/pricing

This is an app that I need to checkout sometime


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Personal Knowledge Management MOC|PKM]]
- 📡 Status:: #status/🌲 
