---
uuid: 20220523022208
title: Link Your Thinking
created: "2022-05-23T02:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---
#  Link Your Thinking

[LYT Website](https://www.linkingyourthinking.com)

Download LYT Kit 6: https://www.linkingyourthinking.com/lyt-kit-course/onboarding

1. https://www.linkingyourthinking.com/lyt-kit-course/lesson-1-introducing-linked-notes
2. https://www.linkingyourthinking.com/lyt-kit-course/lesson-2-make-notes-for-life-using-living-notes
3. https://www.linkingyourthinking.com/lyt-kit-course/lesson-3-never-lose-your-notes-again-with-maps-of-content
4. https://www.linkingyourthinking.com/lyt-kit-course/lesson-4-launch-yourself-anywhere-from-your-home-note
5. https://www.linkingyourthinking.com/lyt-kit-course/lesson-5-get-access-to-your-thoughts-and-ideas
6. https://www.linkingyourthinking.com/lyt-kit-course/lesson-6-manage-your-projects-more-easily-with-spaces


from  [[2022-04-03]]