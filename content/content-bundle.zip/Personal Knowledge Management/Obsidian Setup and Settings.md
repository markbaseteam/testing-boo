---
uuid: 20230329062050
title: Obsidian Setup and Settings
created: 2023-03-29T06:20:50
updated: 2023-03-29T06:20:50
private: true
alias:
---

# [[Obsidian Setup and Settings]]

## Plugins
- 

## Settings
- 






---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[My PKM Process]]
- 📡 Status:: #status/🌱 
