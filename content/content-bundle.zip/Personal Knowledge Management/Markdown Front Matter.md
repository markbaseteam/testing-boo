---
uuid: 20220614053623
title: Markdown Front Matter bloob
created: 2022-06-14T05:36:23
updated: 2022-06-14T05:36:23
private: false
alias:
---

# [[Markdown Front Matter]]

- Front matter is easy to write, easy to parse, and a good solution if you need to keep metadata associated with your markdown with you markdown. ([View Highlight](https://instapaper.com/read/1507305755/19778500))
    - Note: Frontmatter is a great way to have Metadata available with your data and it does not render in most tool's

```md
---
uuid: 20220614053623
title: Markdown Front Matter bloob
created: 2022-06-14T05:36:23
updated: 2022-06-14T05:36:23
private: true
alias:
---
```



---
## Additional Metadata

- Type:: #type/note
- Origin:: [[Markdown Front Matter for Metadata]]
- Status:: #status/🌲 
- Tags:: [[Productivity  MOC]], [[Personal Knowledge Management MOC]]
