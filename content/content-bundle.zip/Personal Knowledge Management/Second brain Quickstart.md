---
uuid: 20220513041209
title: Second brain Quickstart
created: "2022-05-13T04:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---
Up:: [[Personal Knowledge Management MOC|PKM]]

# [[Second Brain Quickstart]]

Mail Series:

Here are the four elements of an effective Second Brain, summarized by the CODE Method:

> [!note]
C - Capture
O - Organize
D - Distill
E - Express

### Capture

Remember: Just one small improvement to your Capture process “trickles down” and improves all the other parts of your Second Brain system.
Great Capture means easier Distillation, clearer Organization, and ultimately... the ability to Express new insights to the world (and yourself).
Capture Quickstart PDF in files

### Organize

 Organize by Actionability. 
 PARA – which breaks down your note’s organizational structure into Projects, Areas, Resources, or Archives.
 [[The PARA Method_ How I Organize my Digital Informa]]

### Distill

When you write notes and capture knowledge in the right way — distilling it down to its most important essence – you can know exactly what’s important as soon as you read it.
technique I’ve developed called [[Progressive Summarization_ A Practical Technique f]].
Progressive Summarization allows you to send your knowledge into the future, definitively highlighting only the most relevant and useful information you’ve captured.

### Express

That’s right: **the single biggest purpose of a Second Brain is creating something with what we’ve collected, organized, and distilled.**
Expressing is about using what you’re learning to make new things. 
[Spotify Podcast 6min episode](https://click.convertkit-mail.com/38ur9z560wfdux5gqmsr/qvh8h7h8q6nl3kul/aHR0cHM6Ly9vcGVuLnNwb3RpZnkuY29tL2VwaXNvZGUvNnRSSUl3UEgxME5ZNklObndVY0c5NT9zaT1MemZxbUlRa1FncWZVUjg3aVB5WXVR)



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: 
- 📡 Status:: #status/🌲 