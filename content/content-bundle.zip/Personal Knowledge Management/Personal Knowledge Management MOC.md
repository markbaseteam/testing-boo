---
uuid: 20220614060448
title: PKM
created: 2022-06-14T06:04:48
updated: 2022-06-14T06:04:48
private: true
alias:
  - PKM
---

# [[Personal Knowledge Management MOC]]

- The area of work where you manage and maintain your own personal knowledge with regards to your life, work and anything else you would like to keep record of.

```dataview
LIST
FROM [[Personal Knowledge Management MOC]]
```

---

## 📇 Additional Metadata

- 🗂 Type:: #type/moc 
- 🏷️ Tags:: [[Personal Knowledge Management MOC|PKM]]
- 📡 Status:: #status/🌲 
