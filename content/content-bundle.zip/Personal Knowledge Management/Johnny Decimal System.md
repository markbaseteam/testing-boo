---
uuid: 20220527220209
title: Johnny Decimal System
created: 2022-05-27T22:02:09
last-modified: 2022-05-27T22:02:09
private: false
alias:
---

# [[Johnny Decimal System]]

- The Johnny Decimal system, created by John Noble, is a numerically-based structure for organizing digital files. Inspired by the Dewey Decimal system, it is a practical approach to the challenge of sorting and finding digital files.
- The **essential steps** of this approach are to:
	 - Break everything up into 10 areas (or less).
	 - Break each of those areas into 10 categories (or less).
	 - Assign ID numbers to those areas and categories.
	 - Assign IDs to files and folders.

- John Noble has an excellent, easy-to-follow summary of his approach over at his site, where he also hosts a dedicated forum:
Home
- A system to organise projects.

- Johnny Decimal ([View Highlight](https://instapaper.com/read/1508601383/19650184))

Additional Resources:: https://johnnydecimal.com/

---
## Additional Metadata

- Type:: #type/resource 
- Status:: #status/🌲 
- Origin:: [[How to Build a Personal Knowledge Management System]]
- Tags:: [[Personal Knowledge Management MOC|PKM]] [[Organization]]