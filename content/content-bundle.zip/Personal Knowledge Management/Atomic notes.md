---
uuid: 20220527220119
title: Atomic Notes
created: 2022-05-27T22:01:19
last-modified: 2022-05-27T22:01:19

alias:
---

# [[Atomic notes]]

The goal of writing an atomic note is to break each piece of knowledge down into its smallest, tiniest, indivisible part (i.e. per Dalton’s atomic theory). The goal is to then link these small, discrete pieces of information to related notes to that you can see interconnections between ideas and themes. To continue the analogy, you can then link your atomic notes together to build “molecules” of knowledge. ([View Highlight](https://instapaper.com/read/1508601383/19650132))

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[How to Build a Personal Knowledge Management System]]
- Tags:: [[Personal Knowledge Management MOC]]