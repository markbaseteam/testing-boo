---
uuid: 20220614061638
title: Task overwhelm
created: 2022-06-14T06:16:38
updated: 2022-06-14T06:16:38
private: true
alias:
---

# [[Task overwhelm]]

>Task overwhelm occurs when the actionable items in your list are crowded out by the non-urgent ones: when your ideas, list of someday-maybes, inspirations, and random learnings make it difficult to find the singular, next important action. ([View Highlight](https://instapaper.com/read/1507305084/19728489))

- Should you capture everything in one place and not **sort** it, you lead the risk of getting overwhelmed by all the items in the list. Yet, there are only a handful of tasks for you, it might seem really really overwhelming.

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[How to Build Your Personal Productivity Stack]]
- Status:: #status/🌲 
- Tags:: [[Personal Knowledge Management MOC|PKM]], [[Task Management]]