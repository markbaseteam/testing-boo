---
uuid: 20220802081411
title: Cataloging, Classification, Information Science, PMKs and YOU!
created: 2022-08-02T08:14:11
updated: 2022-08-02T08:14:20
private: true
alias:
---

# [[Cataloging, Classification, Information Science, PMKs and YOU]]

- Author:: [brimwats](https://forum.obsidian.md/u/brimwats)
- Category:: article
- URL:: https://forum.obsidian.md/t/cataloging-classification-information-science-pkms-and-you/10071
- Rating:: 4

## Learn by elaboration

- Structures
```
**The Self**  
000 Knowledge Management  
100 Personal Management  
200 Philosophy & Psychology; Spirituality & Religion  
**Others**  
300 Social Sciences  
400 Communications & Rhetoric; Language & Linguistics  
**Others + Self**  
500 Natural Sciences  
600 Applied Sciences  
700 Art & Recreation  
800 Literature  
**History of Others & Self**  
900 History & Biography & Geography
```

---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/article 
- 🏷️ Tags:: [[Personal Knowledge Management MOC|PKM]], [[Organization]]
- 📡 Status:: #status/🌿 

