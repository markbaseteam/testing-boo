---
uuid: 20220704131850
title: Building a Second Brain + Writing a book with Tiago Forte
created: 2022-07-04T13:18:50
updated: 2022-07-04T13:19:02
private: true
alias:
---

# [[Building a Second Brain + Writing a book with Tiago Forte]]

- Author:: the original author of the resource
- Category:: video
- URL:: https://www.youtube.com/watch?v=r60GAxl8Hyo
- Rating:: how effective this resource is at solving your problem or teaching you something

## Learn by elaboration

- *Note* in english is among the oldest 2% of words
- Commonplace book comes from ancient greeks
- Note taking is engrained in our DNA/Lives/Reading/Learning/etc
- Tiago approach to Note Taking is same as Note Making where the difference is that it is forever, its digital, it is not just for one semester, single use. Its collaborative.
- Legacy of school is to blame for the mundane/useless note-taking skill we were forced to learn in school. Punishment Orientation, if you don't do this, bad things will happen. Unlearn what was told to take note of and learn to use intuition. **[[Somatic Awareness]]?**
- Mindful Productivity, Mental Health
- Student Architype - Catch all - Starting point before you choose your architype
- Student tools will not be enough - Will have to get more complex like [[Obsidian (App)]]
- "Everyone is living a life worth taking notes about"
- Take 1 note, everyday for 30 days and check afterwards and see, that there is something worth talking/sharing/thinking about.
- 
---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source/video 
- 🏷️ Tags:: [[Building a Second Brain]], [[Note-Making]], [[Writing]]
- 📡 Status:: #status/🌲 

