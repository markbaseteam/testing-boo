---
uuid: 20220429100637
title: Programmable notes
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.335Z
private: false
alias: null
---

Up:: [[Personal Knowledge Management MOC|PKM]]

# [[3 Resources/Personal Knowledge Management/Programmable notes|Programmable notes]]

Interesting concept

https://maggieappleton.com/programmatic-notes

Action orientated note prompts

- [x] Do Joplin check


---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Personal Knowledge Management MOC|PKM]]
- 📡 Status:: #status/🌲 