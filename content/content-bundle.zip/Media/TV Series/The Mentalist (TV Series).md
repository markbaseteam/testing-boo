---
uuid: 20220726100756
title: The Mentalist (TV Series)
created: 2022-07-26T10:07:56
updated: 2022-07-26T10:07:56
private: true
alias:
---

# [[The Mentalist (TV Series)]]

Rating:: 5
Seasons:: 8
Ended:: Y

---

## 📇 Additional Metadata

- 🗂 Type:: #type/tv-series 
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
