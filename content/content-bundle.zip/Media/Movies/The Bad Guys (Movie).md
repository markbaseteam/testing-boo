---
uuid: 20220726100926
title: The Bad Guys (Movie)
created: 2022-07-26T10:09:26
updated: 2022-07-26T10:09:26
private: true
alias:
---

# [[The Bad Guys (Movie)]]

Rating:: 5
Review:: Good movie

---

## 📇 Additional Metadata

- 🗂 Type:: #type/movie
- 🏷️ Tags::
- 📡 Status:: #status/🌲  
