---
uuid: 20220429100635
title: Worm Hive - Multi-layered Stackable work bin
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---

Up:: [[Gardening]]

# [[Worm Hive - Multi-layered Stackable work bin]]

![](../../_resources/88776c06f2e4318e5cc1517860d6be09.png)

URL:: [Mom is an Understatement: Worm Hive: A Multi-Layered, Stackable Worm Bin](http://momisanunderstatement.blogspot.com/2012/03/worm-hive-multi-layered-stackable-worm.html)



---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags::
- 📡 Status:: #status/🌲 
