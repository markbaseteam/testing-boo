---
uuid: 20220526083757
title: Why should we practice gratitude
created: 2022-05-26T08:37:57.000Z
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---

# [[Why should we practice gratitude]]

There are many scientifically proven reasons why practicing gratitude is important. But one reason that isn't obvious is that gratitude is not a quality, it is a skill. And like all skills, we can develop our gratitude with practice. There are many ways to practice our gratitude from journaling, meditation, acts of service, prayer, and more.

---
## Additional Metadata

- Type:: #type/note
- Origin:: [[2022-05-26]]
- Tags:: [[Journaling]], [[Gratitude]]
