---
uuid: 20220429100629
title: Tips for Keeping A Gratitude Journal
created: "2022-04-29T10:"
updated: 2022-06-09T16:15:28.333Z
private: false
alias: null
---
# Tips for Keeping A Gratitude Journal

Robert Emmons, arguably the world’s leading expert on the science of gratitude, and an author of some of the seminal studies of gratitude journals, shared these research-based tips for reaping the greatest psychological rewards from keeping a gratitude journal:

- **Don’t just go through the motions.** Research by psychologist Sonja Lyubomirsky and others suggests that journaling is more effective if you first make the conscious decision to become happier and more grateful. “Motivation to become happier plays a role in the efficacy of journaling,” says Emmons.
- **Go for depth over breadth.** Elaborating in detail about a particular thing for which you’re grateful carries more benefits than a superficial list of many things.
- **Get personal.** Focusing on people to whom you are grateful has more of an impact than focusing on things for which you are grateful.
- **Try subtraction, not just addition.** One effective way of stimulating gratitude is to reflect on what your life would be like without certain blessings, rather than just tallying up all those good things.
- **Savor surprises.** Try to record events that were unexpected or surprising, as these tend to elicit stronger levels of gratitude.
- **Don’t overdo it.** Writing occasionally (once or twice per week) is more beneficial than daily journaling. In fact, one study by Lyubomirsky and her colleagues found that people who wrote in their gratitude journals once a week for six weeks reported boosts in happiness afterward; people who wrote three times per week didn’t. “We adapt to positive events quickly, especially if we constantly focus on them,” says Emmons. “It seems counterintuitive, but it is how the mind works.”

Learn more at “Tips for Keeping a Gratitude Journal,” by Jason Marsh, at the Greater Good Science Center. This excerpt is from an article which originally appeared on Greater Good, the online magazine of the Greater Good Science Center at UC Berkeley. For more, visit greatergood.berkeley.edu.