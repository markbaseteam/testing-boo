---
uuid: 20220601062359
title: Write in the tense which makes sense to journal in
created: 2022-06-01T06:23:59.000Z
updated: 2022-06-09T16:15:28.334Z
private: false
alias: null
---

# [[Write in the tense which makes sense to journal in]]

- Thought:: You should write in the tense that makes sense to you, past when it is something you did, present when you are talking about your emotions, future when you are planning to do something

> [!quote] Past tense is my instinct. Yet it depends on what you are writing and the writing's purpose. If it's an adventure story or something with more of a fast pace then clearly present tense might be best. "What was that? Rustling in the bushes nearby. Footsteps just beyond--sound like a person, a large person. I must move on. Now." That is more effective than: "Yesterday I discovered signs of a person having walked behind my trail during the night. I am being followed and better switch up my route." _The Blair Witch Project_ versus an Aldo Leopold work.
> 

- link:: https://writing.stackexchange.com/questions/6114/which-tense-to-use-when-writing-a-diary
---

## 📇 Additional Metadata

- 🗂 Type:: #type/note
- 🏷️ Tags:: [[Journaling]] 
