---
uuid: 20230106105756
title: Population Collapse is Coming - Elon Musk, Dr Shanna Swan and Jordan Peterson
created: 2023-01-06T10:57:56
updated: 2023-01-06T10:58:02
private: false
alias:
	- "Population Collapse"
	- "Shrinking Population"
---

# [[Population Collapse is Coming - Elon Musk, Dr Shanna Swan and Jordan Peterson]]

- Author:: [[Elon Musk]], [[Dr Shanna Swan]] and [[@Jordan Peterson|Jordan Peterson]]
- Category::  video
- URL:: https://www.youtube.com/watch?v=zC1khWr7wg8
- Rating:: 4

## Learn by elaboration


---
## 📇Additional Metadata

- 📁Type:: #type/resource 
- 📎Source:: #source
- 🏷️ Tags:: [[Population]] [[Environment]]
- 📡 Status:: #status/🌲 

